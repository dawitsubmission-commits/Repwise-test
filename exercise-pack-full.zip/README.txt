REPWISE full exercise pack (all 1,324 exercises; 1,257 animated, 67 text-only)
Unzip so these folders land inside app/src/main/assets/ :
  catalog/exercises.json, exercises/<id>/frame-0N.svg, licenses/*
Frame paths in the JSON are relative to the assets folder. IDs are strings: keep leading zeros.
4 names with a corrupted degree sign were fixed. Data: MIT. Artwork: CC0-1.0 (see licenses/NOTICE.md).
