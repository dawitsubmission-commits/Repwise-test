package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.normalization.Normalizer
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedReader
import java.io.InputStreamReader

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NormalizationTest {

    @Test
    fun testExplicitRequiredMappings() {
        assertEquals("chest", Normalizer.normalizeMuscle("pectorals"))
        assertEquals("shoulders", Normalizer.normalizeMuscle("delts"))
        assertEquals("quadriceps", Normalizer.normalizeMuscle("quads"))
        assertEquals("trapezius", Normalizer.normalizeMuscle("traps"))
        assertEquals("core", Normalizer.normalizeMuscle("abs"))

        // "band" and "resistance band" are the same
        val band = Normalizer.normalizeEquipment("band")
        val resistanceBand = Normalizer.normalizeEquipment("resistance band")
        assertEquals(band, resistanceBand)
        assertEquals("resistance band", band)
    }

    @Test
    fun testAllMusclesAndEquipmentInCatalogAreMapped() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val jsonContent = context.assets.open("catalog/exercises.json").use { stream ->
            BufferedReader(InputStreamReader(stream)).readText()
        }
        val jsonArray = JSONArray(jsonContent)

        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            val exerciseId = item.getString("id")
            val target = item.getString("target")
            val equipment = item.getString("equipment")

            val normalizedTarget = Normalizer.normalizeMuscle(target)
            assertNotNull("Target muscle for $exerciseId should not be null", normalizedTarget)

            val normalizedEquip = Normalizer.normalizeEquipment(equipment)
            assertNotNull("Equipment for $exerciseId should not be null", normalizedEquip)

            val secondaries = item.optJSONArray("secondaryMuscles")
            if (secondaries != null) {
                for (j in 0 until secondaries.length()) {
                    val sec = secondaries.getString(j)
                    val normalizedSec = Normalizer.normalizeMuscle(sec)
                    assertNotNull("Secondary muscle '$sec' in $exerciseId should not be null", normalizedSec)
                }
            }
        }
    }

    @Test
    fun testUnmappedMuscleFails() {
        assertThrows(IllegalArgumentException::class.java) {
            Normalizer.normalizeMuscle("extraterrestrial_muscle")
        }
    }

    @Test
    fun testUnmappedEquipmentFails() {
        assertThrows(IllegalArgumentException::class.java) {
            Normalizer.normalizeEquipment("anti_gravity_boots")
        }
    }
}
