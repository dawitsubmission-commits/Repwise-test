package com.example.ui.screens.progress

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.repository.RepwiseRepository
import com.example.domain.stats.ComputedWorkoutStats
import com.example.util.WeightHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class ProgressUiState(
    val timeRangeTabs: List<String> = listOf("1 Week", "1 Month", "3 Months", "All Time"),
    val selectedRangeIndex: Int = 1,
    val stats: ComputedWorkoutStats = ComputedWorkoutStats(),
    val personalBests: List<Pair<String, String>> = emptyList(),
    val hasCompletedSessions: Boolean = false,
    val showEmptyDemo: Boolean = false
)

class ProgressViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _uiState = MutableStateFlow(ProgressUiState())
    val uiState: StateFlow<ProgressUiState> = _uiState.asStateFlow()

    init {
        loadProgressData()
    }

    private fun loadProgressData() {
        viewModelScope.launch {
            combine(
                repository.getCompletedSessions(),
                repository.getAllPersonalRecords(),
                repository.getCatalogExercises(),
                repository.getComputedStatsFlow()
            ) { completedSessions, prs, catalog, stats ->
                val catalogMap = catalog.associateBy { it.id }

                // Group PRs by exerciseId to show top bests
                val bests = prs
                    .groupBy { it.exerciseId }
                    .mapNotNull { (exerciseId, exercisePrs) ->
                        val exName = catalogMap[exerciseId]?.name?.replaceFirstChar { it.uppercase() }
                            ?: "Exercise $exerciseId"
                        val topWeightPr = exercisePrs.maxByOrNull { it.value } ?: return@mapNotNull null
                        exName to WeightHelper.format(topWeightPr.value)
                    }

                _uiState.value.copy(
                    stats = stats,
                    personalBests = bests,
                    hasCompletedSessions = completedSessions.isNotEmpty()
                )
            }.collect { updated ->
                _uiState.value = updated
            }
        }
    }

    fun selectRange(index: Int) {
        _uiState.value = _uiState.value.copy(selectedRangeIndex = index)
    }

    fun toggleEmptyDemo() {
        _uiState.value = _uiState.value.copy(showEmptyDemo = !_uiState.value.showEmptyDemo)
    }
}
