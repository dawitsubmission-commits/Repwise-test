package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.ui.screens.active.ActiveWorkoutScreen
import com.example.ui.screens.detail.ExerciseDetailScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.library.LibraryScreen
import com.example.ui.screens.licenses.LicensesScreen
import com.example.ui.screens.onboarding.OnboardingScreen
import com.example.ui.screens.plan.PlanScreen
import com.example.ui.screens.plan.RoutineEditorScreen
import com.example.ui.screens.plan.TemplatePickerScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.progress.ProgressScreen
import com.example.ui.screens.train.TrainScreen

@Composable
fun RepwiseNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier,
    startDestination: String = RepwiseDestination.Home.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier
    ) {
        composable(RepwiseDestination.Onboarding.route) {
            OnboardingScreen(
                onFinish = {
                    navController.navigate(RepwiseDestination.Home.route) {
                        popUpTo(RepwiseDestination.Onboarding.route) {
                            inclusive = true
                        }
                    }
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(RepwiseDestination.Home.route) {
            HomeScreen(
                onStartWorkout = { sessionId ->
                    navController.navigate(RepwiseDestination.ActiveWorkout.createRoute(sessionId))
                },
                onResumeWorkout = { sessionId ->
                    navController.navigate(RepwiseDestination.ActiveWorkout.createRoute(sessionId))
                },
                onNavigateToPlan = {
                    navController.navigate(RepwiseDestination.Plan.route)
                }
            )
        }

        composable(RepwiseDestination.Plan.route) {
            PlanScreen(
                onNavigateToEditor = { planId ->
                    navController.navigate(RepwiseDestination.RoutineEditor.createRoute(planId))
                },
                onNavigateToTemplates = {
                    navController.navigate(RepwiseDestination.TemplatePicker.route)
                }
            )
        }

        composable(RepwiseDestination.Library.route) {
            LibraryScreen(
                onExerciseClick = { exerciseId ->
                    navController.navigate(RepwiseDestination.ExerciseDetail.createRoute(exerciseId))
                }
            )
        }

        composable(RepwiseDestination.Progress.route) {
            ProgressScreen()
        }

        composable(RepwiseDestination.Profile.route) {
            ProfileScreen(
                onNavigateToLicenses = {
                    navController.navigate(RepwiseDestination.Licenses.route)
                },
                onRetakeAssessment = {
                    navController.navigate(RepwiseDestination.Onboarding.route)
                }
            )
        }

        composable(RepwiseDestination.Train.route) {
            TrainScreen(
                onFinish = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = RepwiseDestination.ExerciseDetail.route,
            arguments = listOf(
                navArgument("exerciseId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val exerciseId = backStackEntry.arguments?.getString("exerciseId") ?: ""
            ExerciseDetailScreen(
                exerciseId = exerciseId,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(RepwiseDestination.Licenses.route) {
            LicensesScreen(
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(RepwiseDestination.TemplatePicker.route) {
            TemplatePickerScreen(
                onBack = {
                    navController.popBackStack()
                },
                onTemplateCopied = { newPlanId ->
                    navController.navigate(RepwiseDestination.RoutineEditor.createRoute(newPlanId)) {
                        popUpTo(RepwiseDestination.Plan.route)
                    }
                }
            )
        }

        composable(
            route = RepwiseDestination.RoutineEditor.route,
            arguments = listOf(
                navArgument("planId") {
                    type = NavType.LongType
                }
            )
        ) { backStackEntry ->
            val planId = backStackEntry.arguments?.getLong("planId") ?: 0L
            RoutineEditorScreen(
                planId = planId,
                onBack = {
                    navController.popBackStack()
                },
                onStartWorkout = { sessionId ->
                    navController.navigate(RepwiseDestination.ActiveWorkout.createRoute(sessionId))
                }
            )
        }

        composable(
            route = RepwiseDestination.ActiveWorkout.route,
            arguments = listOf(
                navArgument("sessionId") {
                    type = NavType.LongType
                }
            )
        ) { backStackEntry ->
            val sessionId = backStackEntry.arguments?.getLong("sessionId") ?: 0L
            ActiveWorkoutScreen(
                sessionId = sessionId,
                onFinishWorkout = {
                    navController.popBackStack()
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
