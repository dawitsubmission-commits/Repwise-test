package com.example.ui.components

import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.caverock.androidsvg.SVG
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseShapes
import com.example.ui.theme.RepwiseSpacing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Static thumbnail component for exercise list rows.
 * Renders static frame-00 only, never animation.
 */
@Composable
fun ExerciseStaticThumbnail(
    frame00Path: String?,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp
) {
    val context = LocalContext.current
    var decodedSvg by remember(frame00Path) { mutableStateOf<SVG?>(null) }
    var isFailed by remember(frame00Path) { mutableStateOf(frame00Path.isNullOrEmpty()) }

    LaunchedEffect(frame00Path) {
        if (frame00Path.isNullOrEmpty()) {
            isFailed = true
            return@LaunchedEffect
        }
        val svg = withContext(Dispatchers.IO) {
            try {
                context.assets.open(frame00Path).use { stream ->
                    SVG.getFromInputStream(stream)
                }
            } catch (e: Exception) {
                null
            }
        }
        if (svg != null) {
            decodedSvg = svg
            isFailed = false
        } else {
            isFailed = true
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RepwiseShapes.medium)
            .background(CharcoalSurfaceElevated),
        contentAlignment = Alignment.Center
    ) {
        val svg = decodedSvg
        if (svg != null && !isFailed) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(RepwiseSpacing.xs)
                    .clipToBounds()
            ) {
                drawIntoCanvas { canvas ->
                    val dstRect = RectF(0f, 0f, this.size.width, this.size.height)
                    svg.renderToCanvas(canvas.nativeCanvas, dstRect)
                }
            }
        } else {
            Icon(
                imageVector = Icons.Default.FitnessCenter,
                contentDescription = null,
                tint = RepwiseLime,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
