package com.example.ui.screens.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.EmptyState
import com.example.ui.components.FilterChipRow
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatTile
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.TestTags

@Composable
fun ProgressScreen(
    modifier: Modifier = Modifier,
    viewModel: ProgressViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .testTag(TestTags.SCREEN_PROGRESS),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
    ) {
        item {
            Column(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                SectionHeader(
                    title = "Progress & Records",
                    subtitle = "Volume load and estimated 1RM trends",
                    actionText = if (uiState.showEmptyDemo) "Show Stats" else "Simulate Empty",
                    onActionClick = { viewModel.toggleEmptyDemo() }
                )
            }
        }

        if (!uiState.hasCompletedSessions || uiState.showEmptyDemo) {
            item {
                EmptyState(
                    title = "No workouts yet",
                    description = "Complete your first training session to unlock performance analytics, volume charts, and PR tracking.",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.QueryStats,
                            contentDescription = null,
                            tint = RepwiseLime,
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    actionText = if (uiState.showEmptyDemo) "Restore Activity Data" else null,
                    onActionClick = { viewModel.toggleEmptyDemo() }
                )
            }
        } else {
            // Time Range Selector
            item {
                FilterChipRow(
                    items = uiState.timeRangeTabs,
                    selectedIndex = uiState.selectedRangeIndex,
                    onSelected = { viewModel.selectRange(it) }
                )
            }

            // Stat Tiles Grid
            item {
                Column(
                    modifier = Modifier.padding(horizontal = RepwiseSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        StatTile(
                            label = "Total Volume",
                            value = com.example.util.WeightHelper.format(uiState.stats.totalVolumeKg),
                            change = "Workload lifted",
                            isPositive = true,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = "Workouts Finished",
                            value = "${uiState.stats.totalCompletedSessions}",
                            change = "Completed sessions",
                            isPositive = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        StatTile(
                            label = "Avg Session Time",
                            value = "${uiState.stats.avgDurationMinutes} min",
                            change = "Average duration",
                            isPositive = true,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = "PRs (30d)",
                            value = "${uiState.stats.prsLast30Days} records",
                            change = "Recent milestones",
                            isPositive = uiState.stats.prsLast30Days > 0,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Personal Bests Section
            item {
                Column(modifier = Modifier.padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)) {
                    SectionHeader(
                        title = "Personal Best Lifts",
                        subtitle = "Verified all-time weight records"
                    )
                }
            }

            if (uiState.personalBests.isEmpty()) {
                item {
                    Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                        RepwiseCard {
                            Text(
                                text = "No personal records recorded yet. Complete working sets to track all-time weight bests.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            items(uiState.personalBests) { pb ->
                Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                    RepwiseCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CharcoalSurfaceElevated),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = RepwiseLime,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(RepwiseSpacing.md))
                                Text(
                                    text = pb.first,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = TextHighEmphasis
                                )
                            }

                            Text(
                                text = pb.second,
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime
                            )
                        }
                    }
                }
            }

            item {
                Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm)) {
                    SecondaryButton(
                        text = "Export Performance Summary",
                        onClick = { /* Placeholder action */ },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Insights,
                                contentDescription = null
                            )
                        }
                    )
                }
            }
        }
    }
}
