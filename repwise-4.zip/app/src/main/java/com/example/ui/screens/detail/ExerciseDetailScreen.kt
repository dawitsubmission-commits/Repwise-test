package com.example.ui.screens.detail

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.ui.components.EmptyState
import com.example.ui.components.ExerciseAnimation
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ExerciseDetailScreen(
    exerciseId: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ExerciseDetailViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddToRoutineSheet by remember { mutableStateOf(false) }

    BackHandler {
        onBack()
    }

    LaunchedEffect(exerciseId) {
        viewModel.loadExercise(exerciseId)
    }

    val exercise = uiState.exercise

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(CharcoalBackground)
                .padding(WindowInsets.statusBars.asPaddingValues())
                .testTag("screen_exercise_detail")
        ) {
            // Top App Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(CharcoalSurfaceElevated)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextHighEmphasis
                    )
                }

                Spacer(modifier = Modifier.width(RepwiseSpacing.md))

                Text(
                    text = exercise?.name?.replaceFirstChar { it.uppercase() } ?: "Exercise Details",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
            }

            if (uiState.isLoading || exercise == null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(RepwiseSpacing.xxl),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = RepwiseLime)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(RepwiseSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.lg)
                ) {
                    // 1. ExerciseAnimation (or text-only fallback card)
                    item {
                        val frameList = if (exercise.hasAnimation) {
                            listOf(
                                exercise.frame00Path!!,
                                exercise.frame01Path!!,
                                exercise.frame02Path!!
                            )
                        } else null

                        ExerciseAnimation(
                            frames = frameList,
                            sequence = exercise.sequence,
                            frameDurationMs = exercise.frameDurationMs ?: 180L,
                            speedMultiplier = uiState.speedMultiplier,
                            exerciseName = exercise.name.replaceFirstChar { it.uppercase() },
                            targetMuscle = exercise.target.replaceFirstChar { it.uppercase() },
                            equipment = exercise.equipment.replaceFirstChar { it.uppercase() }
                        )
                    }

                    // 2. Guidance Line Requirement: "Illustrations are for general guidance."
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CharcoalSurfaceElevated)
                                .border(1.dp, CharcoalBorderSubtle, RoundedCornerShape(8.dp))
                                .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Guidance note",
                                tint = RepwiseLime,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                            Text(
                                text = "Illustrations are for general guidance.",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = TextSecondary
                            )
                        }
                    }

                    // 3. "Add to Routine" Button (Mandated by prompt)
                    item {
                        SecondaryButton(
                            text = "Add to Routine",
                            onClick = { showAddToRoutineSheet = true },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.PlaylistAdd,
                                    contentDescription = null,
                                    tint = RepwiseLime
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_to_routine_button")
                        )
                    }

                    // 4. Target and Secondary Muscles + Equipment tags
                    item {
                        RepwiseCard {
                            Text(
                                text = "Muscles & Equipment",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextHighEmphasis
                            )

                            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm),
                                verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)
                            ) {
                                // Primary target muscle chip
                                Box(
                                    modifier = Modifier
                                        .clip(PillShape)
                                        .background(RepwiseLime)
                                        .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
                                ) {
                                    Text(
                                        text = "Target: ${exercise.target.replaceFirstChar { it.uppercase() }}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = RepwiseOnLime
                                    )
                                }

                                // Equipment chip
                                Box(
                                    modifier = Modifier
                                        .clip(PillShape)
                                        .background(CharcoalSurfaceElevated)
                                        .border(1.dp, CharcoalBorderSubtle, PillShape)
                                        .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
                                ) {
                                    Text(
                                        text = "Equipment: ${exercise.equipment.replaceFirstChar { it.uppercase() }}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = TextHighEmphasis
                                    )
                                }

                                // Secondary muscles chips
                                exercise.secondaryMuscles.forEach { sec ->
                                    Box(
                                        modifier = Modifier
                                            .clip(PillShape)
                                            .background(CharcoalSurfaceElevated)
                                            .border(1.dp, CharcoalBorderSubtle, PillShape)
                                            .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
                                    ) {
                                        Text(
                                            text = "Secondary: ${sec.replaceFirstChar { it.uppercase() }}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 5. Numbered Instructions
                    item {
                        SectionHeader(
                            title = "Instructions",
                            subtitle = "${exercise.instructions.size} steps to perform correctly"
                        )
                    }

                    if (exercise.instructions.isEmpty()) {
                        item {
                            RepwiseCard {
                                Text(
                                    text = "No step-by-step instructions recorded for this exercise.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    } else {
                        itemsIndexed(exercise.instructions) { index, instruction ->
                            RepwiseCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(RepwiseLimeMuted),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = RepwiseLime
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(RepwiseSpacing.md))

                                    Text(
                                        text = instruction,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextHighEmphasis,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add to Routine Bottom Sheet
        if (showAddToRoutineSheet) {
            AddToRoutineBottomSheet(
                plans = uiState.allPlans,
                onDismiss = { showAddToRoutineSheet = false },
                onDaySelected = { dayId, routineName, dayName ->
                    viewModel.addExerciseToRoutineDay(dayId, routineName, dayName)
                    showAddToRoutineSheet = false
                }
            )
        }

        // Notification Banner
        val message = uiState.addedNotificationMessage
        if (message != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(RepwiseSpacing.md)
                    .clip(RoundedCornerShape(8.dp))
                    .background(RepwiseLime)
                    .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm)
                    .clickable { viewModel.dismissNotification() }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = RepwiseOnLime,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                    Text(
                        text = message,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = RepwiseOnLime
                    )
                }
            }
        }
    }
}

/**
 * Bottom sheet to pick routine and day to append exercise to.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddToRoutineBottomSheet(
    plans: List<WorkoutPlanWithDays>,
    onDismiss: () -> Unit,
    onDaySelected: (dayId: Long, routineName: String, dayName: String) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = CharcoalSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(RepwiseSpacing.md)
        ) {
            SectionHeader(
                title = "Add to Routine",
                subtitle = "Select which routine day to append this exercise to"
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.md))

            if (plans.isEmpty()) {
                Box(modifier = Modifier.padding(vertical = RepwiseSpacing.md)) {
                    EmptyState(
                        title = "No Routines Found",
                        description = "Create a routine in the Plan tab first before adding exercises.",
                        actionText = "Close",
                        onActionClick = onDismiss
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                ) {
                    plans.forEach { planWithDays ->
                        item {
                            Text(
                                text = planWithDays.plan.name.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime,
                                modifier = Modifier.padding(vertical = RepwiseSpacing.xs)
                            )
                        }

                        itemsIndexed(planWithDays.days) { _, dayWithEx ->
                            RepwiseCard(
                                onClick = {
                                    onDaySelected(dayWithEx.day.id, planWithDays.plan.name, dayWithEx.day.name)
                                }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = dayWithEx.day.name,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = TextHighEmphasis
                                        )
                                        Text(
                                            text = "${dayWithEx.exercises.size} existing exercises",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add here",
                                        tint = RepwiseLime
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
