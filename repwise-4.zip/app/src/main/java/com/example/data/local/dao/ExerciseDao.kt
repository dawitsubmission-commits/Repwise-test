package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.local.entities.ExerciseEntity
import com.example.data.local.entities.ExerciseSecondaryMuscleEntity
import com.example.data.local.entities.ExerciseWithSecondaries
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(exercises: List<ExerciseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSecondaryMuscles(secondaries: List<ExerciseSecondaryMuscleEntity>)

    @Transaction
    suspend fun insertAll(
        exercises: List<ExerciseEntity>,
        secondaries: List<ExerciseSecondaryMuscleEntity>
    ) {
        insertExercises(exercises)
        insertSecondaryMuscles(secondaries)
    }

    @Query("SELECT COUNT(*) FROM exercise")
    suspend fun getExerciseCount(): Int

    @Transaction
    @Query("SELECT * FROM exercise ORDER BY name ASC")
    fun getAllExercises(): Flow<List<ExerciseWithSecondaries>>

    @Transaction
    @Query("SELECT * FROM exercise WHERE id = :id")
    fun getExerciseById(id: String): Flow<ExerciseWithSecondaries?>

    @Transaction
    @Query("SELECT * FROM exercise WHERE id = :id")
    suspend fun getExerciseByIdOnce(id: String): ExerciseWithSecondaries?
}
