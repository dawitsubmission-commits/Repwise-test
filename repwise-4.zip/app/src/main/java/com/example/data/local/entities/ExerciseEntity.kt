package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exercise")
data class ExerciseEntity(
    @PrimaryKey
    val id: String, // String keeping leading zeros (e.g. "0662")
    val name: String,
    val bodyPart: String,
    val equipment: String,
    val target: String,
    val movementPattern: String?,
    val instructionsJson: String, // Instructions stored as JSON text
    val dataLicense: String?,
    val mediaStatus: String?,
    val frame00Path: String?,
    val frame01Path: String?,
    val frame02Path: String?,
    val sequenceJson: String?,
    val frameDurationMs: Long?,
    val animationLicense: String?
)
