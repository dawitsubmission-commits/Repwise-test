package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.ExerciseDao
import com.example.data.local.dao.PlanDao
import com.example.data.local.dao.SessionDao
import com.example.data.local.entities.ExerciseEntity
import com.example.data.local.entities.ExerciseSecondaryMuscleEntity
import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.PlanDayEntity
import com.example.data.local.entities.PlanExerciseEntity
import com.example.data.local.entities.SessionExerciseEntity
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutPlanEntity
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.dao.UserProfileDao
import com.example.data.local.entities.UserProfileEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ExerciseEntity::class,
        ExerciseSecondaryMuscleEntity::class,
        WorkoutPlanEntity::class,
        PlanDayEntity::class,
        PlanExerciseEntity::class,
        WorkoutSessionEntity::class,
        SessionExerciseEntity::class,
        SetLogEntity::class,
        PersonalRecordEntity::class,
        UserProfileEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class RepwiseDatabase : RoomDatabase() {

    abstract fun exerciseDao(): ExerciseDao
    abstract fun planDao(): PlanDao
    abstract fun sessionDao(): SessionDao
    abstract fun userProfileDao(): UserProfileDao

    companion object {
        @Volatile
        private var INSTANCE: RepwiseDatabase? = null

        fun getInstance(context: Context): RepwiseDatabase {
            return INSTANCE ?: synchronized(this) {
                val appContext = context.applicationContext
                val instance = Room.databaseBuilder(
                    appContext,
                    RepwiseDatabase::class.java,
                    "repwise.db"
                )
                    // TODO: remove fallbackToDestructiveMigration before release
                    .fallbackToDestructiveMigration()
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Re-import catalog if created or wiped
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    ExerciseCatalogImporter.importCatalogIfEmpty(appContext, database.exerciseDao())
                                }
                            }
                        }

                        override fun onDestructiveMigration(db: SupportSQLiteDatabase) {
                            super.onDestructiveMigration(db)
                            // Re-import catalog if it gets wiped
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    ExerciseCatalogImporter.importCatalogIfEmpty(appContext, database.exerciseDao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
