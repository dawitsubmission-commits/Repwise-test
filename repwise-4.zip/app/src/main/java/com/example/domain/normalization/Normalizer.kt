package com.example.domain.normalization

/**
 * Normalizes muscle names and equipment values to canonical representations.
 * Explicit requirements:
 *  - pectorals -> chest
 *  - delts -> shoulders
 *  - quads -> quadriceps
 *  - traps -> trapezius
 *  - abs -> core
 *  - "band" and "resistance band" are the same
 */
object Normalizer {

    private val muscleMap: Map<String, String> = mapOf(
        // Explicit required mappings
        "pectorals" to "chest",
        "delts" to "shoulders",
        "quads" to "quadriceps",
        "traps" to "trapezius",
        "abs" to "core",

        // Canonical and synonym mappings
        "chest" to "chest",
        "deltoids" to "shoulders",
        "shoulders" to "shoulders",
        "rear deltoids" to "rear deltoids",
        "quadriceps" to "quadriceps",
        "trapezius" to "trapezius",
        "core" to "core",
        "obliques" to "obliques",
        "biceps" to "biceps",
        "triceps" to "triceps",
        "forearms" to "forearms",
        "calves" to "calves",
        "soleus" to "soleus",
        "glutes" to "glutes",
        "hamstrings" to "hamstrings",
        "hip flexors" to "hip flexors",
        "lats" to "lats",
        "upper back" to "upper back",
        "lower back" to "lower back",
        "spine" to "spine",
        "rhomboids" to "rhomboids",
        "cardiovascular system" to "cardiovascular system",
        "ankle stabilizers" to "ankle stabilizers",
        "ankles" to "ankles",
        "feet" to "feet"
    )

    private val equipmentMap: Map<String, String> = mapOf(
        "band" to "resistance band",
        "resistance band" to "resistance band",
        "barbell" to "barbell",
        "body weight" to "body weight",
        "cable" to "cable",
        "dumbbell" to "dumbbell",
        "leverage machine" to "leverage machine"
    )

    /**
     * Normalizes a muscle string.
     * Throws [IllegalArgumentException] on any unmapped value so unit tests fail immediately.
     */
    fun normalizeMuscle(raw: String): String {
        val key = raw.trim().lowercase()
        return muscleMap[key] ?: throw IllegalArgumentException("Unmapped muscle value: '$raw'")
    }

    /**
     * Normalizes an equipment string.
     * Throws [IllegalArgumentException] on any unmapped value so unit tests fail immediately.
     */
    fun normalizeEquipment(raw: String): String {
        val key = raw.trim().lowercase()
        return equipmentMap[key] ?: throw IllegalArgumentException("Unmapped equipment value: '$raw'")
    }

    fun isMuscleMapped(raw: String): Boolean = muscleMap.containsKey(raw.trim().lowercase())
    fun isEquipmentMapped(raw: String): Boolean = equipmentMap.containsKey(raw.trim().lowercase())

    /**
     * Return list of primary normalized muscle groups for UI filter chips.
     */
    fun getAllFilterMuscles(): List<String> {
        return listOf(
            "All",
            "chest",
            "shoulders",
            "quadriceps",
            "trapezius",
            "core",
            "back",
            "biceps",
            "triceps",
            "glutes",
            "hamstrings",
            "calves"
        )
    }

    /**
     * Return list of primary normalized equipments for UI filter chips.
     */
    fun getAllFilterEquipments(): List<String> {
        return listOf(
            "All",
            "body weight",
            "barbell",
            "dumbbell",
            "cable",
            "resistance band",
            "leverage machine"
        )
    }
}
