package com.example.ui.screens.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.models.CatalogExercise
import com.example.domain.repository.RepwiseRepository
import com.example.domain.repository.StartWorkoutResult
import com.example.domain.stats.ComputedWorkoutStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.example.domain.planner.BodyPartArea
import com.example.domain.planner.ExperienceLevel
import com.example.domain.planner.FitnessGoal
import com.example.domain.planner.GeneratedExercise
import com.example.domain.planner.PlanGenerator
import com.example.domain.planner.PlanGeneratorRequest
import com.example.domain.planner.TrainingLocation
import java.time.LocalDate

sealed interface TodayWorkoutStatus {
    data class Scheduled(
        val planDayId: Long,
        val routineName: String,
        val dayName: String,
        val exerciseCount: Int,
        val estimatedMinutes: Int,
        val exerciseNames: List<String>
    ) : TodayWorkoutStatus

    data object RestDay : TodayWorkoutStatus

    data object NoRoutineYet : TodayWorkoutStatus
}

data class HomeUiState(
    val todayStatus: TodayWorkoutStatus = TodayWorkoutStatus.NoRoutineYet,
    val inProgressSession: WorkoutSessionWithExercises? = null,
    val stats: ComputedWorkoutStats = ComputedWorkoutStats(),
    val isLoading: Boolean = false
)

class HomeViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _isLoading = MutableStateFlow(true)

    init {
        viewModelScope.launch {
            repository.ensureCatalogInitialized()
            _isLoading.value = false
        }
    }

    val uiState: StateFlow<HomeUiState> = combine(
        repository.getActiveWorkoutPlan(),
        repository.getCatalogExercises(),
        repository.getActiveInProgressSession(),
        repository.getComputedStatsFlow(),
        _isLoading
    ) { activePlan, catalogList, inProgressSession, computedStats, loading ->
        val todayWeekday = LocalDate.now().dayOfWeek.value // 1 = Mon .. 7 = Sun
        val catalogMap = catalogList.associateBy { it.id }

        val status: TodayWorkoutStatus = if (activePlan == null) {
            TodayWorkoutStatus.NoRoutineYet
        } else {
            val scheduledDay = activePlan.days.find { it.day.weekday == todayWeekday }
            if (scheduledDay != null && scheduledDay.exercises.isNotEmpty()) {
                val exNames = scheduledDay.exercises.map {
                    catalogMap[it.exerciseId]?.name?.replaceFirstChar { c -> c.uppercase() } ?: "Exercise"
                }
                TodayWorkoutStatus.Scheduled(
                    planDayId = scheduledDay.day.id,
                    routineName = activePlan.plan.name,
                    dayName = scheduledDay.day.name,
                    exerciseCount = scheduledDay.exercises.size,
                    estimatedMinutes = (scheduledDay.exercises.size * 10).coerceAtLeast(35),
                    exerciseNames = exNames
                )
            } else {
                TodayWorkoutStatus.RestDay
            }
        }

        HomeUiState(
            todayStatus = status,
            inProgressSession = inProgressSession,
            stats = computedStats,
            isLoading = loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    fun startScheduledWorkout(
        onStarted: (Long) -> Unit,
        onConflict: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val status = uiState.value.todayStatus
            val result = if (status is TodayWorkoutStatus.Scheduled) {
                repository.startWorkoutFromPlanDay(status.planDayId)
            } else {
                repository.startEmptyWorkout("Full Body Workout")
            }
            when (result) {
                is StartWorkoutResult.Started -> onStarted(result.sessionId)
                is StartWorkoutResult.ExistingInProgress -> onConflict(result.sessionId)
            }
        }
    }

    fun startEmptyWorkout(
        onStarted: (Long) -> Unit,
        onConflict: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            when (val result = repository.startEmptyWorkout("Quick Workout")) {
                is StartWorkoutResult.Started -> onStarted(result.sessionId)
                is StartWorkoutResult.ExistingInProgress -> onConflict(result.sessionId)
            }
        }
    }

    fun selectBodyPart(
        area: BodyPartArea,
        onNoProfile: () -> Unit,
        onReady: (BodyPartArea, String, List<GeneratedExercise>) -> Unit
    ) {
        viewModelScope.launch {
            val profile = repository.getUserProfileEntityOnce()
            if (profile == null) {
                onNoProfile()
                return@launch
            }

            val catalogList = repository.getCatalogExercises().firstOrNull() ?: emptyList()
            val catalogIds = catalogList.map { it.id }.toSet()

            val exp = try {
                ExperienceLevel.valueOf(profile.experience)
            } catch (e: Exception) {
                ExperienceLevel.BEGINNER
            }

            val goal = try {
                FitnessGoal.valueOf(profile.goal)
            } catch (e: Exception) {
                FitnessGoal.BUILD_MUSCLE
            }

            val loc = try {
                TrainingLocation.valueOf(profile.location)
            } catch (e: Exception) {
                TrainingLocation.HOME
            }

            val eqSet = profile.equipment.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
            val weekdays = profile.trainingWeekdays.split(",").mapNotNull { it.trim().toIntOrNull() }.sorted()

            val request = PlanGeneratorRequest(
                age = profile.age,
                experience = exp,
                goal = goal,
                location = loc,
                equipmentKeys = eqSet,
                chosenWeekdays = weekdays,
                availableExerciseIds = if (catalogIds.isNotEmpty()) catalogIds else null
            )

            val exercises = PlanGenerator.generateBodyPartDay(area, request)
            val displayName = when (area) {
                BodyPartArea.CHEST -> "Chest"
                BodyPartArea.BACK -> "Back"
                BodyPartArea.LEGS -> "Legs"
                BodyPartArea.SHOULDERS -> "Shoulders"
                BodyPartArea.ARMS -> "Arms"
                BodyPartArea.CORE -> "Core"
            }
            onReady(area, displayName, exercises)
        }
    }

    fun startBodyPartWorkout(
        dayName: String,
        exercises: List<GeneratedExercise>,
        onStarted: (Long) -> Unit,
        onConflict: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            when (val result = repository.startWorkoutFromGeneratedExercises(dayName, exercises)) {
                is StartWorkoutResult.Started -> onStarted(result.sessionId)
                is StartWorkoutResult.ExistingInProgress -> onConflict(result.sessionId)
            }
        }
    }

    fun discardSession(sessionId: Long) {
        viewModelScope.launch {
            repository.discardSession(sessionId)
        }
    }
}
