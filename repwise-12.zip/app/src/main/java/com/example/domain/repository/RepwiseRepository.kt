package com.example.domain.repository

import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.domain.models.CatalogExercise
import com.example.domain.models.Exercise
import com.example.domain.models.MuscleGroup
import com.example.domain.models.WorkoutTemplate
import com.example.domain.stats.ComputedWorkoutStats
import kotlinx.coroutines.flow.Flow

sealed interface StartWorkoutResult {
    data class Started(val sessionId: Long) : StartWorkoutResult
    data class ExistingInProgress(val sessionId: Long) : StartWorkoutResult
}

interface RepwiseRepository {
    // Real computed stats across completed sessions
    fun getComputedStatsFlow(): Flow<ComputedWorkoutStats>

    // Room-backed catalog operations for Phase 3+4
    fun getCatalogExercises(): Flow<List<CatalogExercise>>
    fun getCatalogExerciseById(id: String): Flow<CatalogExercise?>
    suspend fun ensureCatalogInitialized()

    // Room-backed workout planner operations for Phase 5
    fun getAllWorkoutPlans(): Flow<List<WorkoutPlanWithDays>>
    fun getWorkoutPlanById(planId: Long): Flow<WorkoutPlanWithDays?>
    fun getActiveWorkoutPlan(): Flow<WorkoutPlanWithDays?>
    suspend fun saveWorkoutPlan(planWithDays: WorkoutPlanWithDays): Long
    suspend fun updateWorkoutPlan(planWithDays: WorkoutPlanWithDays)
    suspend fun deleteWorkoutPlan(planId: Long)
    suspend fun setActiveWorkoutPlan(planId: Long)
    suspend fun duplicateWorkoutPlan(planId: Long): Long
    suspend fun replaceExerciseInPlan(planExerciseId: Long, newExerciseId: String)
    suspend fun addExerciseToPlanDay(dayId: Long, exerciseId: String, sets: Int = 3, repMin: Int = 8, repMax: Int = 12, restSeconds: Int = 90)
    suspend fun deletePlanExercise(planExerciseId: Long)

    // Room-backed active workout operations for Phase 6
    suspend fun startWorkoutFromPlanDay(planDayId: Long): StartWorkoutResult
    suspend fun startWorkoutFromGeneratedExercises(dayName: String, exercises: List<com.example.domain.planner.GeneratedExercise>): StartWorkoutResult
    suspend fun startEmptyWorkout(dayName: String = "Quick Workout"): StartWorkoutResult
    fun getActiveInProgressSession(): Flow<com.example.data.local.entities.WorkoutSessionWithExercises?>
    suspend fun getActiveInProgressSessionOnce(): com.example.data.local.entities.WorkoutSessionWithExercises?
    fun getSessionById(sessionId: Long): Flow<com.example.data.local.entities.WorkoutSessionWithExercises?>
    suspend fun getSessionByIdOnce(sessionId: Long): com.example.data.local.entities.WorkoutSessionWithExercises?
    suspend fun updateSessionNote(sessionId: Long, note: String?)
    suspend fun updateExerciseNote(sessionExerciseId: Long, note: String?)
    suspend fun addExerciseToSession(sessionId: Long, exerciseId: String, setsCount: Int = 3, repMin: Int = 8, restSeconds: Int = 90): Long
    suspend fun removeExerciseFromSession(sessionExerciseId: Long)
    suspend fun addSetToExercise(sessionExerciseId: Long, weightKg: Double, reps: Int, isWarmup: Boolean = false): Long
    suspend fun updateSetLog(setLog: com.example.data.local.entities.SetLogEntity)
    suspend fun deleteSetLog(setLogId: Long)
    suspend fun substituteExercise(sessionExerciseId: Long, newExerciseId: String)
    suspend fun finishSession(sessionId: Long): List<com.example.data.local.entities.PersonalRecordEntity>
    suspend fun discardSession(sessionId: Long)
    suspend fun getPreviousPerformance(exerciseId: String): com.example.domain.PreviousPerformance?
    fun getCompletedSessions(): Flow<List<com.example.data.local.entities.WorkoutSessionWithExercises>>
    fun getAllPersonalRecords(): Flow<List<com.example.data.local.entities.PersonalRecordEntity>>

    // Phase 7 User Profile and Assessment
    fun getUserProfileFlow(): Flow<com.example.data.local.entities.UserProfileEntity?>
    suspend fun getUserProfileEntityOnce(): com.example.data.local.entities.UserProfileEntity?
    suspend fun saveUserProfile(profile: com.example.data.local.entities.UserProfileEntity)
    suspend fun saveGeneratedPlan(generatedPlan: com.example.domain.planner.GeneratedPlan): Long
}
