package com.example

import com.example.domain.planner.BodyPartArea
import com.example.domain.planner.ExperienceLevel
import com.example.domain.planner.FitnessGoal
import com.example.domain.planner.MovementSlot
import com.example.domain.planner.PlanGenerator
import com.example.domain.planner.PlanGeneratorRequest
import com.example.domain.planner.TrainingLocation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BodyPartDayTest {

    private fun buildRequest(
        experience: ExperienceLevel = ExperienceLevel.INTERMEDIATE,
        goal: FitnessGoal = FitnessGoal.BUILD_MUSCLE,
        location: TrainingLocation = TrainingLocation.GYM,
        equipmentKeys: Set<String> = setOf("full_gym"),
        availableExerciseIds: Set<String>? = null,
        age: Int = 25
    ) = PlanGeneratorRequest(
        age = age,
        experience = experience,
        goal = goal,
        location = location,
        equipmentKeys = equipmentKeys,
        chosenWeekdays = listOf(1, 3, 5),
        availableExerciseIds = availableExerciseIds
    )

    @Test
    fun `each area uses only its allowed slots`() {
        val request = buildRequest()

        // CHEST: H_PUSH x4, TRICEPS
        val chestAllowed = setOf(MovementSlot.H_PUSH, MovementSlot.TRICEPS)
        val chest = PlanGenerator.generateBodyPartDay(BodyPartArea.CHEST, request)
        assertTrue(chest.isNotEmpty())
        for (ex in chest) {
            assertTrue("Chest exercise ${ex.name} has invalid slot ${ex.slot}", chestAllowed.contains(ex.slot))
        }

        // BACK: V_PULL, H_PULL, H_PULL, REAR_DELT, BICEPS
        val backAllowed = setOf(MovementSlot.V_PULL, MovementSlot.H_PULL, MovementSlot.REAR_DELT, MovementSlot.BICEPS)
        val back = PlanGenerator.generateBodyPartDay(BodyPartArea.BACK, request)
        assertTrue(back.isNotEmpty())
        for (ex in back) {
            assertTrue("Back exercise ${ex.name} has invalid slot ${ex.slot}", backAllowed.contains(ex.slot))
        }

        // LEGS: KNEE, KNEE, HINGE, LEG_CURL, CALF
        val legsAllowed = setOf(MovementSlot.KNEE, MovementSlot.HINGE, MovementSlot.LEG_CURL, MovementSlot.CALF)
        val legs = PlanGenerator.generateBodyPartDay(BodyPartArea.LEGS, request)
        assertTrue(legs.isNotEmpty())
        for (ex in legs) {
            assertTrue("Legs exercise ${ex.name} has invalid slot ${ex.slot}", legsAllowed.contains(ex.slot))
        }

        // SHOULDERS: V_PUSH, V_PUSH, SHOULDER_ACC, REAR_DELT
        val shoulderAllowed = setOf(MovementSlot.V_PUSH, MovementSlot.SHOULDER_ACC, MovementSlot.REAR_DELT)
        val shoulders = PlanGenerator.generateBodyPartDay(BodyPartArea.SHOULDERS, request)
        assertTrue(shoulders.isNotEmpty())
        for (ex in shoulders) {
            assertTrue("Shoulders exercise ${ex.name} has invalid slot ${ex.slot}", shoulderAllowed.contains(ex.slot))
        }

        // ARMS: BICEPS, TRICEPS, BICEPS, TRICEPS
        val armsAllowed = setOf(MovementSlot.BICEPS, MovementSlot.TRICEPS)
        val arms = PlanGenerator.generateBodyPartDay(BodyPartArea.ARMS, request)
        assertTrue(arms.isNotEmpty())
        for (ex in arms) {
            assertTrue("Arms exercise ${ex.name} has invalid slot ${ex.slot}", armsAllowed.contains(ex.slot))
        }

        // CORE: CORE x4
        val coreAllowed = setOf(MovementSlot.CORE)
        val core = PlanGenerator.generateBodyPartDay(BodyPartArea.CORE, request)
        assertTrue(core.isNotEmpty())
        for (ex in core) {
            assertTrue("Core exercise ${ex.name} has invalid slot ${ex.slot}", coreAllowed.contains(ex.slot))
        }
    }

    @Test
    fun `no repeated exercise in generated body part day`() {
        val request = buildRequest()
        for (area in BodyPartArea.values()) {
            val exercises = PlanGenerator.generateBodyPartDay(area, request)
            val ids = exercises.map { it.exerciseId }
            assertEquals(
                "Area $area contained duplicate exercises: $ids",
                ids.size,
                ids.toSet().size
            )
        }
    }

    @Test
    fun `beginner limit of 5 exercises is respected`() {
        val beginnerRequest = buildRequest(experience = ExperienceLevel.BEGINNER)
        for (area in BodyPartArea.values()) {
            val exercises = PlanGenerator.generateBodyPartDay(area, beginnerRequest)
            assertTrue(
                "Beginner workout for $area must have at most 5 exercises, had ${exercises.size}",
                exercises.size <= 5
            )
        }
    }

    @Test
    fun `generation is deterministic`() {
        val request = buildRequest()
        for (area in BodyPartArea.values()) {
            val first = PlanGenerator.generateBodyPartDay(area, request)
            val second = PlanGenerator.generateBodyPartDay(area, request)
            assertEquals("First and second run for $area must match exactly", first, second)
        }
    }

    @Test
    fun `availableExerciseIds is strictly respected`() {
        // Provide a limited allowed set of 3 exercise IDs
        val allowedIds = setOf("0662", "0289", "0430")
        val request = buildRequest(
            experience = ExperienceLevel.BEGINNER,
            availableExerciseIds = allowedIds
        )

        val chest = PlanGenerator.generateBodyPartDay(BodyPartArea.CHEST, request)
        for (ex in chest) {
            assertTrue(
                "Generated exercise ${ex.exerciseId} (${ex.name}) must be in allowed availableExerciseIds",
                allowedIds.contains(ex.exerciseId)
            )
        }
    }

    @Test
    fun `returns empty list when nothing fits`() {
        // Disjoint IDs
        val request = buildRequest(
            availableExerciseIds = setOf("nonexistent_1", "nonexistent_2")
        )
        val exercises = PlanGenerator.generateBodyPartDay(BodyPartArea.CHEST, request)
        assertTrue("Must return empty list when no exercises fit availableExerciseIds", exercises.isEmpty())

        // Under minimum age
        val underAgeRequest = buildRequest(age = 10)
        val underAgeExercises = PlanGenerator.generateBodyPartDay(BodyPartArea.CHEST, underAgeRequest)
        assertTrue("Must return empty list when under minimum age", underAgeExercises.isEmpty())
    }
}
