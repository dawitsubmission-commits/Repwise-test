package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import com.example.domain.musclemap.MuscleMap
import com.example.domain.musclemap.MuscleMapData
import com.example.domain.musclemap.MuscleSlugMapper
import com.example.ui.theme.RepwiseLime

private data class ParsedPart(val slug: String, val paths: List<Path>)

/**
 * Muscle map overlay showing miniature front and back anatomical silhouettes
 * with highlighted primary and secondary muscle groups.
 */
@Composable
fun MuscleMapOverlay(
    primaryMuscle: String,
    secondaryMuscles: List<String> = emptyList(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var muscleMap by remember { mutableStateOf<MuscleMap?>(MuscleMapData.getCached()) }

    LaunchedEffect(Unit) {
        if (muscleMap == null) {
            muscleMap = MuscleMapData.get(context)
        }
    }

    val currentMap = muscleMap ?: return

    val highlights = remember(primaryMuscle, secondaryMuscles) {
        MuscleSlugMapper.resolveHighlights(primaryMuscle, secondaryMuscles)
    }

    val frontParts: List<ParsedPart> = remember(currentMap) {
        currentMap.front.parts.map { part ->
            val paths = part.paths.mapNotNull { pathStr ->
                try {
                    androidx.core.graphics.PathParser.createPathFromPathData(pathStr).asComposePath()
                } catch (e: Exception) {
                    try {
                        androidx.compose.ui.graphics.vector.PathParser().parsePathString(pathStr).toPath()
                    } catch (e2: Exception) {
                        null
                    }
                }
            }
            ParsedPart(part.slug, paths)
        }
    }

    val backParts: List<ParsedPart> = remember(currentMap) {
        currentMap.back.parts.map { part ->
            val paths = part.paths.mapNotNull { pathStr ->
                try {
                    androidx.core.graphics.PathParser.createPathFromPathData(pathStr).asComposePath()
                } catch (e: Exception) {
                    try {
                        androidx.compose.ui.graphics.vector.PathParser().parsePathString(pathStr).toPath()
                    } catch (e2: Exception) {
                        null
                    }
                }
            }
            ParsedPart(part.slug, paths)
        }
    }

    val neutralGrey = Color(0xFF5F5F5F)
    val primaryColor = RepwiseLime
    val secondaryColor = RepwiseLime.copy(alpha = 0.40f)

    fun colorForSlug(slug: String): Color {
        if (slug in MuscleSlugMapper.NON_HIGHLIGHTABLE_SLUGS) {
            return neutralGrey
        }
        return when {
            slug in highlights.primarySlugs -> primaryColor
            slug in highlights.secondarySlugs -> secondaryColor
            else -> neutralGrey
        }
    }

    Box(modifier = modifier.alpha(0.70f)) {
        Canvas(modifier = Modifier.matchParentSize()) {
            if (size.width <= 0f || size.height <= 0f) return@Canvas

            val figureWidth = 724f
            val figureHeight = 1448f
            val gap = 16f

            val totalModelWidth = figureWidth * 2f + gap
            val totalModelHeight = figureHeight

            val scale = minOf(size.width / totalModelWidth, size.height / totalModelHeight)
            val renderedWidth = totalModelWidth * scale
            val renderedHeight = totalModelHeight * scale

            val offsetX = (size.width - renderedWidth) / 2f
            val offsetY = (size.height - renderedHeight) / 2f

            // Front figure (left)
            withTransform({
                translate(left = offsetX, top = offsetY)
                scale(scaleX = scale, scaleY = scale, pivot = Offset.Zero)
            }) {
                for (part in frontParts) {
                    val color = colorForSlug(part.slug)
                    for (path in part.paths) {
                        drawPath(path = path, color = color)
                    }
                }
            }

            // Back figure (right) - coordinates start at x=724, translate by -724
            withTransform({
                translate(left = offsetX + (figureWidth + gap) * scale, top = offsetY)
                scale(scaleX = scale, scaleY = scale, pivot = Offset.Zero)
                translate(left = -figureWidth, top = 0f)
            }) {
                for (part in backParts) {
                    val color = colorForSlug(part.slug)
                    for (path in part.paths) {
                        drawPath(path = path, color = color)
                    }
                }
            }
        }
    }
}
