package com.example.ui.screens.active

import android.app.Activity
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.PersonalRecordType
import com.example.data.local.entities.SessionExerciseWithSets
import com.example.data.local.entities.SetLogEntity
import com.example.domain.PreviousPerformance
import com.example.domain.models.CatalogExercise
import com.example.ui.components.ExerciseAnimation
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.util.Formatters
import com.example.util.TestTags
import com.example.util.WeightHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveWorkoutScreen(
    sessionId: Long,
    onFinishWorkout: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: ActiveWorkoutViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // Initialize session
    LaunchedEffect(sessionId) {
        viewModel.initSession(sessionId)
    }

    // Keep screen on while workout is active
    val activity = context as? Activity
    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Back handling: prompt if workout is in progress
    BackHandler {
        if (uiState.workoutSummary != null) {
            onFinishWorkout()
        } else {
            // Minimize back to home without discarding (session stays in-progress in Room)
            onBack()
        }
    }

    // If workout summary is available, show celebration summary screen
    val summary = uiState.workoutSummary
    if (summary != null) {
        WorkoutSummaryView(
            summary = summary,
            onDone = onFinishWorkout
        )
        return
    }

    if (uiState.isLoading && uiState.sessionWithExercises == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CharcoalBackground),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = RepwiseLime)
        }
        return
    }

    val session = uiState.sessionWithExercises?.session
    val exercises = uiState.sessionWithExercises?.exercises ?: emptyList()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .padding(WindowInsets.statusBars.asPaddingValues())
            .testTag("screen_active_workout")
    ) {
        // Fullscreen Active Top Bar
        ActiveTopBar(
            title = session?.dayName ?: "Workout",
            elapsedSeconds = uiState.elapsedSeconds,
            onBack = onBack,
            onFinish = { viewModel.promptFinish() },
            onDiscard = { viewModel.promptDiscard() }
        )

        // Check if any completed set exists in this session
        val hasCompletedSets = exercises.any { se -> se.sets.any { it.completedAt != null } }
        val showWarmup = uiState.warmupDrills.isNotEmpty() && !hasCompletedSets

        // Exercise List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(RepwiseSpacing.md),
            verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
        ) {
            // Warm-up Card as first item
            if (showWarmup) {
                item(key = "warmup_card") {
                    WarmupCard(
                        status = uiState.warmupStatus,
                        drills = uiState.warmupDrills,
                        currentIndex = uiState.warmupIndex,
                        secondsRemaining = uiState.warmupSecondsRemaining,
                        catalogMap = uiState.catalogMap,
                        onStart = { viewModel.startWarmup() },
                        onNext = { viewModel.nextDrill() },
                        onBack = { viewModel.previousDrill() },
                        onSkip = { viewModel.skipWarmup() },
                        onRedo = { viewModel.redoWarmup() }
                    )
                }
            }

            // Exercise Cards
            itemsIndexed(
                items = exercises,
                key = { _, item -> item.exercise.id }
            ) { _, sessionExercise ->
                val exId = sessionExercise.exercise.exerciseId
                val catalogItem = uiState.catalogMap[exId]
                val prevPerf = uiState.previousPerformanceMap[exId]
                val isExpanded = uiState.expandedExerciseId == exId

                ActiveExerciseCard(
                    sessionExercise = sessionExercise,
                    catalogItem = catalogItem,
                    previousPerformance = prevPerf,
                    isExpanded = isExpanded,
                    onToggleExpand = { viewModel.setExpandedExercise(exId) },
                    onToggleSetDone = { setLog, restSec -> viewModel.toggleSetDone(setLog, restSec) },
                    onUpdateSetWeight = { setLog, weight -> viewModel.updateSetWeight(setLog, weight) },
                    onUpdateSetReps = { setLog, reps -> viewModel.updateSetReps(setLog, reps) },
                    onToggleWarmup = { setLog -> viewModel.toggleSetWarmup(setLog) },
                    onAddSet = {
                        val lastSet = sessionExercise.sets.lastOrNull()
                        val w = lastSet?.weightKg ?: prevPerf?.defaultWeightKg ?: 0.0
                        val r = lastSet?.reps ?: prevPerf?.defaultReps ?: 10
                        viewModel.addSet(sessionExercise.exercise.id, w, r)
                    },
                    onDeleteSet = { setLogId -> viewModel.deleteSet(setLogId) },
                    onUpdateNote = { note -> viewModel.updateExerciseNote(sessionExercise.exercise.id, note) },
                    onSubstitute = { viewModel.openSubstituteSheet(sessionExercise) },
                    onRemoveExercise = { viewModel.removeExercise(sessionExercise.exercise.id) },
                    isSetPR = { setLog -> viewModel.isSetPR(setLog, exId) }
                )
            }

            // "+ Add Exercise" Button
            item {
                SecondaryButton(
                    text = "+ Add Exercise",
                    onClick = { viewModel.openAddExercisePicker() },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = TextHighEmphasis,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_exercise_to_session_button")
                )
            }

            // Bottom Spacing for Rest Timer
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Rest Timer Floating Bottom Bar
        AnimatedVisibility(
            visible = uiState.restTimerEndTime != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            RestTimerBar(
                remainingSeconds = uiState.restSecondsRemaining,
                onAdd15 = { viewModel.addRestTime(15) },
                onMinus15 = { viewModel.subtractRestTime(15) },
                onSkip = { viewModel.skipRestTimer() }
            )
        }
    }

    // Substitute Alternatives Bottom Sheet
    val substituteTarget = uiState.substituteTarget
    if (substituteTarget != null) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.closeSubstituteSheet() },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CharcoalSurface,
            contentColor = TextHighEmphasis
        ) {
            SubstituteAlternativesSheet(
                currentExercise = uiState.catalogMap[substituteTarget.exercise.exerciseId],
                alternatives = uiState.substituteAlternatives,
                onSelectAlternative = { newExId -> viewModel.applySubstitute(newExId) },
                onDismiss = { viewModel.closeSubstituteSheet() }
            )
        }
    }

    // Add Exercise From Library Picker Sheet
    if (uiState.isAddExercisePickerOpen) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.closeAddExercisePicker() },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CharcoalSurface,
            contentColor = TextHighEmphasis
        ) {
            AddExercisePickerSheet(
                exercises = uiState.allCatalogExercises,
                onSelectExercise = { exId -> viewModel.addExerciseFromPicker(exId) },
                onDismiss = { viewModel.closeAddExercisePicker() }
            )
        }
    }

    // Finish Workout Confirmation Dialog
    if (uiState.showFinishConfirm) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissFinishPrompt() },
            title = { Text("Finish Workout?") },
            text = { Text("Great work! All completed sets will be recorded and personal records updated.") },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.confirmFinish() }
                ) {
                    Text("Finish", color = RepwiseLime, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissFinishPrompt() }) {
                    Text("Keep Training", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis,
            textContentColor = TextSecondary
        )
    }

    // Discard Workout Confirmation Dialog
    if (uiState.showDiscardConfirm) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissDiscardPrompt() },
            title = { Text("Discard Workout?") },
            text = { Text("Are you sure you want to discard this session? All logged sets will be discarded and excluded from history and PRs.") },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.confirmDiscard(onBack) }
                ) {
                    Text("Discard", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissDiscardPrompt() }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis,
            textContentColor = TextSecondary
        )
    }
}

@Composable
private fun ActiveTopBar(
    title: String,
    elapsedSeconds: Long,
    onBack: () -> Unit,
    onFinish: () -> Unit,
    onDiscard: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(CharcoalSurfaceElevated)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Minimize Workout",
                tint = TextHighEmphasis
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextHighEmphasis,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = RepwiseLime,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                Text(
                    text = Formatters.formatSecondsToTime(elapsedSeconds),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Finish Workout Button
            Text(
                text = "Finish",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = RepwiseOnLime,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(RepwiseLime)
                    .clickable(onClick = onFinish)
                    .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
                    .testTag(TestTags.FINISH_WORKOUT_BUTTON)
            )

            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Session Menu",
                        tint = TextSecondary
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(CharcoalSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("Discard Workout", color = DangerRed) },
                        onClick = {
                            showMenu = false
                            onDiscard()
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = DangerRed
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveExerciseCard(
    sessionExercise: SessionExerciseWithSets,
    catalogItem: CatalogExercise?,
    previousPerformance: PreviousPerformance?,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onToggleSetDone: (SetLogEntity, Int) -> Unit,
    onUpdateSetWeight: (SetLogEntity, Double) -> Unit,
    onUpdateSetReps: (SetLogEntity, Int) -> Unit,
    onToggleWarmup: (SetLogEntity) -> Unit,
    onAddSet: () -> Unit,
    onDeleteSet: (Long) -> Unit,
    onUpdateNote: (String) -> Unit,
    onSubstitute: () -> Unit,
    onRemoveExercise: () -> Unit,
    isSetPR: (SetLogEntity) -> Boolean
) {
    var showMenu by remember { mutableStateOf(false) }
    var noteText by remember(sessionExercise.exercise.note) {
        mutableStateOf(sessionExercise.exercise.note ?: "")
    }

    val restSec = catalogItem?.frameDurationMs?.toInt()?.let { 90 } ?: 90

    RepwiseCard(
        modifier = Modifier.testTag("exercise_card_${sessionExercise.exercise.exerciseId}")
    ) {
        // Exercise Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggleExpand),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = catalogItem?.name ?: "Exercise ${sessionExercise.exercise.exerciseId}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextHighEmphasis
                    )

                    if (sessionExercise.exercise.replacedExerciseId != null) {
                        Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                        Box(
                            modifier = Modifier
                                .clip(PillShape)
                                .background(RepwiseLimeMuted)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Substituted",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))

                Text(
                    text = "${catalogItem?.equipment ?: "Equipment"} • Target: ${catalogItem?.target ?: "Muscles"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                // "Previous" Line: reps x weight from the last COMPLETED session
                if (previousPerformance != null) {
                    Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = RepwiseLime,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Previous: ${previousPerformance.summaryText}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RepwiseLime
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onToggleExpand) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = TextSecondary
                    )
                }

                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options",
                            tint = TextSecondary
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(CharcoalSurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Substitute Exercise", color = TextHighEmphasis) },
                            onClick = {
                                showMenu = false
                                onSubstitute()
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = null,
                                    tint = RepwiseLime
                                )
                            }
                        )

                        DropdownMenuItem(
                            text = { Text("Remove Exercise", color = DangerRed) },
                            onClick = {
                                showMenu = false
                                onRemoveExercise()
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = DangerRed
                                )
                            }
                        )
                    }
                }
            }
        }

        // Expanded Animation Preview
        AnimatedVisibility(visible = isExpanded) {
            Column {
                Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                val frameList = if (catalogItem?.hasAnimation == true) {
                    listOf(
                        catalogItem.frame00Path!!,
                        catalogItem.frame01Path!!,
                        catalogItem.frame02Path!!
                    )
                } else null

                ExerciseAnimation(
                    frames = frameList,
                    sequence = catalogItem?.sequence ?: listOf(0, 1, 2, 1),
                    frameDurationMs = catalogItem?.frameDurationMs ?: 180L,
                    speedMultiplier = 0.5f,
                    exerciseName = catalogItem?.name ?: "",
                    targetMuscle = catalogItem?.target ?: "",
                    secondaryMuscles = catalogItem?.secondaryMuscles ?: emptyList(),
                    equipment = catalogItem?.equipment ?: "",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                )

                Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                // Exercise Note Field
                OutlinedTextField(
                    value = noteText,
                    onValueChange = {
                        noteText = it
                        onUpdateNote(it)
                    },
                    placeholder = { Text("Add exercise notes (form, seat height...)", color = TextTertiary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RepwiseLime,
                        unfocusedBorderColor = CharcoalBorderSubtle,
                        focusedTextColor = TextHighEmphasis,
                        unfocusedTextColor = TextHighEmphasis,
                        focusedContainerColor = CharcoalSurfaceElevated,
                        unfocusedContainerColor = CharcoalSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = RepwiseSpacing.xs, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SET",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = TextSecondary,
                modifier = Modifier.width(42.dp),
                textAlign = TextAlign.Center
            )
            Text(
                text = "WEIGHT (${WeightHelper.activeUnit.suffix})",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = TextSecondary,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )
            Text(
                text = "REPS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = TextSecondary,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )
            Text(
                text = "DONE",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = TextSecondary,
                modifier = Modifier.width(52.dp),
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        // Sets Rows
        sessionExercise.sets.forEachIndexed { index, setLog ->
            ActiveSetRow(
                setLog = setLog,
                setNumber = index + 1,
                isPR = isSetPR(setLog),
                onToggleDone = { onToggleSetDone(setLog, restSec) },
                onUpdateWeight = { onUpdateSetWeight(setLog, it) },
                onUpdateReps = { onUpdateSetReps(setLog, it) },
                onToggleWarmup = { onToggleWarmup(setLog) },
                onDelete = { onDeleteSet(setLog.id) }
            )
            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        // "+ Add Set" button
        SecondaryButton(
            text = "+ Add Set",
            onClick = onAddSet,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("add_set_button_${sessionExercise.exercise.exerciseId}")
        )
    }
}

@Composable
private fun ActiveSetRow(
    setLog: SetLogEntity,
    setNumber: Int,
    isPR: Boolean,
    onToggleDone: () -> Unit,
    onUpdateWeight: (Double) -> Unit,
    onUpdateReps: (Int) -> Unit,
    onToggleWarmup: () -> Unit,
    onDelete: () -> Unit
) {
    val isCompleted = setLog.completedAt != null
    val focusManager = LocalFocusManager.current

    var weightInput by remember(setLog.weightKg) {
        mutableStateOf(WeightHelper.format(setLog.weightKg, includeUnit = false))
    }
    var repsInput by remember(setLog.reps) {
        mutableStateOf(setLog.reps.toString())
    }

    val rowBg = when {
        isCompleted -> RepwiseLimeMuted
        setLog.isWarmup -> CharcoalSurfaceElevated.copy(alpha = 0.5f)
        else -> CharcoalSurfaceElevated
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(rowBg)
            .border(
                1.dp,
                if (isCompleted) RepwiseLime.copy(alpha = 0.4f) else CharcoalBorderSubtle,
                RoundedCornerShape(8.dp)
            )
            .padding(horizontal = RepwiseSpacing.xs, vertical = RepwiseSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Set Index / Warmup Indicator
        Column(
            modifier = Modifier
                .width(42.dp)
                .clickable(onClick = onToggleWarmup),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (setLog.isWarmup) "W" else "$setNumber",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black),
                color = if (setLog.isWarmup) WarningAmber else if (isCompleted) RepwiseLime else TextHighEmphasis
            )

            if (isPR && isCompleted) {
                Box(
                    modifier = Modifier
                        .clip(PillShape)
                        .background(WarningAmber)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "PR",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
                        color = Color.Black,
                        fontSize = 9.sp
                    )
                }
            }
        }

        // Weight Input
        OutlinedTextField(
            value = weightInput,
            onValueChange = {
                weightInput = it
                val d = it.toDoubleOrNull()
                if (d != null) onUpdateWeight(WeightHelper.toKg(d))
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Decimal,
                imeAction = ImeAction.Next
            ),
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                color = TextHighEmphasis
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RepwiseLime,
                unfocusedBorderColor = Color.Transparent,
                focusedContainerColor = CharcoalSurface,
                unfocusedContainerColor = CharcoalSurface
            ),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp)
                .height(48.dp)
        )

        // Reps Input
        OutlinedTextField(
            value = repsInput,
            onValueChange = {
                repsInput = it
                val r = it.toIntOrNull()
                if (r != null) onUpdateReps(r)
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                color = TextHighEmphasis
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RepwiseLime,
                unfocusedBorderColor = Color.Transparent,
                focusedContainerColor = CharcoalSurface,
                unfocusedContainerColor = CharcoalSurface
            ),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp)
                .height(48.dp)
        )

        // One-Tap Big Check Button
        Box(
            modifier = Modifier
                .width(52.dp)
                .height(48.dp),
            contentAlignment = Alignment.Center
        ) {
            IconButton(
                onClick = onToggleDone,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isCompleted) RepwiseLime else CharcoalBorder)
                    .testTag("check_set_${setLog.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = if (isCompleted) "Set Done" else "Mark Set Done",
                    tint = if (isCompleted) RepwiseOnLime else TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

/**
 * Rest timer floating bottom bar:
 * Stored end timestamp, survive rotation/background, +15s / -15s / Skip.
 */
@Composable
private fun RestTimerBar(
    remainingSeconds: Int,
    onAdd15: () -> Unit,
    onMinus15: () -> Unit,
    onSkip: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm)
            .padding(WindowInsets.navigationBars.asPaddingValues()),
        shape = RoundedCornerShape(16.dp),
        color = CharcoalSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, RepwiseLime.copy(alpha = 0.5f)),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = RepwiseLime,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                Column {
                    Text(
                        text = "REST TIMER",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextSecondary
                    )
                    Text(
                        text = Formatters.formatSecondsToTime(remainingSeconds.toLong()),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        ),
                        color = RepwiseLime
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)) {
                // -15s
                Text(
                    text = "-15s",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalSurface)
                        .clickable(onClick = onMinus15)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                )

                // +15s
                Text(
                    text = "+15s",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalSurface)
                        .clickable(onClick = onAdd15)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                )

                // Skip
                Text(
                    text = "Skip",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = DangerRed,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalSurface)
                        .clickable(onClick = onSkip)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                )
            }
        }
    }
}

/**
 * Exercise Substitute Bottom Sheet:
 * Lists alternatives matching normalized target & movementPattern, ranked by shared secondary muscles.
 */
@Composable
private fun SubstituteAlternativesSheet(
    currentExercise: CatalogExercise?,
    alternatives: List<CatalogExercise>,
    onSelectAlternative: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(RepwiseSpacing.md)
            .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
    ) {
        Text(
            text = "Substitute Exercise",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = TextHighEmphasis
        )

        Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))

        Text(
            text = "Replacing: ${currentExercise?.name ?: "Exercise"} (${currentExercise?.target} • ${currentExercise?.movementPattern ?: "Pattern"})",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

        if (alternatives.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = RepwiseSpacing.xl),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No direct alternatives found with the same target muscle and movement pattern.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp),
                verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
            ) {
                items(alternatives) { alt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CharcoalSurfaceElevated)
                            .clickable { onSelectAlternative(alt.id) }
                            .padding(RepwiseSpacing.md),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = alt.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextHighEmphasis
                            )
                            Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                            Text(
                                text = "${alt.equipment} • Secondaries: ${alt.secondaryMuscles.joinToString(", ").ifEmpty { "None" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Select",
                            tint = RepwiseLime
                        )
                    }
                }
            }
        }
    }
}

/**
 * Exercise Picker Sheet for adding exercises to the active workout.
 */
@Composable
private fun AddExercisePickerSheet(
    exercises: List<CatalogExercise>,
    onSelectExercise: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = remember(searchQuery, exercises) {
        if (searchQuery.isBlank()) exercises
        else exercises.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                it.target.contains(searchQuery, ignoreCase = true) ||
                it.equipment.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(RepwiseSpacing.md)
            .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
    ) {
        Text(
            text = "Add Exercise",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = TextHighEmphasis
        )

        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by name, muscle, equipment...", color = TextTertiary) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = TextSecondary
                )
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RepwiseLime,
                unfocusedBorderColor = CharcoalBorderSubtle,
                focusedTextColor = TextHighEmphasis,
                unfocusedTextColor = TextHighEmphasis,
                focusedContainerColor = CharcoalSurfaceElevated,
                unfocusedContainerColor = CharcoalSurfaceElevated
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(350.dp),
            verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
        ) {
            items(filtered) { ex ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CharcoalSurfaceElevated)
                        .clickable { onSelectExercise(ex.id) }
                        .padding(RepwiseSpacing.md),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = ex.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                        Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                        Text(
                            text = "${ex.equipment} • Target: ${ex.target}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add",
                        tint = RepwiseLime
                    )
                }
            }
        }
    }
}

/**
 * Workout Summary View shown upon finishing a workout.
 */
@Composable
private fun WorkoutSummaryView(
    summary: WorkoutSummaryData,
    onDone: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .padding(WindowInsets.statusBars.asPaddingValues())
            .padding(RepwiseSpacing.md),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.lg)
        ) {
            Spacer(modifier = Modifier.height(RepwiseSpacing.md))

            // Celebration Badge
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(RepwiseLimeMuted)
                    .align(Alignment.CenterHorizontally),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = RepwiseLime,
                    modifier = Modifier.size(40.dp)
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "WORKOUT COMPLETE!",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    ),
                    color = RepwiseLime
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                Text(
                    text = summary.dayName,
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )
            }

            // Stat Cards Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
            ) {
                StatCard(
                    title = "DURATION",
                    value = Formatters.formatSecondsToTime(summary.durationSeconds),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "EXERCISES",
                    value = "${summary.totalExercises}",
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
            ) {
                StatCard(
                    title = "SETS COMPLETED",
                    value = "${summary.totalSetsCompleted}",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "TOTAL VOLUME",
                    value = WeightHelper.format(summary.totalVolumeKg),
                    modifier = Modifier.weight(1f)
                )
            }

            // Personal Records Section
            if (summary.newRecords.isNotEmpty()) {
                RepwiseCard {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "${summary.newRecords.size} New Personal Records!",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                    }

                    Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                    summary.newRecords.forEach { pr ->
                        val recordLabel = when (pr.type) {
                            PersonalRecordType.HEAVIEST_WEIGHT -> "Heaviest Weight: ${WeightHelper.format(pr.value)}"
                            PersonalRecordType.BEST_E1RM -> "Best Estimated 1RM: ${WeightHelper.format(pr.value)}"
                            PersonalRecordType.BEST_REPS_AT_WEIGHT -> "Best Reps at Weight: ${pr.value.toInt()} reps"
                            else -> "Record: ${pr.value}"
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(WarningAmber)
                            )
                            Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                            Text(
                                text = recordLabel,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextHighEmphasis
                            )
                        }
                    }
                }
            }
        }

        // Return to Home / Finish Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
        ) {
            PrimaryButton(
                text = "Done",
                onClick = onDone,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CharcoalSurfaceElevated)
            .border(1.dp, CharcoalBorderSubtle, RoundedCornerShape(12.dp))
            .padding(RepwiseSpacing.md)
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                color = TextHighEmphasis
            )
        }
    }
}
