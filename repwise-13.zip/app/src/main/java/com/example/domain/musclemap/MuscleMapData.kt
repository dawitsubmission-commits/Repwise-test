package com.example.domain.musclemap

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class MusclePart(
    val slug: String,
    val paths: List<String>
)

data class BodyView(
    val viewBox: String,
    val parts: List<MusclePart>
)

data class MuscleMap(
    val front: BodyView,
    val back: BodyView
)

object MuscleMapData {

    @Volatile
    private var cachedMap: MuscleMap? = null

    fun getCached(): MuscleMap? = cachedMap

    suspend fun get(context: Context): MuscleMap? {
        cachedMap?.let { return it }

        return withContext(Dispatchers.IO) {
            cachedMap?.let { return@withContext it }
            try {
                val jsonString = context.assets.open("musclemap/body-parts.json").use { stream ->
                    stream.bufferedReader().use { it.readText() }
                }
                val root = JSONObject(jsonString)
                val male = root.optJSONObject("male") ?: return@withContext null
                val frontObj = male.optJSONObject("front") ?: return@withContext null
                val backObj = male.optJSONObject("back") ?: return@withContext null

                val frontView = parseBodyView(frontObj) ?: return@withContext null
                val backView = parseBodyView(backObj) ?: return@withContext null

                val map = MuscleMap(front = frontView, back = backView)
                cachedMap = map
                map
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun parseBodyView(obj: JSONObject): BodyView? {
        val viewBox = obj.optString("viewBox", "")
        val partsArray = obj.optJSONArray("parts") ?: return null
        val parts = mutableListOf<MusclePart>()
        for (i in 0 until partsArray.length()) {
            val partObj = partsArray.optJSONObject(i) ?: continue
            val slug = partObj.optString("slug", "")
            val pathsArray = partObj.optJSONArray("paths") ?: continue
            val paths = mutableListOf<String>()
            for (j in 0 until pathsArray.length()) {
                val path = pathsArray.optString(j, "")
                if (path.isNotEmpty()) {
                    paths.add(path)
                }
            }
            parts.add(MusclePart(slug, paths))
        }
        return BodyView(viewBox, parts)
    }
}
