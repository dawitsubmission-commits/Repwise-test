package com.example.domain.musclemap

object MuscleSlugMapper {

    private val nameToSlugMap: Map<String, String> = mapOf(
        // chest
        "chest" to "chest",
        "pectorals" to "chest",
        "pectoral" to "chest",

        // obliques
        "serratus anterior" to "obliques",
        "obliques" to "obliques",

        // deltoids
        "shoulders" to "deltoids",
        "deltoids" to "deltoids",
        "rear deltoids" to "deltoids",
        "delts" to "deltoids",
        "delt" to "deltoids",

        // upper-back
        "lats" to "upper-back",
        "upper back" to "upper-back",
        "rhomboids" to "upper-back",
        "back" to "upper-back",

        // lower-back
        "spine" to "lower-back",
        "lower back" to "lower-back",

        // trapezius
        "trapezius" to "trapezius",
        "levator scapulae" to "trapezius",
        "traps" to "trapezius",
        "trap" to "trapezius",

        // biceps
        "biceps" to "biceps",
        "brachialis" to "biceps",

        // triceps
        "triceps" to "triceps",

        // forearm
        "forearms" to "forearm",
        "forearm" to "forearm",
        "wrists" to "forearm",
        "hands" to "forearm",
        "grip muscles" to "forearm",

        // abs
        "core" to "abs",
        "abs" to "abs",
        "ab" to "abs",
        "abdominals" to "abs",
        "abdominal" to "abs",
        "lower abs" to "abs",

        // quadriceps
        "quadriceps" to "quadriceps",
        "quads" to "quadriceps",
        "quad" to "quadriceps",

        // hamstring
        "hamstrings" to "hamstring",
        "hamstring" to "hamstring",

        // gluteal
        "glutes" to "gluteal",
        "glute" to "gluteal",
        "abductors" to "gluteal",

        // calves
        "calves" to "calves",
        "calf" to "calves",
        "soleus" to "calves",

        // tibialis
        "shins" to "tibialis",
        "shin" to "tibialis",

        // adductors
        "adductors" to "adductors",
        "adductor" to "adductors",
        "groin" to "adductors",
        "inner thighs" to "adductors",

        // neck
        "neck" to "neck"
    )

    val NON_HIGHLIGHTABLE_SLUGS: Set<String> = setOf(
        "head", "hair", "hands", "feet", "ankles", "knees"
    )

    fun mapToSlug(muscleName: String?): String? {
        if (muscleName == null) return null
        val trimmed = muscleName.trim().lowercase()
        return nameToSlugMap[trimmed]
    }

    fun mapToSlugs(muscleNames: Iterable<String>): Set<String> {
        val result = mutableSetOf<String>()
        for (name in muscleNames) {
            val slug = mapToSlug(name)
            if (slug != null) {
                result.add(slug)
            }
        }
        return result
    }

    data class HighlightedSlugs(
        val primarySlugs: Set<String>,
        val secondarySlugs: Set<String>
    )

    fun resolveHighlights(
        primaryMuscle: String,
        secondaryMuscles: List<String>
    ): HighlightedSlugs {
        val primarySlug = mapToSlug(primaryMuscle)
        val primarySet = if (primarySlug != null && primarySlug !in NON_HIGHLIGHTABLE_SLUGS) {
            setOf(primarySlug)
        } else {
            emptySet()
        }

        val allSecondarySlugs = mapToSlugs(secondaryMuscles)
        val filteredSecondary = allSecondarySlugs
            .filter { it !in NON_HIGHLIGHTABLE_SLUGS }
            .toSet() - primarySet

        return HighlightedSlugs(
            primarySlugs = primarySet,
            secondarySlugs = filteredSecondary
        )
    }
}
