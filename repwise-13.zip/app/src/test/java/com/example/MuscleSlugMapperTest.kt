package com.example

import com.example.domain.musclemap.MuscleSlugMapper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MuscleSlugMapperTest {

    @Test
    fun `canonical muscle names map to correct slugs`() {
        assertEquals("chest", MuscleSlugMapper.mapToSlug("chest"))
        assertEquals("obliques", MuscleSlugMapper.mapToSlug("serratus anterior"))
        assertEquals("deltoids", MuscleSlugMapper.mapToSlug("shoulders"))
        assertEquals("deltoids", MuscleSlugMapper.mapToSlug("deltoids"))
        assertEquals("deltoids", MuscleSlugMapper.mapToSlug("rear deltoids"))
        assertEquals("upper-back", MuscleSlugMapper.mapToSlug("lats"))
        assertEquals("upper-back", MuscleSlugMapper.mapToSlug("upper back"))
        assertEquals("upper-back", MuscleSlugMapper.mapToSlug("rhomboids"))
        assertEquals("upper-back", MuscleSlugMapper.mapToSlug("back"))
        assertEquals("lower-back", MuscleSlugMapper.mapToSlug("spine"))
        assertEquals("lower-back", MuscleSlugMapper.mapToSlug("lower back"))
        assertEquals("trapezius", MuscleSlugMapper.mapToSlug("trapezius"))
        assertEquals("trapezius", MuscleSlugMapper.mapToSlug("levator scapulae"))
        assertEquals("biceps", MuscleSlugMapper.mapToSlug("biceps"))
        assertEquals("biceps", MuscleSlugMapper.mapToSlug("brachialis"))
        assertEquals("triceps", MuscleSlugMapper.mapToSlug("triceps"))
        assertEquals("forearm", MuscleSlugMapper.mapToSlug("forearms"))
        assertEquals("forearm", MuscleSlugMapper.mapToSlug("wrists"))
        assertEquals("forearm", MuscleSlugMapper.mapToSlug("hands"))
        assertEquals("forearm", MuscleSlugMapper.mapToSlug("grip muscles"))
        assertEquals("abs", MuscleSlugMapper.mapToSlug("core"))
        assertEquals("abs", MuscleSlugMapper.mapToSlug("abdominals"))
        assertEquals("abs", MuscleSlugMapper.mapToSlug("lower abs"))
        assertEquals("obliques", MuscleSlugMapper.mapToSlug("obliques"))
        assertEquals("quadriceps", MuscleSlugMapper.mapToSlug("quadriceps"))
        assertEquals("hamstring", MuscleSlugMapper.mapToSlug("hamstrings"))
        assertEquals("gluteal", MuscleSlugMapper.mapToSlug("glutes"))
        assertEquals("gluteal", MuscleSlugMapper.mapToSlug("abductors"))
        assertEquals("calves", MuscleSlugMapper.mapToSlug("calves"))
        assertEquals("calves", MuscleSlugMapper.mapToSlug("soleus"))
        assertEquals("tibialis", MuscleSlugMapper.mapToSlug("shins"))
        assertEquals("adductors", MuscleSlugMapper.mapToSlug("adductors"))
        assertEquals("adductors", MuscleSlugMapper.mapToSlug("groin"))
        assertEquals("neck", MuscleSlugMapper.mapToSlug("neck"))
    }

    @Test
    fun `raw shorthand names map to correct slugs`() {
        assertEquals("chest", MuscleSlugMapper.mapToSlug("pectorals"))
        assertEquals("deltoids", MuscleSlugMapper.mapToSlug("delts"))
        assertEquals("quadriceps", MuscleSlugMapper.mapToSlug("quads"))
        assertEquals("trapezius", MuscleSlugMapper.mapToSlug("traps"))
        assertEquals("abs", MuscleSlugMapper.mapToSlug("abs"))
    }

    @Test
    fun `case insensitivity and whitespace trimming work`() {
        assertEquals("chest", MuscleSlugMapper.mapToSlug("  CHEST  "))
        assertEquals("deltoids", MuscleSlugMapper.mapToSlug("Shoulders"))
        assertEquals("quadriceps", MuscleSlugMapper.mapToSlug("QuAdS"))
        assertEquals("abs", MuscleSlugMapper.mapToSlug("  LOWER ABS "))
    }

    @Test
    fun `unknown muscle names are ignored and return null`() {
        assertNull(MuscleSlugMapper.mapToSlug("unknown_muscle"))
        assertNull(MuscleSlugMapper.mapToSlug(""))
        assertNull(MuscleSlugMapper.mapToSlug(null))
        assertEquals(emptySet<String>(), MuscleSlugMapper.mapToSlugs(listOf("unknown1", "unknown2")))
    }

    @Test
    fun `primary wins over secondary when both resolve to same slug`() {
        val highlights = MuscleSlugMapper.resolveHighlights(
            primaryMuscle = "chest",
            secondaryMuscles = listOf("triceps", "pectorals", "shoulders")
        )

        assertEquals(setOf("chest"), highlights.primarySlugs)
        // "pectorals" maps to "chest", which should be removed because "chest" is primary
        assertEquals(setOf("triceps", "deltoids"), highlights.secondarySlugs)
    }

    @Test
    fun `non-highlightable slugs are never highlighted`() {
        assertTrue(MuscleSlugMapper.NON_HIGHLIGHTABLE_SLUGS.contains("head"))
        assertTrue(MuscleSlugMapper.NON_HIGHLIGHTABLE_SLUGS.contains("hair"))
        assertTrue(MuscleSlugMapper.NON_HIGHLIGHTABLE_SLUGS.contains("hands"))
        assertTrue(MuscleSlugMapper.NON_HIGHLIGHTABLE_SLUGS.contains("feet"))
        assertTrue(MuscleSlugMapper.NON_HIGHLIGHTABLE_SLUGS.contains("ankles"))
        assertTrue(MuscleSlugMapper.NON_HIGHLIGHTABLE_SLUGS.contains("knees"))

        val highlights = MuscleSlugMapper.resolveHighlights(
            primaryMuscle = "head",
            secondaryMuscles = listOf("hair", "feet", "chest")
        )

        // Neither head nor feet can be in highlighted sets
        assertTrue(highlights.primarySlugs.isEmpty())
        assertEquals(setOf("chest"), highlights.secondarySlugs)
    }
}
