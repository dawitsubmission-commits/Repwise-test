package com.example

import com.example.domain.EssentialExercises
import com.example.domain.models.CatalogExercise
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EssentialsFilterTest {

    private fun createExercise(
        id: String,
        name: String,
        target: String = "chest",
        secondaryMuscles: List<String> = emptyList(),
        equipment: String = "dumbbell",
        bodyPart: String = "chest"
    ) = CatalogExercise(
        id = id,
        name = name,
        bodyPart = bodyPart,
        equipment = equipment,
        target = target,
        secondaryMuscles = secondaryMuscles
    )

    @Test
    fun `Essentials mode keeps only the listed IDs when essentials exist in catalog`() {
        // "0662" (push-up) and "0652" (pull-up) are in EssentialExercises.ids
        // "9991" and "9992" are arbitrary non-essential IDs
        val fakeExercises = listOf(
            createExercise(id = "0662", name = "Push-up", target = "chest", equipment = "body weight"),
            createExercise(id = "0652", name = "Pull-up", target = "lats", equipment = "body weight"),
            createExercise(id = "9991", name = "Obscure Exercise A", target = "chest", equipment = "cable"),
            createExercise(id = "9992", name = "Obscure Exercise B", target = "biceps", equipment = "dumbbell")
        )

        val result = EssentialExercises.filterExercises(
            allExercises = fakeExercises,
            showAll = false
        )

        assertEquals(2, result.size)
        assertEquals(listOf("0662", "0652"), result.map { it.id })
    }

    @Test
    fun `All mode keeps all exercises regardless of essential status`() {
        val fakeExercises = listOf(
            createExercise(id = "0662", name = "Push-up"),
            createExercise(id = "9991", name = "Obscure Exercise A"),
            createExercise(id = "9992", name = "Obscure Exercise B")
        )

        val result = EssentialExercises.filterExercises(
            allExercises = fakeExercises,
            showAll = true
        )

        assertEquals(3, result.size)
        assertEquals(listOf("0662", "9991", "9992"), result.map { it.id })
    }

    @Test
    fun `zero-match fallback returns all exercises when no essentials exist in catalog`() {
        // Catalog only contains non-essential IDs (e.g. preview starter set with disjoint IDs)
        val nonEssentialExercises = listOf(
            createExercise(id = "9991", name = "Custom Movement 1"),
            createExercise(id = "9992", name = "Custom Movement 2"),
            createExercise(id = "9993", name = "Custom Movement 3")
        )

        val result = EssentialExercises.filterExercises(
            allExercises = nonEssentialExercises,
            showAll = false
        )

        // Must automatically fall back to showing all exercises
        assertEquals(3, result.size)
        assertEquals(listOf("9991", "9992", "9993"), result.map { it.id })
    }

    @Test
    fun `search query filter applies on top of essentials`() {
        val fakeExercises = listOf(
            createExercise(id = "0662", name = "Push-up"),
            createExercise(id = "0289", name = "Dumbbell Bench Press"),
            createExercise(id = "0025", name = "Barbell Bench Press"),
            createExercise(id = "9991", name = "Custom Incline Bench Press")
        )

        val result = EssentialExercises.filterExercises(
            allExercises = fakeExercises,
            showAll = false,
            query = "Bench Press"
        )

        // Only essential exercises matching "Bench Press"
        assertEquals(2, result.size)
        assertEquals(listOf("0289", "0025"), result.map { it.id })
    }

    @Test
    fun `muscle and equipment chip filters apply on top of essentials`() {
        val fakeExercises = listOf(
            createExercise(id = "0289", name = "Dumbbell Bench Press", target = "chest", equipment = "dumbbell"),
            createExercise(id = "0025", name = "Barbell Bench Press", target = "chest", equipment = "barbell"),
            createExercise(id = "0652", name = "Pull-up", target = "lats", equipment = "body weight"),
            createExercise(id = "0293", name = "Dumbbell Bent Over Row", target = "upper back", equipment = "dumbbell")
        )

        // Filter by muscle = "back" (which matches lats and upper back)
        val backResult = EssentialExercises.filterExercises(
            allExercises = fakeExercises,
            showAll = false,
            muscle = "back"
        )
        assertEquals(2, backResult.size)
        assertTrue(backResult.any { it.id == "0652" })
        assertTrue(backResult.any { it.id == "0293" })

        // Filter by muscle = "back" and equipment = "dumbbell"
        val backDumbbellResult = EssentialExercises.filterExercises(
            allExercises = fakeExercises,
            showAll = false,
            muscle = "back",
            equipment = "dumbbell"
        )
        assertEquals(1, backDumbbellResult.size)
        assertEquals("0293", backDumbbellResult.first().id)
    }

    @Test
    fun `equipment filter handles other equipment category`() {
        val fakeExercises = listOf(
            createExercise(id = "0662", name = "Push-up", equipment = "body weight"),
            createExercise(id = "0289", name = "Dumbbell Bench Press", equipment = "dumbbell"),
            createExercise(id = "0047", name = "Special Sandbag Press", equipment = "sandbag")
        )

        val otherResult = EssentialExercises.filterExercises(
            allExercises = fakeExercises,
            showAll = false,
            equipment = "other"
        )
        assertEquals(1, otherResult.size)
        assertEquals("0047", otherResult.first().id)
    }
}
