package com.example

import com.example.domain.planner.ExperienceLevel
import com.example.domain.planner.FitnessGoal
import com.example.domain.planner.MovementSlot
import com.example.domain.planner.PlanGenerator
import com.example.domain.planner.PlanGeneratorRequest
import com.example.domain.planner.TrainingLocation
import com.example.domain.planner.TrainingStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BodyPartSplitTest {

    @Test
    fun testAutoEqualsRequestWithoutStyle() {
        val reqDefault = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 2, 4, 5)
        )
        val reqExplicitAuto = reqDefault.copy(style = TrainingStyle.AUTO)

        val planDefault = PlanGenerator.generatePlan(reqDefault)
        val planAuto = PlanGenerator.generatePlan(reqExplicitAuto)

        assertNotNull(planDefault)
        assertEquals(planDefault, planAuto)
    }

    @Test
    fun testBodyPartExactDayNamesFor345Days() {
        // 3 days
        val req3 = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 3, 5),
            style = TrainingStyle.BODY_PART
        )
        val plan3 = PlanGenerator.generatePlan(req3)
        assertNotNull(plan3)
        assertEquals(
            listOf("Chest & Triceps", "Back & Biceps", "Legs & Shoulders"),
            plan3!!.days.map { it.dayName }
        )

        // 4 days
        val req4 = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 2, 4, 5),
            style = TrainingStyle.BODY_PART
        )
        val plan4 = PlanGenerator.generatePlan(req4)
        assertNotNull(plan4)
        assertEquals(
            listOf("Chest & Triceps", "Back & Biceps", "Legs", "Shoulders & Arms"),
            plan4!!.days.map { it.dayName }
        )

        // 5 days
        val req5 = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 2, 3, 5, 6),
            style = TrainingStyle.BODY_PART
        )
        val plan5 = PlanGenerator.generatePlan(req5)
        assertNotNull(plan5)
        assertEquals(
            listOf("Chest", "Back", "Legs", "Shoulders & Core", "Arms"),
            plan5!!.days.map { it.dayName }
        )
    }

    @Test
    fun testBodyPartWith2DaysFallsBackToFullBodyWithNote() {
        val req2 = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(2, 4),
            style = TrainingStyle.BODY_PART
        )
        val plan2 = PlanGenerator.generatePlan(req2)
        assertNotNull(plan2)
        assertEquals("Full Body Split", plan2!!.title)
        assertEquals(2, plan2.days.size)
        assertTrue(
            "Expected note about needing at least 3 training days",
            plan2.notes.any { it.contains("Body-Part Split needs at least 3 training days, so we used Full Body instead.") }
        )
    }

    @Test
    fun testBeginnerBodyPart5DaysCappedAt3WithNotesAndNo3ConsecutiveDays() {
        val req = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 2, 3, 4, 5), // Mon-Fri
            style = TrainingStyle.BODY_PART
        )
        val plan = PlanGenerator.generatePlan(req)
        assertNotNull(plan)
        assertEquals(3, plan!!.days.size)
        assertEquals("Body-Part Split", plan.title)
        assertTrue("Must contain BODY_PART_BEGINNER_NOTE", plan.notes.contains(PlanGenerator.BODY_PART_BEGINNER_NOTE))

        // Check no 3 consecutive training days
        val assignedDays = plan.days.map { it.assignedWeekday }.sorted()
        for (i in 0 until assignedDays.size - 2) {
            val d1 = assignedDays[i]
            val d2 = assignedDays[i + 1]
            val d3 = assignedDays[i + 2]
            assertFalse(
                "Must never have 3 consecutive training days: $assignedDays",
                d2 == d1 + 1 && d3 == d2 + 1
            )
        }
    }

    @Test
    fun testNoExerciseRepeatsWithinADay() {
        listOf(3, 4, 5).forEach { daysCount ->
            val weekdays = (1..daysCount).toList()
            val req = PlanGeneratorRequest(
                age = 25,
                experience = ExperienceLevel.ADVANCED,
                goal = FitnessGoal.BUILD_MUSCLE,
                location = TrainingLocation.GYM,
                equipmentKeys = setOf("full_gym"),
                chosenWeekdays = weekdays,
                style = TrainingStyle.BODY_PART
            )
            val plan = PlanGenerator.generatePlan(req)
            assertNotNull(plan)
            plan!!.days.forEach { day ->
                val exerciseIds = day.exercises.map { it.exerciseId }
                assertEquals(
                    "Duplicate exercises found in day ${day.dayName}: $exerciseIds",
                    exerciseIds.toSet().size,
                    exerciseIds.size
                )
            }
        }
    }

    @Test
    fun testPlanIsDeterministic() {
        val req = PlanGeneratorRequest(
            age = 30,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 3, 5),
            style = TrainingStyle.BODY_PART
        )
        val plan1 = PlanGenerator.generatePlan(req)
        val plan2 = PlanGenerator.generatePlan(req)
        assertEquals(plan1, plan2)
    }

    @Test
    fun testChestAndTricepsDaySlots() {
        val req = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 3, 5),
            style = TrainingStyle.BODY_PART
        )
        val plan = PlanGenerator.generatePlan(req)
        assertNotNull(plan)
        val chestTricepsDay = plan!!.days.firstOrNull { it.dayName == "Chest & Triceps" }
        assertNotNull(chestTricepsDay)
        assertTrue("Chest & Triceps day must have exercises", chestTricepsDay!!.exercises.isNotEmpty())
        chestTricepsDay.exercises.forEach { ex ->
            assertTrue(
                "Exercise ${ex.name} slot ${ex.slot} must be H_PUSH or TRICEPS",
                ex.slot == MovementSlot.H_PUSH || ex.slot == MovementSlot.TRICEPS
            )
        }
    }

    @Test
    fun testUpperLowerWith6DaysCappedAt4WithNote() {
        val req = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 2, 3, 4, 5, 6),
            style = TrainingStyle.UPPER_LOWER
        )
        val plan = PlanGenerator.generatePlan(req)
        assertNotNull(plan)
        assertEquals(4, plan!!.days.size)
        assertEquals("Upper / Lower Split", plan.title)
        assertTrue(
            "Expected note that Upper / Lower works with up to 4 training days",
            plan.notes.any { it.contains("Upper / Lower works with up to 4 training days, so we used 4.") }
        )
    }

    @Test
    fun testPushPullLegsWith2DaysFallsBackWithNote() {
        val req = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(2, 4),
            style = TrainingStyle.PUSH_PULL_LEGS
        )
        val plan = PlanGenerator.generatePlan(req)
        assertNotNull(plan)
        assertEquals("Full Body Split", plan!!.title)
        assertEquals(2, plan.days.size)
        assertTrue(
            "Expected note that Push / Pull / Legs needs at least 3 training days",
            plan.notes.any { it.contains("Push / Pull / Legs needs at least 3 training days, so we used Full Body instead.") }
        )
    }
}
