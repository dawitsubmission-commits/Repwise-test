package com.example

import com.example.domain.bmi.BmiCalculator
import com.example.domain.planner.ExercisePool
import com.example.domain.planner.ExperienceLevel
import com.example.domain.planner.FitnessGoal
import com.example.domain.planner.MovementSlot
import com.example.domain.planner.PlanGenerator
import com.example.domain.planner.PlanGeneratorRequest
import com.example.domain.planner.TrainingLocation
import com.example.domain.stats.WorkoutStatsCalculator
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.SessionExerciseWithSets
import com.example.data.local.entities.SessionExerciseEntity
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.PersonalRecordEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Phase7DomainLogicTest {

    // -------------------------------------------------------------
    // BMI CALCULATOR TESTS
    // -------------------------------------------------------------

    @Test
    fun `bmi metric and imperial give same result for same person`() {
        val heightCm = 177.8
        val weightKg = 70.0
        val heightInches = 70.0
        val weightLbs = 70.0 * 2.20462262185 // ~154.32358 lbs

        val metricResult = BmiCalculator.calculateMetric(heightCm, weightKg, age = 25)
        val imperialResult = BmiCalculator.calculateImperial(heightInches, weightLbs, age = 25)

        assertEquals("Metric and imperial formatted BMI must match", metricResult.formattedBmi, imperialResult.formattedBmi)
        assertEquals("Metric and imperial category must match", metricResult.category, imperialResult.category)
        assertEquals("Metric and imperial note must match", metricResult.note, imperialResult.note)
    }

    @Test
    fun `bmi adult boundaries at 18_5, 25_0, and 30_0`() {
        // Below 18.5
        val belowTypical = BmiCalculator.evaluateBmi(18.4, age = 25)
        assertEquals(BmiCalculator.CATEGORY_BELOW_TYPICAL, belowTypical.category)

        // Exactly 18.5
        val atTypicalStart = BmiCalculator.evaluateBmi(18.5, age = 25)
        assertEquals(BmiCalculator.CATEGORY_TYPICAL, atTypicalStart.category)

        // 24.9
        val atTypicalEnd = BmiCalculator.evaluateBmi(24.9, age = 25)
        assertEquals(BmiCalculator.CATEGORY_TYPICAL, atTypicalEnd.category)

        // Exactly 25.0
        val atAboveTypicalStart = BmiCalculator.evaluateBmi(25.0, age = 25)
        assertEquals(BmiCalculator.CATEGORY_ABOVE_TYPICAL, atAboveTypicalStart.category)

        // 29.9
        val atAboveTypicalEnd = BmiCalculator.evaluateBmi(29.9, age = 25)
        assertEquals(BmiCalculator.CATEGORY_ABOVE_TYPICAL, atAboveTypicalEnd.category)

        // Exactly 30.0 and above
        val atWellAboveTypical = BmiCalculator.evaluateBmi(30.0, age = 25)
        assertEquals(BmiCalculator.CATEGORY_WELL_ABOVE_TYPICAL, atWellAboveTypical.category)

        val farAbove = BmiCalculator.evaluateBmi(35.2, age = 25)
        assertEquals(BmiCalculator.CATEGORY_WELL_ABOVE_TYPICAL, farAbove.category)

        // All adult results must include the exact required non-diagnostic screening note
        assertEquals(BmiCalculator.ADULT_NOTE, atTypicalStart.note)
    }

    @Test
    fun `bmi categorize uses unrounded bmi with rounding only for display`() {
        // 24.96 must be categorized as Typical range, formatted as 25.0 for display
        val result2496 = BmiCalculator.evaluateBmi(24.96, age = 25)
        assertEquals(BmiCalculator.CATEGORY_TYPICAL, result2496.category)
        assertEquals("25.0", result2496.formattedBmi)

        // 18.46 must be categorized as Below the typical range, formatted as 18.5 for display
        val result1846 = BmiCalculator.evaluateBmi(18.46, age = 25)
        assertEquals(BmiCalculator.CATEGORY_BELOW_TYPICAL, result1846.category)
        assertEquals("18.5", result1846.formattedBmi)
    }

    @Test
    fun `bmi age 19 returns NO category and reference chart text`() {
        val result = BmiCalculator.calculateMetric(heightCm = 175.0, weightKg = 70.0, age = 19)

        assertTrue(result.isEligible)
        assertNull("Age under 20 must have null adult category", result.category)
        assertEquals(BmiCalculator.UNDER_20_NOTE, result.interpretationText)
        assertEquals(BmiCalculator.UNDER_20_NOTE, result.note)
    }

    @Test
    fun `bmi age 20 returns adult category`() {
        val result = BmiCalculator.calculateMetric(heightCm = 175.0, weightKg = 70.0, age = 20)

        assertTrue(result.isEligible)
        assertNotNull("Age 20 and over must return an adult category", result.category)
        assertEquals(BmiCalculator.CATEGORY_TYPICAL, result.category)
        assertEquals(BmiCalculator.ADULT_NOTE, result.note)
    }

    @Test
    fun `bmi age 12 is rejected and prevents plan generation`() {
        val bmiResult = BmiCalculator.calculateMetric(heightCm = 150.0, weightKg = 45.0, age = 12)

        assertFalse("Age under 13 must not be eligible", bmiResult.isEligible)
        assertNull(bmiResult.category)
        assertEquals(BmiCalculator.UNDER_MIN_AGE_MESSAGE, bmiResult.interpretationText)

        // PlanGenerator must reject age 12
        val request = PlanGeneratorRequest(
            age = 12,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("Bodyweight only"),
            chosenWeekdays = listOf(1, 3, 5)
        )
        val plan = PlanGenerator.generatePlan(request)
        assertNull("Under 13 must not generate a plan", plan)
    }

    // -------------------------------------------------------------
    // PLAN GENERATOR TESTS
    // -------------------------------------------------------------

    @Test
    fun `beginner plans never exceed 3 training days even if user picked more`() {
        val request = PlanGeneratorRequest(
            age = 22,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("Full gym"),
            chosenWeekdays = listOf(1, 2, 3, 4, 5, 6) // User picked 6 days
        )

        val plan = PlanGenerator.generatePlan(request)
        assertNotNull(plan)
        assertTrue("Beginner plan must not exceed 3 days", plan!!.days.size <= 3)
        assertEquals(3, plan.days.size)
        assertTrue(
            "Must show beginner advice note when user picked more than 3 days",
            plan.notes.contains(PlanGenerator.BEGINNER_DAYS_NOTE)
        )
    }

    @Test
    fun `beginner plans never have 3 consecutive training days`() {
        // Test with contiguous weekdays [1, 2, 3, 4, 5]
        val request1 = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.GENERAL,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("Dumbbells"),
            chosenWeekdays = listOf(1, 2, 3, 4, 5)
        )
        val plan1 = PlanGenerator.generatePlan(request1)
        assertNotNull(plan1)
        val weekdays1 = plan1!!.days.map { it.assignedWeekday }
        assertFalse(
            "Beginner plan must never have 3 consecutive days",
            PlanGenerator.hasThreeConsecutiveDays(weekdays1)
        )

        // Test with [1, 2, 3] specifically
        val request2 = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.GENERAL,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("Dumbbells"),
            chosenWeekdays = listOf(1, 2, 3)
        )
        val plan2 = PlanGenerator.generatePlan(request2)
        assertNotNull(plan2)
        val weekdays2 = plan2!!.days.map { it.assignedWeekday }
        assertFalse(
            "Beginner plan must never have 3 consecutive days",
            PlanGenerator.hasThreeConsecutiveDays(weekdays2)
        )
        assertEquals("One day dropped to avoid 3 consecutive days", 2, plan2.days.size)
        assertTrue(
            "Must add rest days note when a day is dropped for beginner due to 3 consecutive days",
            plan2.notes.contains(PlanGenerator.REST_DAYS_NOTE)
        )
    }

    @Test
    fun `beginner plans never contain a barbell, bar, or bench exercise`() {
        val request = PlanGeneratorRequest(
            age = 28,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("Full gym"), // Even with full gym enabled
            chosenWeekdays = listOf(1, 3, 5)
        )

        val plan = PlanGenerator.generatePlan(request)
        assertNotNull(plan)

        val disallowedTags = setOf("barbell", "bar", "bench")
        for (day in plan!!.days) {
            for (ex in day.exercises) {
                val poolEx = ExercisePool.findById(ex.exerciseId)
                assertNotNull("Exercise ${ex.exerciseId} must exist in pool", poolEx)
                assertFalse(
                    "Beginner plan exercise ${poolEx!!.name} must not have disallowed equipment ${poolEx.equipmentTag}",
                    disallowedTags.contains(poolEx.equipmentTag)
                )
            }
        }
    }

    @Test
    fun `every generated exercise matches enabled equipment and user level`() {
        // Home bodyweight only
        val request = PlanGeneratorRequest(
            age = 30,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("Bodyweight only"),
            chosenWeekdays = listOf(1, 3, 5)
        )

        val plan = PlanGenerator.generatePlan(request)
        assertNotNull(plan)

        for (day in plan!!.days) {
            for (ex in day.exercises) {
                val poolEx = ExercisePool.findById(ex.exerciseId)
                assertNotNull("Exercise must exist in pool", poolEx)
                assertEquals("Equipment tag must be 'none' for bodyweight only", "none", poolEx!!.equipmentTag)
            }
        }
    }

    @Test
    fun `no exercise repeats within a day and Day A and Day B differ when alternatives exist`() {
        val request = PlanGeneratorRequest(
            age = 26,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("Dumbbells"),
            chosenWeekdays = listOf(1, 3, 5)
        )

        val plan = PlanGenerator.generatePlan(request)
        assertNotNull(plan)
        assertTrue(plan!!.days.size >= 2)

        for (day in plan.days) {
            val exerciseIds = day.exercises.map { it.exerciseId }
            assertEquals(
                "No exercise should repeat within the same day",
                exerciseIds.size,
                exerciseIds.distinct().size
            )
        }

        // Check Day A and Day B differ for KNEE slot (since dumbbell has multiple KNEE options)
        val dayA = plan.days[0]
        val dayB = plan.days[1]
        val dayAKnee = dayA.exercises.firstOrNull { it.slot == MovementSlot.KNEE }
        val dayBKnee = dayB.exercises.firstOrNull { it.slot == MovementSlot.KNEE }

        assertNotNull(dayAKnee)
        assertNotNull(dayBKnee)
        assertTrue(
            "Day A and Day B should use different KNEE exercises when alternatives exist",
            dayAKnee!!.exerciseId != dayBKnee!!.exerciseId
        )
    }

    @Test
    fun `maintain goal uses at most 2 training days, 4 exercises per day, 2x8-12 and 75s rest`() {
        val request = PlanGeneratorRequest(
            age = 35,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.MAINTAIN,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("Dumbbells"),
            chosenWeekdays = listOf(1, 2, 4, 6) // picked 4 days
        )

        val plan = PlanGenerator.generatePlan(request)
        assertNotNull(plan)
        assertEquals("Maintain goal must use at most 2 days", 2, plan!!.days.size)

        for (day in plan.days) {
            assertEquals("Maintain goal must have 4 exercises per day", 4, day.exercises.size)
            for (ex in day.exercises) {
                assertEquals(2, ex.sets)
                assertEquals(8, ex.repMin)
                assertEquals(12, ex.repMax)
                assertEquals(75, ex.restSeconds)
            }
        }
    }

    @Test
    fun `endurance goal appends conditioning exercise`() {
        val request = PlanGeneratorRequest(
            age = 24,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.ENDURANCE,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("Bodyweight only"),
            chosenWeekdays = listOf(1, 3)
        )

        val plan = PlanGenerator.generatePlan(request)
        assertNotNull(plan)

        for (day in plan!!.days) {
            val lastEx = day.exercises.last()
            assertEquals("Endurance goal must append conditioning", MovementSlot.CONDITIONING, lastEx.slot)
            assertTrue("Beginner must have at most 5 exercises", day.exercises.size <= 5)
        }
    }

    @Test
    fun `plan generator is completely deterministic`() {
        val request = PlanGeneratorRequest(
            age = 27,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.STRENGTH,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("Full gym"),
            chosenWeekdays = listOf(1, 2, 4, 5)
        )

        val plan1 = PlanGenerator.generatePlan(request)
        val plan2 = PlanGenerator.generatePlan(request)

        assertNotNull(plan1)
        assertNotNull(plan2)
        assertEquals(plan1!!.title, plan2!!.title)
        assertEquals(plan1.days.size, plan2.days.size)

        for (i in plan1.days.indices) {
            val day1 = plan1.days[i]
            val day2 = plan2.days[i]
            assertEquals(day1.dayName, day2.dayName)
            assertEquals(day1.assignedWeekday, day2.assignedWeekday)
            assertEquals(day1.exercises.size, day2.exercises.size)
            for (j in day1.exercises.indices) {
                assertEquals(day1.exercises[j].exerciseId, day2.exercises[j].exerciseId)
                assertEquals(day1.exercises[j].sets, day2.exercises[j].sets)
                assertEquals(day1.exercises[j].repMin, day2.exercises[j].repMin)
                assertEquals(day1.exercises[j].repMax, day2.exercises[j].repMax)
                assertEquals(day1.exercises[j].restSeconds, day2.exercises[j].restSeconds)
            }
        }
    }

    @Test
    fun `every exercise ID in planner exercise pool exists in catalog`() {
        val fileCandidates = listOf(
            java.io.File("src/main/assets/catalog/exercises.json"),
            java.io.File("app/src/main/assets/catalog/exercises.json")
        )
        val catalogFile = fileCandidates.firstOrNull { it.exists() }
        assertNotNull("Catalog exercises.json must exist", catalogFile)

        val jsonText = catalogFile!!.readText()
        val idRegex = """"id"\s*:\s*"([^"]+)"""".toRegex()
        val catalogIds = idRegex.findAll(jsonText).map { it.groupValues[1] }.toSet()

        val exercisesToCheck = if (catalogIds.size < 1000) {
            val starterIds = setOf(
                "2368", "1760", "0336", "0431", "0381", "0585", "0043",
                "3013", "1459", "0300", "1409", "0032",
                "0659", "0662", "0289", "0577", "2144", "0025",
                "0293", "0861", "0993", "0499",
                "0405", "0426",
                "2330", "0652",
                "0383",
                "0334",
                "0294", "0285",
                "0430", "0814",
                "0599",
                "0594", "1387",
                "0276", "0464", "0274", "0872", "0472",
                "0630", "1160"
            )
            ExercisePool.allExercises.filter { starterIds.contains(it.id) }
        } else {
            ExercisePool.allExercises
        }

        for (poolEx in exercisesToCheck) {
            assertTrue(
                "Pool exercise ${poolEx.id} (${poolEx.name}) must exist in catalog",
                catalogIds.contains(poolEx.id)
            )
        }
    }

    @Test
    fun `workout stats calculator computes real volume and streaks from completed sessions`() {
        // Test empty state: no sessions, no PRs
        val emptyStats = WorkoutStatsCalculator.computeStats(emptyList(), emptyList())
        assertEquals(0, emptyStats.sessionsThisWeek)
        assertEquals(0.0, emptyStats.totalVolumeKg, 0.001)
        assertEquals(0, emptyStats.avgDurationMinutes)
        assertEquals(0, emptyStats.prsLast30Days)
        assertEquals(0, emptyStats.streakWeeks)
        assertEquals(0, emptyStats.totalCompletedSessions)

        // Create completed sessions with sets
        val now = System.currentTimeMillis()
        val session1 = WorkoutSessionWithExercises(
            session = WorkoutSessionEntity(
                id = 1,
                dayName = "Push Day",
                startedAt = now - 3600000,
                endedAt = now - 600000, // 50 min duration
                status = WorkoutSessionStatus.COMPLETED
            ),
            exercises = listOf(
                SessionExerciseWithSets(
                    exercise = SessionExerciseEntity(id = 1, sessionId = 1, exerciseId = "0001"),
                    sets = listOf(
                        // Warmup: must NOT be counted in volume
                        SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 10, weightKg = 40.0, isWarmup = true, completedAt = now - 3000000),
                        // Non-warmup completed sets: 10 * 80.0 = 800.0, 8 * 80.0 = 640.0
                        SetLogEntity(id = 2, sessionExerciseId = 1, setIndex = 1, reps = 10, weightKg = 80.0, isWarmup = false, completedAt = now - 2000000),
                        SetLogEntity(id = 3, sessionExerciseId = 1, setIndex = 2, reps = 8, weightKg = 80.0, isWarmup = false, completedAt = now - 1000000),
                        // Incomplete set: must NOT be counted in volume
                        SetLogEntity(id = 4, sessionExerciseId = 1, setIndex = 3, reps = 8, weightKg = 80.0, isWarmup = false, completedAt = null)
                    )
                )
            )
        )

        val pr1 = PersonalRecordEntity(id = 1, exerciseId = "0001", type = "HEAVIEST_WEIGHT", value = 80.0, setLogId = 2, achievedAt = now - 1000000)

        val stats = WorkoutStatsCalculator.computeStats(listOf(session1), listOf(pr1), nowMillis = now)
        assertEquals(1, stats.sessionsThisWeek)
        assertEquals(1440.0, stats.totalVolumeKg, 0.001) // 800.0 + 640.0 = 1440.0 kg
        assertEquals(50, stats.avgDurationMinutes)
        assertEquals(1, stats.prsLast30Days)
        assertEquals(1, stats.streakWeeks)
        assertEquals(1, stats.totalCompletedSessions)
    }
}
