package com.example

import com.example.domain.planner.ExercisePool
import com.example.domain.planner.ExperienceLevel
import com.example.domain.planner.FitnessGoal
import com.example.domain.planner.MinLevel
import com.example.domain.planner.PlanGenerator
import com.example.domain.planner.PlanGeneratorRequest
import com.example.domain.planner.TrainingLocation
import com.example.domain.planner.TrainingStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PoolExpansionTest {

    @Test
    fun `the pool has 91 rows`() {
        assertEquals("Exercise pool must have exactly 91 rows", 91, ExercisePool.allExercises.size)
    }

    @Test
    fun `no ID appears twice in the pool`() {
        val ids = ExercisePool.allExercises.map { it.id }
        val uniqueIds = ids.toSet()
        assertEquals("All 91 exercise IDs in the pool must be unique", 91, uniqueIds.size)
    }

    @Test
    fun `every ID is a 4-character String`() {
        for (exercise in ExercisePool.allExercises) {
            assertEquals("Exercise ID ${exercise.id} should have length 4", 4, exercise.id.length)
            assertTrue("Exercise ID ${exercise.id} should be numeric digits", exercise.id.all { it.isDigit() })
        }
    }

    @Test
    fun `null availableExerciseIds does not filter candidates`() {
        val requestWithNull = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.INTERMEDIATE,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 3, 5),
            style = TrainingStyle.FULL_BODY,
            availableExerciseIds = null
        )
        val plan = PlanGenerator.generatePlan(requestWithNull)
        assertNotNull("Plan should be generated when availableExerciseIds is null", plan)
        assertTrue(plan!!.days.isNotEmpty())
        val generatedIds = plan.days.flatMap { it.exercises }.map { it.exerciseId }.toSet()
        assertTrue("Generated exercises should be present", generatedIds.isNotEmpty())
    }

    @Test
    fun `availableExerciseIds filtering drops missing IDs`() {
        val allowedIds = setOf("0314", "1760", "3013", "0293", "0276")
        val request = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.GENERAL,
            location = TrainingLocation.HOME,
            equipmentKeys = setOf("dumbbell"),
            chosenWeekdays = listOf(1, 3),
            style = TrainingStyle.FULL_BODY,
            availableExerciseIds = allowedIds
        )
        val plan = PlanGenerator.generatePlan(request)
        assertNotNull(plan)
        val chosenIds = plan!!.days.flatMap { it.exercises }.map { it.exerciseId }
        for (id in chosenIds) {
            assertTrue("Generated exercise $id must be in allowed availableExerciseIds", allowedIds.contains(id))
        }

        val emptyRequest = PlanGeneratorRequest(
            age = 25,
            experience = ExperienceLevel.BEGINNER,
            goal = FitnessGoal.BUILD_MUSCLE,
            location = TrainingLocation.GYM,
            equipmentKeys = setOf("full_gym"),
            chosenWeekdays = listOf(1, 3, 5),
            availableExerciseIds = setOf("9999", "8888")
        )
        val emptyPlan = PlanGenerator.generatePlan(emptyRequest)
        assertTrue(emptyPlan == null || emptyPlan.days.all { it.exercises.isEmpty() })
    }

    @Test
    fun `a beginner never gets a barbell, bar, or bench exercise from the expanded pool`() {
        val barredEquipment = setOf("barbell", "bar", "bench")

        // 1. Verify pool data invariant: any exercise with barbell, bar, or bench requires MinLevel.I
        for (exercise in ExercisePool.allExercises) {
            if (barredEquipment.contains(exercise.equipmentTag)) {
                assertEquals(
                    "Exercise ${exercise.id} (${exercise.name}) with tag ${exercise.equipmentTag} must require intermediate level",
                    MinLevel.I,
                    exercise.minLevel
                )
            }
        }

        // 2. Verify planner behavior: beginner with full gym / all equipment selected never receives barred exercises
        for (style in TrainingStyle.values()) {
            val request = PlanGeneratorRequest(
                age = 28,
                experience = ExperienceLevel.BEGINNER,
                goal = FitnessGoal.BUILD_MUSCLE,
                location = TrainingLocation.GYM,
                equipmentKeys = setOf("none", "dumbbell", "band", "bar", "bench", "full_gym"),
                chosenWeekdays = listOf(1, 2, 3, 4, 5),
                style = style
            )
            val plan = PlanGenerator.generatePlan(request)
            if (plan != null) {
                for (day in plan.days) {
                    for (exercise in day.exercises) {
                        val poolEx = ExercisePool.findById(exercise.exerciseId)
                        assertNotNull(poolEx)
                        assertFalse(
                            "Beginner must not get ${poolEx!!.equipmentTag} exercise ${poolEx.name}",
                            barredEquipment.contains(poolEx.equipmentTag)
                        )
                    }
                }
            }
        }
    }
}
