package com.example.domain

import com.example.domain.models.CatalogExercise

object EssentialExercises {

    val ids: Set<String> = setOf(
        // chest (15)
        "0662", "0289", "0025", "0314", "0047", "0308", "0155", "0577", "2144", "0301", "0375", "0493", "0279", "0251", "0748",
        // back (14)
        "0652", "1326", "0197", "0198", "0861", "0293", "0027", "0499", "1350", "0238", "0573", "0378", "0032", "0406",
        // shoulders (8)
        "0405", "0426", "0091", "0334", "0310", "0178", "0603", "2137",
        // arms (14)
        "0294", "0285", "0031", "0313", "0868", "0447", "0372", "0241", "0201", "0351", "0814", "0060", "0259", "0333",
        // legs (21)
        "1760", "0043", "0042", "0760", "0585", "0586", "0599", "0336", "0431", "1459", "0085", "0300", "0381", "0770", "0413", "1375", "0594", "1379", "0196", "3013", "2368",
        // core (13)
        "0276", "0472", "0687", "0630", "0872", "0459", "0001", "0689", "0223", "0972", "1014", "0274", "0464"
    )

    private val backMuscles = setOf("lats", "upper back", "lower back", "rhomboids", "spine", "back")
    private val standardEquipments = setOf(
        "body weight",
        "dumbbell",
        "barbell",
        "cable",
        "resistance band",
        "leverage machine",
        "smith machine",
        "kettlebell"
    )

    /**
     * Pure filtering logic for exercises in the catalog.
     * When showAll is false, only exercises with IDs in [ids] are retained,
     * unless none of the exercises in allExercises match [ids] (fallback to all).
     * Then search query, muscle filter, and equipment filter are applied on top.
     */
    fun filterExercises(
        allExercises: List<CatalogExercise>,
        showAll: Boolean,
        query: String = "",
        muscle: String = "All",
        equipment: String = "All"
    ): List<CatalogExercise> {
        val baseList = if (showAll) {
            allExercises
        } else {
            val essentialsExist = allExercises.any { it.id in ids }
            if (essentialsExist) {
                allExercises.filter { it.id in ids }
            } else {
                // Fallback to all when no essential exercises exist in this build
                allExercises
            }
        }

        return baseList.filter { exercise ->
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                exercise.name.contains(query, ignoreCase = true)
            }

            val matchesMuscle = if (muscle.equals("All", ignoreCase = true)) {
                true
            } else if (muscle.equals("back", ignoreCase = true)) {
                exercise.target in backMuscles || exercise.secondaryMuscles.any { it in backMuscles }
            } else {
                exercise.target.equals(muscle, ignoreCase = true) ||
                    exercise.secondaryMuscles.any { it.equals(muscle, ignoreCase = true) }
            }

            val matchesEquipment = if (equipment.equals("All", ignoreCase = true)) {
                true
            } else if (equipment.equals("other", ignoreCase = true)) {
                exercise.equipment !in standardEquipments
            } else {
                exercise.equipment.equals(equipment, ignoreCase = true)
            }

            matchesQuery && matchesMuscle && matchesEquipment
        }
    }
}
