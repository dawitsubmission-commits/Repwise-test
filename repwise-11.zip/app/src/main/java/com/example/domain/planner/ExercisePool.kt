package com.example.domain.planner

enum class MovementSlot {
    KNEE,
    HINGE,
    H_PUSH,
    H_PULL,
    V_PUSH,
    V_PULL,
    REAR_DELT,
    SHOULDER_ACC,
    BICEPS,
    TRICEPS,
    LEG_CURL,
    CALF,
    CORE,
    CONDITIONING
}

enum class MinLevel {
    B, // Beginner
    I  // Intermediate
}

data class PoolExercise(
    val id: String,
    val name: String,
    val slot: MovementSlot,
    val equipmentTag: String,
    val minLevel: MinLevel
) {
    val isCompound: Boolean
        get() = when (slot) {
            MovementSlot.KNEE,
            MovementSlot.HINGE,
            MovementSlot.H_PUSH,
            MovementSlot.H_PULL,
            MovementSlot.V_PUSH,
            MovementSlot.V_PULL -> true
            else -> false
        }
}

/**
 * Hardcoded exercise pool matching Phase 7 specifications.
 * All 91 exercises verified to exist in the catalog.
 */
object ExercisePool {

    val allExercises: List<PoolExercise> = listOf(
        // KNEE (11)
        PoolExercise("2368", "Split Squats", MovementSlot.KNEE, "none", MinLevel.B),
        PoolExercise("1760", "Dumbbell Goblet Squat", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0336", "Dumbbell Lunge", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0431", "Dumbbell Step-up", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0381", "Dumbbell Rear Lunge", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0585", "Lever Leg Extension", MovementSlot.KNEE, "machine", MinLevel.B),
        PoolExercise("0043", "Barbell Full Squat", MovementSlot.KNEE, "barbell", MinLevel.I),
        PoolExercise("0042", "Barbell Front Squat", MovementSlot.KNEE, "barbell", MinLevel.I),
        PoolExercise("0760", "Smith Front Squat", MovementSlot.KNEE, "machine", MinLevel.I),
        PoolExercise("0770", "Smith Squat", MovementSlot.KNEE, "machine", MinLevel.I),
        PoolExercise("0413", "Dumbbell Single Leg Squat", MovementSlot.KNEE, "dumbbell", MinLevel.I),

        // HINGE (8)
        PoolExercise("3013", "Low Glute Bridge on Floor", MovementSlot.HINGE, "none", MinLevel.B),
        PoolExercise("1459", "Dumbbell Romanian Deadlift", MovementSlot.HINGE, "dumbbell", MinLevel.B),
        PoolExercise("0300", "Dumbbell Deadlift", MovementSlot.HINGE, "dumbbell", MinLevel.B),
        PoolExercise("1409", "Barbell Glute Bridge", MovementSlot.HINGE, "barbell", MinLevel.I),
        PoolExercise("0032", "Barbell Deadlift", MovementSlot.HINGE, "barbell", MinLevel.I),
        PoolExercise("0573", "Lever Back Extension", MovementSlot.HINGE, "machine", MinLevel.B),
        PoolExercise("0085", "Barbell Romanian Deadlift", MovementSlot.HINGE, "barbell", MinLevel.I),
        PoolExercise("0196", "Cable Pull Through (With Rope)", MovementSlot.HINGE, "cable", MinLevel.B),

        // H_PUSH (15)
        PoolExercise("0659", "Push-up (Wall)", MovementSlot.H_PUSH, "none", MinLevel.B),
        PoolExercise("0662", "Push-up", MovementSlot.H_PUSH, "none", MinLevel.B),
        PoolExercise("0289", "Dumbbell Bench Press", MovementSlot.H_PUSH, "dumbbell", MinLevel.B),
        PoolExercise("0577", "Lever Chest Press", MovementSlot.H_PUSH, "machine", MinLevel.B),
        PoolExercise("2144", "Cable Seated Chest Press", MovementSlot.H_PUSH, "cable", MinLevel.B),
        PoolExercise("0025", "Barbell Bench Press", MovementSlot.H_PUSH, "barbell", MinLevel.I),
        PoolExercise("0314", "Dumbbell Incline Bench Press", MovementSlot.H_PUSH, "dumbbell", MinLevel.B),
        PoolExercise("0047", "Barbell Incline Bench Press", MovementSlot.H_PUSH, "barbell", MinLevel.I),
        PoolExercise("0308", "Dumbbell Fly", MovementSlot.H_PUSH, "dumbbell", MinLevel.B),
        PoolExercise("0155", "Cable Cross-Over Variation", MovementSlot.H_PUSH, "cable", MinLevel.B),
        PoolExercise("0301", "Dumbbell Decline Bench Press", MovementSlot.H_PUSH, "dumbbell", MinLevel.I),
        PoolExercise("0493", "Incline Push-Up", MovementSlot.H_PUSH, "none", MinLevel.B),
        PoolExercise("0279", "Decline Push-Up", MovementSlot.H_PUSH, "bench", MinLevel.I),
        PoolExercise("0251", "Chest Dip", MovementSlot.H_PUSH, "bar", MinLevel.I),
        PoolExercise("0748", "Smith Bench Press", MovementSlot.H_PUSH, "machine", MinLevel.I),

        // H_PULL (6)
        PoolExercise("0293", "Dumbbell Bent Over Row", MovementSlot.H_PULL, "dumbbell", MinLevel.B),
        PoolExercise("0861", "Cable Seated Row", MovementSlot.H_PULL, "cable", MinLevel.B),
        PoolExercise("0993", "Band Reverse Fly", MovementSlot.H_PULL, "band", MinLevel.B),
        PoolExercise("0499", "Inverted Row", MovementSlot.H_PULL, "bar", MinLevel.I),
        PoolExercise("0027", "Barbell Bent Over Row", MovementSlot.H_PULL, "barbell", MinLevel.I),
        PoolExercise("1350", "Lever Seated Row", MovementSlot.H_PULL, "machine", MinLevel.B),

        // V_PUSH (5)
        PoolExercise("0405", "Dumbbell Seated Shoulder Press", MovementSlot.V_PUSH, "dumbbell", MinLevel.B),
        PoolExercise("0426", "Dumbbell Standing Overhead Press", MovementSlot.V_PUSH, "dumbbell", MinLevel.B),
        PoolExercise("0091", "Barbell Seated Overhead Press", MovementSlot.V_PUSH, "barbell", MinLevel.I),
        PoolExercise("0603", "Lever Seated Shoulder Press", MovementSlot.V_PUSH, "machine", MinLevel.B),
        PoolExercise("2137", "Cable Forward Raise", MovementSlot.V_PUSH, "cable", MinLevel.B),

        // V_PULL (6)
        PoolExercise("2330", "Cable Lat Pulldown Full Range of Motion", MovementSlot.V_PULL, "cable", MinLevel.B),
        PoolExercise("0652", "Pull-up", MovementSlot.V_PULL, "bar", MinLevel.I),
        PoolExercise("1326", "Chin-Up", MovementSlot.V_PULL, "bar", MinLevel.I),
        PoolExercise("0197", "Cable Pulldown (Pro Lat Bar)", MovementSlot.V_PULL, "cable", MinLevel.B),
        PoolExercise("0198", "Cable Pulldown", MovementSlot.V_PULL, "cable", MinLevel.B),
        PoolExercise("0238", "Cable Straight Arm Pulldown", MovementSlot.V_PULL, "cable", MinLevel.B),

        // REAR_DELT (2)
        PoolExercise("0383", "Dumbbell Reverse Fly", MovementSlot.REAR_DELT, "dumbbell", MinLevel.B),
        PoolExercise("0378", "Dumbbell Rear Fly", MovementSlot.REAR_DELT, "dumbbell", MinLevel.B),

        // SHOULDER_ACC (3)
        PoolExercise("0334", "Dumbbell Lateral Raise", MovementSlot.SHOULDER_ACC, "dumbbell", MinLevel.B),
        PoolExercise("0310", "Dumbbell Front Raise", MovementSlot.SHOULDER_ACC, "dumbbell", MinLevel.B),
        PoolExercise("0178", "Cable Lateral Raise", MovementSlot.SHOULDER_ACC, "cable", MinLevel.B),

        // BICEPS (7)
        PoolExercise("0294", "Dumbbell Biceps Curl", MovementSlot.BICEPS, "dumbbell", MinLevel.B),
        PoolExercise("0285", "Dumbbell Alternate Biceps Curl", MovementSlot.BICEPS, "dumbbell", MinLevel.B),
        PoolExercise("0031", "Barbell Curl", MovementSlot.BICEPS, "barbell", MinLevel.I),
        PoolExercise("0313", "Dumbbell Incline Biceps Curl", MovementSlot.BICEPS, "dumbbell", MinLevel.B),
        PoolExercise("0868", "Cable Preacher Curl", MovementSlot.BICEPS, "cable", MinLevel.B),
        PoolExercise("0447", "EZ Barbell Spider Curl", MovementSlot.BICEPS, "barbell", MinLevel.I),
        PoolExercise("0372", "Dumbbell Preacher Curl", MovementSlot.BICEPS, "dumbbell", MinLevel.B),

        // TRICEPS (8)
        PoolExercise("0430", "Dumbbell Standing Triceps Extension", MovementSlot.TRICEPS, "dumbbell", MinLevel.B),
        PoolExercise("0814", "Triceps Dip", MovementSlot.TRICEPS, "bench", MinLevel.I),
        PoolExercise("0241", "Cable Triceps Pushdown (V-Bar)", MovementSlot.TRICEPS, "cable", MinLevel.B),
        PoolExercise("0201", "Cable Standing One Arm Triceps Extension", MovementSlot.TRICEPS, "cable", MinLevel.B),
        PoolExercise("0351", "Dumbbell One Arm Triceps Extension", MovementSlot.TRICEPS, "dumbbell", MinLevel.B),
        PoolExercise("0060", "Barbell Lying Triceps Extension Skull Crusher", MovementSlot.TRICEPS, "barbell", MinLevel.I),
        PoolExercise("0259", "Close-Grip Push-up", MovementSlot.TRICEPS, "none", MinLevel.B),
        PoolExercise("0333", "Dumbbell Kickback", MovementSlot.TRICEPS, "dumbbell", MinLevel.B),

        // LEG_CURL (2)
        PoolExercise("0599", "Lever Seated Leg Curl", MovementSlot.LEG_CURL, "machine", MinLevel.B),
        PoolExercise("0586", "Lever Lying Leg Curl", MovementSlot.LEG_CURL, "machine", MinLevel.B),

        // CALF (4)
        PoolExercise("0594", "Lever Seated Calf Raise", MovementSlot.CALF, "machine", MinLevel.B),
        PoolExercise("1387", "One Leg Floor Calf Raise", MovementSlot.CALF, "none", MinLevel.B),
        PoolExercise("1375", "Dumbbell Standing Calf Raise", MovementSlot.CALF, "dumbbell", MinLevel.B),
        PoolExercise("1379", "Barbell Standing Calf Raise", MovementSlot.CALF, "barbell", MinLevel.I),

        // CORE (12)
        PoolExercise("0276", "Dead Bug", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0464", "Front Plank with Twist", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0274", "Crunch Floor", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0872", "Reverse Crunch", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0472", "Hanging Leg Raise", MovementSlot.CORE, "bar", MinLevel.I),
        PoolExercise("0687", "Side Plank", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0459", "Frog Crunch", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0001", "3/4 Sit-up", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0689", "Side Plank Hip Adduction", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0223", "Cable Seated Crunch", MovementSlot.CORE, "cable", MinLevel.B),
        PoolExercise("0972", "Barbell Rollout", MovementSlot.CORE, "barbell", MinLevel.I),
        PoolExercise("1014", "Hanging Leg Hip Raise", MovementSlot.CORE, "bar", MinLevel.I),

        // CONDITIONING (2)
        PoolExercise("0630", "Mountain Climber", MovementSlot.CONDITIONING, "none", MinLevel.B),
        PoolExercise("1160", "Burpee", MovementSlot.CONDITIONING, "none", MinLevel.I)
    )

    private val poolById: Map<String, PoolExercise> = allExercises.associateBy { it.id }

    fun findById(id: String): PoolExercise? = poolById[id]
}
