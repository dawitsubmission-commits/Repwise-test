package com.example.domain.planner

import com.example.domain.bmi.BmiCalculator

enum class ExperienceLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}

enum class FitnessGoal {
    BUILD_MUSCLE,
    STRENGTH,
    ENDURANCE,
    GENERAL,
    MAINTAIN
}

enum class TrainingLocation {
    HOME,
    GYM
}

enum class TrainingStyle {
    AUTO,
    FULL_BODY,
    UPPER_LOWER,
    PUSH_PULL_LEGS,
    BODY_PART
}

data class PlanGeneratorRequest(
    val age: Int,
    val experience: ExperienceLevel,
    val goal: FitnessGoal,
    val location: TrainingLocation,
    val equipmentKeys: Set<String>, // e.g. "none", "dumbbell", "band", "bar", "bench", "full_gym"
    val chosenWeekdays: List<Int>, // 1 = Monday ... 7 = Sunday
    val style: TrainingStyle = TrainingStyle.AUTO,
    val availableExerciseIds: Set<String>? = null
)

data class GeneratedExercise(
    val exerciseId: String,
    val name: String,
    val slot: MovementSlot,
    val sets: Int,
    val repMin: Int,
    val repMax: Int,
    val restSeconds: Int
) {
    val summaryText: String
        get() = "${sets} sets × ${repMin}-${repMax} reps • ${restSeconds}s rest"
}

data class GeneratedDay(
    val dayName: String,
    val assignedWeekday: Int,
    val weekdayName: String,
    val exercises: List<GeneratedExercise>
)

data class GeneratedPlan(
    val title: String,
    val templateKey: String = "generated",
    val days: List<GeneratedDay>,
    val notes: List<String>,
    val recoveryNote: String = PlanGenerator.RECOVERY_NOTE
)

fun styleDayRange(style: TrainingStyle): IntRange = PlanGenerator.styleDayRange(style)

object PlanGenerator {

    const val RECOVERY_NOTE =
        "Leave a rest day between sessions that train the same muscles. If you feel sharp pain, stop and check with a professional."

    const val BEGINNER_DAYS_NOTE =
        "Beginners get better results starting with 3 days."

    const val LIBRARY_LIMIT_NOTE =
        "Limited by the exercises available in this version of the library."

    const val REST_DAYS_NOTE =
        "To leave rest days between sessions, we used fewer training days than you selected."

    const val BODY_PART_BEGINNER_NOTE =
        "A body-part split trains each muscle about once a week. Many beginners progress faster training each muscle twice a week (like Full Body), but you can switch any time by retaking the assessment."

    fun styleDayRange(style: TrainingStyle): IntRange = when (style) {
        TrainingStyle.FULL_BODY -> 1..6
        TrainingStyle.UPPER_LOWER -> 2..4
        TrainingStyle.PUSH_PULL_LEGS -> 3..6
        TrainingStyle.BODY_PART -> 3..5
        TrainingStyle.AUTO -> 1..6
    }

    fun styleDisplayName(style: TrainingStyle): String = when (style) {
        TrainingStyle.AUTO -> "Let REPWISE decide"
        TrainingStyle.FULL_BODY -> "Full Body"
        TrainingStyle.UPPER_LOWER -> "Upper / Lower"
        TrainingStyle.PUSH_PULL_LEGS -> "Push / Pull / Legs"
        TrainingStyle.BODY_PART -> "Body-Part Split"
    }

    private val WEEKDAY_NAMES = mapOf(
        1 to "Monday",
        2 to "Tuesday",
        3 to "Wednesday",
        4 to "Thursday",
        5 to "Friday",
        6 to "Saturday",
        7 to "Sunday"
    )

    fun weekdayName(weekday: Int): String = WEEKDAY_NAMES[weekday] ?: "Day $weekday"

    /**
     * Resolves enabled equipment tags based on selection and location.
     */
    fun resolveEnabledEquipment(
        equipmentKeys: Set<String>,
        location: TrainingLocation
    ): Set<String> {
        val isFullGym = equipmentKeys.any {
            it.equals("Full gym", ignoreCase = true) ||
                it.equals("full_gym", ignoreCase = true) ||
                it.equals("gym", ignoreCase = true)
        }
        if (isFullGym) {
            return setOf("none", "dumbbell", "band", "bar", "bench", "machine", "cable", "barbell")
        }

        val enabled = mutableSetOf<String>()
        enabled.add("none") // Bodyweight always enabled

        for (eq in equipmentKeys) {
            when {
                eq.equals("Bodyweight only", ignoreCase = true) || eq == "none" -> enabled.add("none")
                eq.equals("Dumbbells", ignoreCase = true) || eq == "dumbbell" -> enabled.add("dumbbell")
                eq.equals("Resistance band", ignoreCase = true) || eq == "band" -> enabled.add("band")
                eq.equals("Pull-up bar", ignoreCase = true) || eq == "bar" -> enabled.add("bar")
                eq.equals("Bench", ignoreCase = true) || eq == "bench" -> enabled.add("bench")
            }
        }

        if (location == TrainingLocation.GYM) {
            enabled.add("machine")
            enabled.add("cable")
            enabled.add("barbell")
        }
        // Location HOME never enables machine, cable, or barbell unless Full gym was selected
        return enabled
    }

    /**
     * Generates a deterministic training plan based on assessment parameters.
     */
    fun generatePlan(request: PlanGeneratorRequest): GeneratedPlan? {
        if (request.age < BmiCalculator.MIN_SUPPORTED_AGE) {
            return null
        }

        val enabledEquipment = resolveEnabledEquipment(request.equipmentKeys, request.location)
        val notes = mutableListOf<String>()

        // Determine number of days and filter weekdays
        val chosen = if (request.chosenWeekdays.isEmpty()) listOf(1, 3, 5) else request.chosenWeekdays.distinct().sorted()

        val isBeginner = request.experience == ExperienceLevel.BEGINNER
        var effectiveDays = when {
            request.goal == FitnessGoal.MAINTAIN -> minOf(2, chosen.size)
            isBeginner -> {
                if (chosen.size > 3) {
                    notes.add(BEGINNER_DAYS_NOTE)
                }
                minOf(3, chosen.size)
            }
            else -> minOf(6, chosen.size)
        }

        var resolvedStyle = request.style
        if (request.style != TrainingStyle.AUTO) {
            val range = styleDayRange(request.style)
            if (effectiveDays > range.last) {
                notes.add("${styleDisplayName(request.style)} works with up to ${range.last} training days, so we used ${range.last}.")
                effectiveDays = range.last
            } else if (effectiveDays < range.first) {
                notes.add("${styleDisplayName(request.style)} needs at least ${range.first} training days, so we used Full Body instead.")
                resolvedStyle = TrainingStyle.FULL_BODY
            }
        }

        val scheduledWeekdays = selectOptimalWeekdays(chosen, effectiveDays, isBeginner)

        if (isBeginner && hasThreeConsecutiveDays(chosen) && (scheduledWeekdays.size < chosen.size || scheduledWeekdays.size < effectiveDays)) {
            if (!notes.contains(REST_DAYS_NOTE)) {
                notes.add(REST_DAYS_NOTE)
            }
        }

        // Select template:
        // 2-3 -> Full Body (A/B/C)
        // 4 -> Upper/Lower (INTERMEDIATE and ADVANCED only; beginners get Full Body)
        // 5-6 -> Push/Pull/Legs (INTERMEDIATE and ADVANCED only; otherwise fall back to 4-day Upper/Lower)
        val templateType = if (request.style == TrainingStyle.AUTO) {
            when {
                isBeginner || scheduledWeekdays.size <= 3 -> TemplateType.FULL_BODY
                scheduledWeekdays.size == 4 -> TemplateType.UPPER_LOWER
                scheduledWeekdays.size in 5..6 -> {
                    if (request.experience != ExperienceLevel.BEGINNER) {
                        TemplateType.PUSH_PULL_LEGS
                    } else {
                        TemplateType.FULL_BODY
                    }
                }
                else -> TemplateType.FULL_BODY
            }
        } else {
            when (resolvedStyle) {
                TrainingStyle.FULL_BODY -> TemplateType.FULL_BODY
                TrainingStyle.UPPER_LOWER -> TemplateType.UPPER_LOWER
                TrainingStyle.PUSH_PULL_LEGS -> TemplateType.PUSH_PULL_LEGS
                TrainingStyle.BODY_PART -> TemplateType.BODY_PART
                TrainingStyle.AUTO -> TemplateType.FULL_BODY
            }
        }

        if (isBeginner && resolvedStyle == TrainingStyle.BODY_PART) {
            notes.add(BODY_PART_BEGINNER_NOTE)
        }

        // Generate day templates
        val dayTemplates = buildDayTemplates(templateType, scheduledWeekdays.size, request)

        var hitLibraryLimit = false
        val generatedDays = mutableListOf<GeneratedDay>()

        for ((index, dayTemplate) in dayTemplates.withIndex()) {
            val assignedWeekday = scheduledWeekdays.getOrElse(index) { index + 1 }
            val exercises = mutableListOf<GeneratedExercise>()
            val usedExerciseIdsInDay = mutableSetOf<String>()

            for (slot in dayTemplate.slots) {
                val candidate = pickExerciseForSlot(
                    slot = slot,
                    dayIndex = index,
                    enabledEquipment = enabledEquipment,
                    userLevel = request.experience,
                    usedInDay = usedExerciseIdsInDay,
                    availableExerciseIds = request.availableExerciseIds
                )

                if (candidate != null) {
                    usedExerciseIdsInDay.add(candidate.id)
                    val scheme = getSetRepScheme(slot, request.goal)
                    exercises.add(
                        GeneratedExercise(
                            exerciseId = candidate.id,
                            name = candidate.name,
                            slot = slot,
                            sets = scheme.sets,
                            repMin = scheme.repMin,
                            repMax = scheme.repMax,
                            restSeconds = scheme.restSeconds
                        )
                    )
                } else {
                    hitLibraryLimit = true
                }
            }

            // For ENDURANCE goal, append one CONDITIONING exercise at the end of each day
            if (request.goal == FitnessGoal.ENDURANCE) {
                val conditioningCandidate = pickExerciseForSlot(
                    slot = MovementSlot.CONDITIONING,
                    dayIndex = index,
                    enabledEquipment = enabledEquipment,
                    userLevel = request.experience,
                    usedInDay = usedExerciseIdsInDay
                )
                if (conditioningCandidate != null) {
                    if (isBeginner && exercises.size >= 5) {
                        // Beginner limit: at most 5 exercises per day. Replace last exercise to fit conditioning.
                        exercises.removeAt(exercises.size - 1)
                    }
                    usedExerciseIdsInDay.add(conditioningCandidate.id)
                    val scheme = getSetRepScheme(MovementSlot.CONDITIONING, request.goal)
                    exercises.add(
                        GeneratedExercise(
                            exerciseId = conditioningCandidate.id,
                            name = conditioningCandidate.name,
                            slot = MovementSlot.CONDITIONING,
                            sets = scheme.sets,
                            repMin = scheme.repMin,
                            repMax = scheme.repMax,
                            restSeconds = scheme.restSeconds
                        )
                    )
                } else {
                    hitLibraryLimit = true
                }
            }

            // Enforce beginner limit: at most 5 exercises per day
            val finalExercises = if (isBeginner && exercises.size > 5) {
                exercises.take(5)
            } else {
                exercises
            }

            generatedDays.add(
                GeneratedDay(
                    dayName = dayTemplate.name,
                    assignedWeekday = assignedWeekday,
                    weekdayName = weekdayName(assignedWeekday),
                    exercises = finalExercises
                )
            )
        }

        if (hitLibraryLimit) {
            notes.add(LIBRARY_LIMIT_NOTE)
        }

        val planTitle = when (templateType) {
            TemplateType.FULL_BODY -> "Full Body Split"
            TemplateType.UPPER_LOWER -> "Upper / Lower Split"
            TemplateType.PUSH_PULL_LEGS -> "Push / Pull / Legs Split"
            TemplateType.BODY_PART -> "Body-Part Split"
        }

        return GeneratedPlan(
            title = planTitle,
            templateKey = "generated",
            days = generatedDays,
            notes = notes
        )
    }

    private data class DayTemplate(
        val name: String,
        val slots: List<MovementSlot>
    )

    private enum class TemplateType {
        FULL_BODY,
        UPPER_LOWER,
        PUSH_PULL_LEGS,
        BODY_PART
    }

    private fun buildDayTemplates(
        templateType: TemplateType,
        dayCount: Int,
        request: PlanGeneratorRequest
    ): List<DayTemplate> {
        val isBeginner = request.experience == ExperienceLevel.BEGINNER
        val isMaintain = request.goal == FitnessGoal.MAINTAIN

        return when (templateType) {
            TemplateType.FULL_BODY -> {
                val fullBodySlots = if (isMaintain) {
                    listOf(MovementSlot.KNEE, MovementSlot.H_PUSH, MovementSlot.H_PULL, MovementSlot.HINGE)
                } else if (isBeginner) {
                    listOf(MovementSlot.KNEE, MovementSlot.H_PUSH, MovementSlot.H_PULL, MovementSlot.HINGE, MovementSlot.CORE)
                } else {
                    listOf(MovementSlot.KNEE, MovementSlot.H_PUSH, MovementSlot.H_PULL, MovementSlot.HINGE, MovementSlot.CORE, MovementSlot.V_PUSH)
                }

                val dayNames = listOf("Full Body A", "Full Body B", "Full Body C")
                (0 until dayCount).map { i ->
                    DayTemplate(
                        name = dayNames.getOrElse(i) { "Full Body ${('A'.code + i).toChar()}" },
                        slots = fullBodySlots
                    )
                }
            }

            TemplateType.UPPER_LOWER -> {
                // Upper: H_PUSH, H_PULL, V_PUSH, V_PULL (fall back to REAR_DELT if no pull-down), BICEPS or TRICEPS
                // Lower: KNEE, HINGE, LEG_CURL, CALF, CORE
                listOf(
                    DayTemplate(
                        name = "Upper Body A",
                        slots = listOf(MovementSlot.H_PUSH, MovementSlot.H_PULL, MovementSlot.V_PUSH, MovementSlot.V_PULL, MovementSlot.BICEPS)
                    ),
                    DayTemplate(
                        name = "Lower Body A",
                        slots = listOf(MovementSlot.KNEE, MovementSlot.HINGE, MovementSlot.LEG_CURL, MovementSlot.CALF, MovementSlot.CORE)
                    ),
                    DayTemplate(
                        name = "Upper Body B",
                        slots = listOf(MovementSlot.H_PUSH, MovementSlot.H_PULL, MovementSlot.V_PUSH, MovementSlot.V_PULL, MovementSlot.TRICEPS)
                    ),
                    DayTemplate(
                        name = "Lower Body B",
                        slots = listOf(MovementSlot.KNEE, MovementSlot.HINGE, MovementSlot.LEG_CURL, MovementSlot.CALF, MovementSlot.CORE)
                    )
                ).take(dayCount)
            }

            TemplateType.PUSH_PULL_LEGS -> {
                // Push: H_PUSH, V_PUSH, SHOULDER_ACC, TRICEPS, H_PUSH (second option)
                // Pull: V_PULL, H_PULL, REAR_DELT, BICEPS, H_PULL (second option)
                // Legs: KNEE, HINGE, KNEE (second option), LEG_CURL, CALF
                val pushSlots = listOf(MovementSlot.H_PUSH, MovementSlot.V_PUSH, MovementSlot.SHOULDER_ACC, MovementSlot.TRICEPS, MovementSlot.H_PUSH)
                val pullSlots = listOf(MovementSlot.V_PULL, MovementSlot.H_PULL, MovementSlot.REAR_DELT, MovementSlot.BICEPS, MovementSlot.H_PULL)
                val legsSlots = listOf(MovementSlot.KNEE, MovementSlot.HINGE, MovementSlot.KNEE, MovementSlot.LEG_CURL, MovementSlot.CALF)

                val allTemplates = listOf(
                    DayTemplate("Push A", pushSlots),
                    DayTemplate("Pull A", pullSlots),
                    DayTemplate("Legs A", legsSlots),
                    DayTemplate("Push B", pushSlots),
                    DayTemplate("Pull B", pullSlots),
                    DayTemplate("Legs B", legsSlots)
                )
                allTemplates.take(dayCount)
            }

            TemplateType.BODY_PART -> {
                when (dayCount) {
                    3 -> listOf(
                        DayTemplate(
                            name = "Chest & Triceps",
                            slots = listOf(
                                MovementSlot.H_PUSH,
                                MovementSlot.H_PUSH,
                                MovementSlot.H_PUSH,
                                MovementSlot.TRICEPS,
                                MovementSlot.TRICEPS
                            )
                        ),
                        DayTemplate(
                            name = "Back & Biceps",
                            slots = listOf(
                                MovementSlot.V_PULL,
                                MovementSlot.H_PULL,
                                MovementSlot.H_PULL,
                                MovementSlot.REAR_DELT,
                                MovementSlot.BICEPS,
                                MovementSlot.BICEPS
                            )
                        ),
                        DayTemplate(
                            name = "Legs & Shoulders",
                            slots = listOf(
                                MovementSlot.KNEE,
                                MovementSlot.HINGE,
                                MovementSlot.LEG_CURL,
                                MovementSlot.CALF,
                                MovementSlot.V_PUSH,
                                MovementSlot.SHOULDER_ACC
                            )
                        )
                    )
                    4 -> listOf(
                        DayTemplate(
                            name = "Chest & Triceps",
                            slots = listOf(
                                MovementSlot.H_PUSH,
                                MovementSlot.H_PUSH,
                                MovementSlot.H_PUSH,
                                MovementSlot.TRICEPS,
                                MovementSlot.TRICEPS
                            )
                        ),
                        DayTemplate(
                            name = "Back & Biceps",
                            slots = listOf(
                                MovementSlot.V_PULL,
                                MovementSlot.H_PULL,
                                MovementSlot.H_PULL,
                                MovementSlot.REAR_DELT,
                                MovementSlot.BICEPS,
                                MovementSlot.BICEPS
                            )
                        ),
                        DayTemplate(
                            name = "Legs",
                            slots = listOf(
                                MovementSlot.KNEE,
                                MovementSlot.KNEE,
                                MovementSlot.HINGE,
                                MovementSlot.LEG_CURL,
                                MovementSlot.CALF,
                                MovementSlot.CORE
                            )
                        ),
                        DayTemplate(
                            name = "Shoulders & Arms",
                            slots = listOf(
                                MovementSlot.V_PUSH,
                                MovementSlot.SHOULDER_ACC,
                                MovementSlot.REAR_DELT,
                                MovementSlot.BICEPS,
                                MovementSlot.TRICEPS
                            )
                        )
                    )
                    else -> listOf(
                        DayTemplate(
                            name = "Chest",
                            slots = listOf(
                                MovementSlot.H_PUSH,
                                MovementSlot.H_PUSH,
                                MovementSlot.H_PUSH,
                                MovementSlot.H_PUSH
                            )
                        ),
                        DayTemplate(
                            name = "Back",
                            slots = listOf(
                                MovementSlot.V_PULL,
                                MovementSlot.H_PULL,
                                MovementSlot.H_PULL,
                                MovementSlot.REAR_DELT
                            )
                        ),
                        DayTemplate(
                            name = "Legs",
                            slots = listOf(
                                MovementSlot.KNEE,
                                MovementSlot.KNEE,
                                MovementSlot.HINGE,
                                MovementSlot.LEG_CURL,
                                MovementSlot.CALF,
                                MovementSlot.CORE
                            )
                        ),
                        DayTemplate(
                            name = "Shoulders & Core",
                            slots = listOf(
                                MovementSlot.V_PUSH,
                                MovementSlot.V_PUSH,
                                MovementSlot.SHOULDER_ACC,
                                MovementSlot.REAR_DELT,
                                MovementSlot.CORE
                            )
                        ),
                        DayTemplate(
                            name = "Arms",
                            slots = listOf(
                                MovementSlot.BICEPS,
                                MovementSlot.TRICEPS,
                                MovementSlot.BICEPS,
                                MovementSlot.TRICEPS
                            )
                        )
                    ).take(dayCount)
                }
            }
        }
    }

    private fun pickExerciseForSlot(
        slot: MovementSlot,
        dayIndex: Int,
        enabledEquipment: Set<String>,
        userLevel: ExperienceLevel,
        usedInDay: Set<String>,
        availableExerciseIds: Set<String>? = null
    ): PoolExercise? {
        var candidates = ExercisePool.allExercises.filter { ex ->
            ex.slot == slot &&
                enabledEquipment.contains(ex.equipmentTag) &&
                isLevelAllowed(ex.minLevel, userLevel) &&
                (availableExerciseIds == null || availableExerciseIds.contains(ex.id))
        }

        // Fallback for V_PULL: "fall back to REAR_DELT if no pull-down option"
        if (candidates.isEmpty() && slot == MovementSlot.V_PULL) {
            candidates = ExercisePool.allExercises.filter { ex ->
                ex.slot == MovementSlot.REAR_DELT &&
                    enabledEquipment.contains(ex.equipmentTag) &&
                    isLevelAllowed(ex.minLevel, userLevel) &&
                    (availableExerciseIds == null || availableExerciseIds.contains(ex.id))
            }
        }

        if (candidates.isEmpty()) {
            return null
        }

        // Rotate through candidates across days
        val startOffset = dayIndex % candidates.size
        for (i in candidates.indices) {
            val candidate = candidates[(startOffset + i) % candidates.size]
            if (!usedInDay.contains(candidate.id)) {
                return candidate
            }
        }

        // All candidates already used in this day. To avoid duplicate in same day, return null
        return null
    }

    private fun isLevelAllowed(minLevel: MinLevel, userLevel: ExperienceLevel): Boolean {
        return when (userLevel) {
            ExperienceLevel.BEGINNER -> minLevel == MinLevel.B
            ExperienceLevel.INTERMEDIATE,
            ExperienceLevel.ADVANCED -> true
        }
    }

    private data class Scheme(val sets: Int, val repMin: Int, val repMax: Int, val restSeconds: Int)

    private fun getSetRepScheme(slot: MovementSlot, goal: FitnessGoal): Scheme {
        if (goal == FitnessGoal.MAINTAIN) {
            return Scheme(sets = 2, repMin = 8, repMax = 12, restSeconds = 75)
        }

        val isCompound = when (slot) {
            MovementSlot.KNEE,
            MovementSlot.HINGE,
            MovementSlot.H_PUSH,
            MovementSlot.H_PULL,
            MovementSlot.V_PUSH,
            MovementSlot.V_PULL -> true
            else -> false
        }

        return when (goal) {
            FitnessGoal.BUILD_MUSCLE -> {
                if (isCompound) {
                    Scheme(sets = 3, repMin = 8, repMax = 12, restSeconds = 90)
                } else {
                    Scheme(sets = 3, repMin = 10, repMax = 15, restSeconds = 60)
                }
            }
            FitnessGoal.STRENGTH -> {
                if (isCompound) {
                    Scheme(sets = 3, repMin = 5, repMax = 8, restSeconds = 150)
                } else {
                    Scheme(sets = 2, repMin = 8, repMax = 12, restSeconds = 90)
                }
            }
            FitnessGoal.ENDURANCE -> {
                Scheme(sets = 3, repMin = 12, repMax = 20, restSeconds = 45)
            }
            FitnessGoal.GENERAL -> {
                if (isCompound) {
                    Scheme(sets = 3, repMin = 8, repMax = 12, restSeconds = 90)
                } else {
                    Scheme(sets = 2, repMin = 10, repMax = 15, restSeconds = 60)
                }
            }
            FitnessGoal.MAINTAIN -> Scheme(sets = 2, repMin = 8, repMax = 12, restSeconds = 75)
        }
    }

    /**
     * Checks if a list of weekdays contains any 3 consecutive days in a circular 7-day week.
     */
    fun hasThreeConsecutiveDays(days: List<Int>): Boolean {
        if (days.size < 3) return false
        val set = days.toSet()
        for (d in 1..7) {
            val next1 = if (d == 7) 1 else d + 1
            val next2 = if (next1 == 7) 1 else next1 + 1
            if (set.contains(d) && set.contains(next1) && set.contains(next2)) {
                return true
            }
        }
        return false
    }

    /**
     * Deterministically selects targetDays weekdays from chosen weekdays, ensuring
     * no 3 consecutive training days for beginners.
     */
    fun selectOptimalWeekdays(
        chosenWeekdays: List<Int>,
        targetDays: Int,
        isBeginner: Boolean
    ): List<Int> {
        val sorted = chosenWeekdays.distinct().sorted()
        if (sorted.isEmpty()) return listOf(1, 3, 5).take(targetDays)
        if (targetDays <= 1) return listOf(sorted.first())

        // If targetDays is same or larger than sorted size
        if (sorted.size <= targetDays) {
            if (isBeginner && hasThreeConsecutiveDays(sorted)) {
                // If sorted has 3 consecutive days, drop one to ensure beginner rule: never 3 consecutive days!
                return listOf(sorted[0], sorted[2])
            }
            return sorted
        }

        // Generate combinations of size targetDays and pick the one with max spacing and no 3 consecutive days
        val combinations = generateCombinations(sorted, targetDays)

        val validCombinations = if (isBeginner) {
            combinations.filter { !hasThreeConsecutiveDays(it) }
        } else {
            combinations
        }

        if (isBeginner && validCombinations.isEmpty()) {
            return selectOptimalWeekdays(sorted, targetDays - 1, isBeginner)
        }

        val pool = if (validCombinations.isNotEmpty()) validCombinations else combinations

        // Deterministic selection: pick combination with largest minimum gap between days
        return pool.maxByOrNull { calculateMinGap(it) } ?: sorted.take(targetDays)
    }

    private fun <T> generateCombinations(list: List<T>, k: Int): List<List<T>> {
        val result = mutableListOf<List<T>>()
        fun backtrack(start: Int, current: MutableList<T>) {
            if (current.size == k) {
                result.add(ArrayList(current))
                return
            }
            for (i in start until list.size) {
                current.add(list[i])
                backtrack(i + 1, current)
                current.removeAt(current.size - 1)
            }
        }
        backtrack(0, mutableListOf())
        return result
    }

    private fun calculateMinGap(days: List<Int>): Int {
        if (days.size <= 1) return 7
        val sorted = days.sorted()
        var minGap = 7
        for (i in 0 until sorted.size - 1) {
            val gap = sorted[i + 1] - sorted[i]
            if (gap < minGap) minGap = gap
        }
        val wrapGap = (7 - sorted.last()) + sorted.first()
        if (wrapGap < minGap) minGap = wrapGap
        return minGap
    }
}
