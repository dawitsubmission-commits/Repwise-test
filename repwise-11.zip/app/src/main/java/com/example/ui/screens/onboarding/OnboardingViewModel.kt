package com.example.ui.screens.onboarding

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.UserProfileEntity
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.bmi.BmiCalculator
import com.example.domain.bmi.BmiResult
import com.example.domain.planner.ExperienceLevel
import com.example.domain.planner.FitnessGoal
import com.example.domain.planner.GeneratedPlan
import com.example.domain.planner.PlanGenerator
import com.example.domain.planner.PlanGeneratorRequest
import com.example.domain.planner.TrainingLocation
import com.example.domain.planner.TrainingStyle
import com.example.domain.repository.RepwiseRepository
import com.example.util.HeightHelper
import com.example.util.WeightHelper
import com.example.util.WeightUnit
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OnboardingUiState(
    val currentStep: Int = 1,
    val unitSystem: String = "METRIC", // METRIC or IMPERIAL
    val ageText: String = "25",
    val heightCmText: String = "175",
    val heightFeetText: String = "5",
    val heightInchesText: String = "9",
    val weightText: String = "70",
    val experience: ExperienceLevel = ExperienceLevel.BEGINNER,
    val goal: FitnessGoal = FitnessGoal.BUILD_MUSCLE,
    val location: TrainingLocation = TrainingLocation.HOME,
    val selectedEquipment: Set<String> = setOf("Bodyweight only", "Dumbbells"),
    val selectedWeekdays: Set<Int> = setOf(1, 3, 5), // Mon, Wed, Fri
    val trainingStyle: TrainingStyle = TrainingStyle.AUTO,
    val healthNoticeAcknowledged: Boolean = false,
    val bmiResult: BmiResult? = null,
    val generatedPlan: GeneratedPlan? = null,
    val errorMessage: String? = null,
    val isPlanSaved: Boolean = false,
    val isLoading: Boolean = false,
    val showReplacePlanDialog: Boolean = false,
    val activePlanName: String? = null
)

class OnboardingViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _uiState = MutableStateFlow(OnboardingUiState())
    val uiState: StateFlow<OnboardingUiState> = _uiState.asStateFlow()

    init {
        loadExistingProfile()
    }

    private fun loadExistingProfile() {
        viewModelScope.launch {
            val existing = repository.getUserProfileEntityOnce()
            if (existing != null) {
                val isImperial = existing.unitSystem.equals("IMPERIAL", ignoreCase = true)
                val (feet, inches) = HeightHelper.fromCmToFeetAndInches(existing.heightCm)
                val weightDisplay = if (isImperial) {
                    WeightHelper.fromKg(existing.weightKg, WeightUnit.LBS)
                } else {
                    existing.weightKg
                }

                val eqSet = existing.equipment.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                val daysSet = existing.trainingWeekdays.split(",")
                    .mapNotNull { it.trim().toIntOrNull() }
                    .toSet()

                val exp = try {
                    ExperienceLevel.valueOf(existing.experience)
                } catch (e: Exception) {
                    ExperienceLevel.BEGINNER
                }

                val goal = try {
                    FitnessGoal.valueOf(existing.goal)
                } catch (e: Exception) {
                    FitnessGoal.BUILD_MUSCLE
                }

                val loc = try {
                    TrainingLocation.valueOf(existing.location)
                } catch (e: Exception) {
                    TrainingLocation.HOME
                }

                _uiState.update { current ->
                    current.copy(
                        unitSystem = existing.unitSystem,
                        ageText = existing.age.toString(),
                        heightCmText = existing.heightCm.toInt().toString(),
                        heightFeetText = feet.toString(),
                        heightInchesText = inches.toString(),
                        weightText = String.format(java.util.Locale.US, "%.1f", weightDisplay),
                        experience = exp,
                        goal = goal,
                        location = loc,
                        selectedEquipment = if (eqSet.isNotEmpty()) eqSet else current.selectedEquipment,
                        selectedWeekdays = if (daysSet.isNotEmpty()) daysSet else current.selectedWeekdays,
                        trainingStyle = TrainingStyle.AUTO,
                        healthNoticeAcknowledged = existing.healthNoticeAcknowledged
                    )
                }
            }
        }
    }

    fun setUnitSystem(unit: String) {
        val current = _uiState.value
        if (current.unitSystem == unit) return

        if (unit == "IMPERIAL") {
            // Convert cm to feet/inches, kg to lbs
            val cm = current.heightCmText.toDoubleOrNull() ?: 175.0
            val (feet, inches) = HeightHelper.fromCmToFeetAndInches(cm)
            val kg = current.weightText.toDoubleOrNull() ?: 70.0
            val lbs = WeightHelper.fromKg(kg, WeightUnit.LBS)

            _uiState.update {
                it.copy(
                    unitSystem = "IMPERIAL",
                    heightFeetText = feet.toString(),
                    heightInchesText = inches.toString(),
                    weightText = String.format(java.util.Locale.US, "%.1f", lbs)
                )
            }
        } else {
            // Convert feet/inches to cm, lbs to kg
            val feet = current.heightFeetText.toIntOrNull() ?: 5
            val inches = current.heightInchesText.toIntOrNull() ?: 9
            val cm = HeightHelper.toCm(feet, inches)
            val lbs = current.weightText.toDoubleOrNull() ?: 154.0
            val kg = WeightHelper.toKg(lbs, WeightUnit.LBS)

            _uiState.update {
                it.copy(
                    unitSystem = "METRIC",
                    heightCmText = cm.toInt().toString(),
                    weightText = String.format(java.util.Locale.US, "%.1f", kg)
                )
            }
        }
    }

    fun updateAge(age: String) {
        _uiState.update { it.copy(ageText = age, errorMessage = null) }
    }

    fun updateHeightCm(cm: String) {
        _uiState.update { it.copy(heightCmText = cm, errorMessage = null) }
    }

    fun updateHeightFeet(feet: String) {
        _uiState.update { it.copy(heightFeetText = feet, errorMessage = null) }
    }

    fun updateHeightInches(inches: String) {
        _uiState.update { it.copy(heightInchesText = inches, errorMessage = null) }
    }

    fun updateWeight(weight: String) {
        _uiState.update { it.copy(weightText = weight, errorMessage = null) }
    }

    fun setGoal(goal: FitnessGoal) {
        _uiState.update { it.copy(goal = goal) }
    }

    fun setExperience(experience: ExperienceLevel) {
        _uiState.update { it.copy(experience = experience) }
    }

    fun setLocation(location: TrainingLocation) {
        _uiState.update { it.copy(location = location) }
    }

    fun toggleEquipment(equipment: String) {
        _uiState.update { state ->
            val set = state.selectedEquipment.toMutableSet()
            if (equipment.equals("Full gym", ignoreCase = true)) {
                if (set.contains("Full gym")) {
                    set.remove("Full gym")
                } else {
                    set.add("Full gym")
                }
            } else {
                if (set.contains(equipment)) {
                    set.remove(equipment)
                } else {
                    set.add(equipment)
                }
            }
            // Ensure at least bodyweight is active
            if (set.isEmpty()) {
                set.add("Bodyweight only")
            }
            state.copy(selectedEquipment = set)
        }
    }

    fun toggleWeekday(day: Int) {
        _uiState.update { state ->
            val set = state.selectedWeekdays.toMutableSet()
            if (set.contains(day)) {
                if (set.size > 1) { // Keep at least 1 day selected
                    set.remove(day)
                }
            } else {
                set.add(day)
            }
            state.copy(selectedWeekdays = set)
        }
    }

    fun selectTrainingStyle(style: TrainingStyle) {
        _uiState.update { it.copy(trainingStyle = style) }
    }

    fun setHealthNoticeAcknowledged(acknowledged: Boolean) {
        _uiState.update { it.copy(healthNoticeAcknowledged = acknowledged) }
    }

    fun nextStep() {
        val state = _uiState.value
        when (state.currentStep) {
            1 -> {
                val age = state.ageText.toIntOrNull() ?: 0
                if (age < BmiCalculator.MIN_SUPPORTED_AGE) {
                    _uiState.update { it.copy(errorMessage = BmiCalculator.UNDER_MIN_AGE_MESSAGE) }
                    return
                }
                val weight = state.weightText.toDoubleOrNull() ?: 0.0
                if (weight <= 0.0) {
                    _uiState.update { it.copy(errorMessage = "Please enter a valid weight.") }
                    return
                }
                _uiState.update { it.copy(currentStep = 2, errorMessage = null) }
            }
            2 -> _uiState.update { it.copy(currentStep = 3) }
            3 -> _uiState.update { it.copy(currentStep = 4) }
            4 -> _uiState.update { it.copy(currentStep = 5) }
            5 -> {
                if (!state.healthNoticeAcknowledged) {
                    _uiState.update { it.copy(errorMessage = "Please acknowledge the health notice to continue.") }
                    return
                }
                // Compute BMI and transition to Step 6 (Summary)
                val age = state.ageText.toIntOrNull() ?: 25
                val heightCm: Double
                val weightKg: Double

                if (state.unitSystem == "IMPERIAL") {
                    val feet = state.heightFeetText.toIntOrNull() ?: 5
                    val inches = state.heightInchesText.toIntOrNull() ?: 9
                    heightCm = HeightHelper.toCm(feet, inches)
                    val lbs = state.weightText.toDoubleOrNull() ?: 154.0
                    weightKg = WeightHelper.toKg(lbs, WeightUnit.LBS)
                } else {
                    heightCm = state.heightCmText.toDoubleOrNull() ?: 175.0
                    weightKg = state.weightText.toDoubleOrNull() ?: 70.0
                }

                val bmiResult = BmiCalculator.calculateMetric(heightCm, weightKg, age)
                _uiState.update {
                    it.copy(
                        currentStep = 6,
                        bmiResult = bmiResult,
                        errorMessage = null
                    )
                }
            }
            6 -> {
                createPlan()
            }
        }
    }

    fun previousStep() {
        _uiState.update {
            if (it.currentStep > 1) {
                it.copy(currentStep = it.currentStep - 1, errorMessage = null)
            } else {
                it
            }
        }
    }

    fun createPlan() {
        val state = _uiState.value
        val age = state.ageText.toIntOrNull() ?: 25
        if (age < BmiCalculator.MIN_SUPPORTED_AGE) {
            _uiState.update { it.copy(errorMessage = BmiCalculator.UNDER_MIN_AGE_MESSAGE) }
            return
        }

        viewModelScope.launch {
            val catalogExercises = repository.getCatalogExercises().firstOrNull()
            val availableIds = catalogExercises?.map { it.id }?.toSet()

            val request = PlanGeneratorRequest(
                age = age,
                experience = state.experience,
                goal = state.goal,
                location = state.location,
                equipmentKeys = state.selectedEquipment,
                chosenWeekdays = state.selectedWeekdays.toList().sorted(),
                style = state.trainingStyle,
                availableExerciseIds = availableIds
            )

            val plan = PlanGenerator.generatePlan(request)
            if (plan != null) {
                _uiState.update {
                    it.copy(
                        generatedPlan = plan,
                        currentStep = 7,
                        errorMessage = null
                    )
                }
            } else {
                _uiState.update {
                    it.copy(errorMessage = "Could not generate plan with selected parameters.")
                }
            }
        }
    }

    fun requestUsePlan() {
        val state = _uiState.value
        if (state.generatedPlan == null) return

        viewModelScope.launch {
            val activePlan = repository.getActiveWorkoutPlan().firstOrNull()
            if (activePlan != null) {
                _uiState.update {
                    it.copy(
                        showReplacePlanDialog = true,
                        activePlanName = activePlan.plan.name
                    )
                }
            } else {
                usePlan()
            }
        }
    }

    fun dismissReplacePlanDialog() {
        _uiState.update { it.copy(showReplacePlanDialog = false) }
    }

    fun confirmReplacePlan() {
        _uiState.update { it.copy(showReplacePlanDialog = false) }
        usePlan()
    }

    fun usePlan() {
        val state = _uiState.value
        val plan = state.generatedPlan ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            val age = state.ageText.toIntOrNull() ?: 25
            val heightCm = if (state.unitSystem == "IMPERIAL") {
                val feet = state.heightFeetText.toIntOrNull() ?: 5
                val inches = state.heightInchesText.toIntOrNull() ?: 9
                HeightHelper.toCm(feet, inches)
            } else {
                state.heightCmText.toDoubleOrNull() ?: 175.0
            }

            val weightKg = if (state.unitSystem == "IMPERIAL") {
                val lbs = state.weightText.toDoubleOrNull() ?: 154.0
                WeightHelper.toKg(lbs, WeightUnit.LBS)
            } else {
                state.weightText.toDoubleOrNull() ?: 70.0
            }

            val profileEntity = UserProfileEntity(
                id = 1,
                age = age,
                heightCm = heightCm,
                weightKg = weightKg,
                experience = state.experience.name,
                goal = state.goal.name,
                equipment = state.selectedEquipment.joinToString(","),
                location = state.location.name,
                trainingWeekdays = state.selectedWeekdays.sorted().joinToString(","),
                unitSystem = state.unitSystem,
                healthNoticeAcknowledged = state.healthNoticeAcknowledged,
                onboardingCompleted = true,
                createdAt = System.currentTimeMillis()
            )

            repository.saveUserProfile(profileEntity)
            repository.saveGeneratedPlan(plan)

            _uiState.update { it.copy(isLoading = false, isPlanSaved = true) }
        }
    }
}
