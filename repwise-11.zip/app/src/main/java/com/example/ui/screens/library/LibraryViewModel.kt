package com.example.ui.screens.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.EssentialExercises
import com.example.domain.models.CatalogExercise
import com.example.domain.normalization.Normalizer
import com.example.domain.repository.RepwiseRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryUiState(
    val searchQuery: String = "",
    val selectedMuscle: String = "All",
    val selectedEquipment: String = "All",
    val showAll: Boolean = false,
    val isEssentialsFallback: Boolean = false,
    val hasMatchesInAll: Boolean = false,
    val muscleFilterOptions: List<String> = Normalizer.getAllFilterMuscles(),
    val equipmentFilterOptions: List<String> = Normalizer.getAllFilterEquipments(),
    val exercises: List<CatalogExercise> = emptyList(),
    val isLoading: Boolean = true
)

@OptIn(FlowPreview::class)
class LibraryViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _searchQuery = MutableStateFlow("")
    private val _selectedMuscle = MutableStateFlow("All")
    private val _selectedEquipment = MutableStateFlow("All")
    private val _showAll = MutableStateFlow(false)
    private val _isLoading = MutableStateFlow(true)

    init {
        viewModelScope.launch {
            repository.ensureCatalogInitialized()
            _isLoading.value = false
        }
    }

    private val debouncedQuery = _searchQuery.debounce { if (it.isEmpty()) 0L else 250L }

    private data class FilterResult(
        val exercises: List<CatalogExercise>,
        val showAll: Boolean,
        val isEssentialsFallback: Boolean,
        val hasMatchesInAll: Boolean
    )

    private val filteredExercises = combine(
        repository.getCatalogExercises(),
        debouncedQuery,
        _selectedMuscle,
        _selectedEquipment,
        _showAll
    ) { allExercises, query, muscle, equip, showAll ->
        val essentialsAvailable = allExercises.any { it.id in EssentialExercises.ids }
        val isFallback = !showAll && allExercises.isNotEmpty() && !essentialsAvailable

        val filtered = EssentialExercises.filterExercises(
            allExercises = allExercises,
            showAll = showAll,
            query = query,
            muscle = muscle,
            equipment = equip
        )

        val hasMatchesInAll = if (!showAll && !isFallback && filtered.isEmpty() && query.isNotBlank()) {
            EssentialExercises.filterExercises(
                allExercises = allExercises,
                showAll = true,
                query = query,
                muscle = muscle,
                equipment = equip
            ).isNotEmpty()
        } else {
            false
        }

        FilterResult(
            exercises = filtered,
            showAll = showAll,
            isEssentialsFallback = isFallback,
            hasMatchesInAll = hasMatchesInAll
        )
    }

    val uiState: StateFlow<LibraryUiState> = combine(
        _searchQuery,
        _selectedMuscle,
        _selectedEquipment,
        _isLoading,
        filteredExercises
    ) { query, muscle, equip, loading, result ->
        LibraryUiState(
            searchQuery = query,
            selectedMuscle = muscle,
            selectedEquipment = equip,
            showAll = result.showAll,
            isEssentialsFallback = result.isEssentialsFallback,
            hasMatchesInAll = result.hasMatchesInAll,
            exercises = result.exercises,
            isLoading = loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryUiState()
    )

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onMuscleSelect(muscle: String) {
        _selectedMuscle.value = muscle
    }

    fun onEquipmentSelect(equipment: String) {
        _selectedEquipment.value = equipment
    }

    fun onShowAllChange(showAll: Boolean) {
        _showAll.value = showAll
    }

    fun clearFilters() {
        _searchQuery.value = ""
        _selectedMuscle.value = "All"
        _selectedEquipment.value = "All"
    }
}
