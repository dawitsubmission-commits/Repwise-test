package com.example.ui.screens.onboarding

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Checkbox
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.bmi.BmiCalculator
import com.example.domain.planner.ExperienceLevel
import com.example.domain.planner.FitnessGoal
import com.example.domain.planner.GeneratedPlan
import androidx.compose.ui.text.style.TextOverflow
import com.example.domain.planner.PlanGenerator
import com.example.domain.planner.TrainingLocation
import com.example.domain.planner.TrainingStyle
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    onFinish: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: OnboardingViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState.isPlanSaved) {
        if (uiState.isPlanSaved) {
            onFinish()
        }
    }

    BackHandler {
        if (uiState.currentStep > 1) {
            viewModel.previousStep()
        } else {
            onBack()
        }
    }

    if (uiState.showReplacePlanDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissReplacePlanDialog() },
            title = {
                Text(
                    text = "Replace Active Plan?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )
            },
            text = {
                Text(
                    text = "You currently have an active plan (\"${uiState.activePlanName ?: "Current Split"}\"). Would you like to replace it with this new generated plan?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.confirmReplacePlan() }
                ) {
                    Text(
                        text = "Replace Plan",
                        color = RepwiseLime,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { viewModel.dismissReplacePlanDialog() }
                ) {
                    Text(
                        text = "Cancel",
                        color = TextSecondary
                    )
                }
            },
            containerColor = CharcoalSurfaceElevated
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground),
        containerColor = CharcoalBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (uiState.currentStep == 7) "Your Plan Preview" else "Fitness Assessment",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextHighEmphasis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (uiState.currentStep > 1) {
                                viewModel.previousStep()
                            } else {
                                onBack()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextHighEmphasis
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CharcoalBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Step Progress Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Step ${uiState.currentStep} of 7",
                        style = MaterialTheme.typography.labelMedium,
                        color = RepwiseLime
                    )
                    Text(
                        text = when (uiState.currentStep) {
                            1 -> "Measurements"
                            2 -> "Goal & Experience"
                            3 -> "Location & Equipment"
                            4 -> "Schedule"
                            5 -> "Health Notice"
                            6 -> "Assessment & BMI"
                            7 -> "Review Plan"
                            else -> ""
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                LinearProgressIndicator(
                    progress = { uiState.currentStep / 7f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = RepwiseLime,
                    trackColor = CharcoalSurfaceElevated,
                )
            }

            // Error Banner if present
            uiState.errorMessage?.let { error ->
                RepwiseCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs),
                    containerColor = CharcoalSurfaceElevated
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = RepwiseLime,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = error,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextHighEmphasis
                        )
                    }
                }
            }

            // Step Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (uiState.currentStep) {
                    1 -> Step1Measurements(uiState, viewModel)
                    2 -> Step2GoalAndExperience(uiState, viewModel)
                    3 -> Step3LocationAndEquipment(uiState, viewModel)
                    4 -> Step4Schedule(uiState, viewModel)
                    5 -> Step5HealthNotice(uiState, viewModel)
                    6 -> Step6SummaryAndBmi(uiState, viewModel)
                    7 -> Step7PlanPreview(uiState, viewModel)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Step 1: Units + Age + Height + Weight
// -------------------------------------------------------------
@Composable
private fun Step1Measurements(
    uiState: OnboardingUiState,
    viewModel: OnboardingViewModel
) {
    val isImperial = uiState.unitSystem == "IMPERIAL"
    val age = uiState.ageText.toIntOrNull() ?: 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md)
    ) {
        item {
            SectionHeader(
                title = "Your Body Measurements",
                subtitle = "Used strictly for calibration and BMI screening"
            )
        }

        // Units Toggle
        item {
            RepwiseCard {
                Text(
                    text = "Unit System",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextHighEmphasis
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                ) {
                    UnitOptionButton(
                        text = "Metric (cm, kg)",
                        isSelected = !isImperial,
                        onClick = { viewModel.setUnitSystem("METRIC") },
                        modifier = Modifier.weight(1f)
                    )
                    UnitOptionButton(
                        text = "Imperial (ft/in, lbs)",
                        isSelected = isImperial,
                        onClick = { viewModel.setUnitSystem("IMPERIAL") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Age Input
        item {
            RepwiseCard {
                Text(
                    text = "Age",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextHighEmphasis
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                OutlinedTextField(
                    value = uiState.ageText,
                    onValueChange = { viewModel.updateAge(it) },
                    label = { Text("Years") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )

                if (age in 1 until BmiCalculator.MIN_SUPPORTED_AGE) {
                    Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                    Text(
                        text = BmiCalculator.UNDER_MIN_AGE_MESSAGE,
                        style = MaterialTheme.typography.bodySmall,
                        color = RepwiseLime
                    )
                }
            }
        }

        // Height Input
        item {
            RepwiseCard {
                Text(
                    text = "Height",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextHighEmphasis
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                if (isImperial) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        OutlinedTextField(
                            value = uiState.heightFeetText,
                            onValueChange = { viewModel.updateHeightFeet(it) },
                            label = { Text("Feet (ft)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = outlinedFieldColors(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = uiState.heightInchesText,
                            onValueChange = { viewModel.updateHeightInches(it) },
                            label = { Text("Inches (in)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = outlinedFieldColors(),
                            singleLine = true
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = uiState.heightCmText,
                        onValueChange = { viewModel.updateHeightCm(it) },
                        label = { Text("Centimeters (cm)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = outlinedFieldColors(),
                        singleLine = true
                    )
                }
            }
        }

        // Weight Input
        item {
            RepwiseCard {
                Text(
                    text = "Weight",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextHighEmphasis
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                OutlinedTextField(
                    value = uiState.weightText,
                    onValueChange = { viewModel.updateWeight(it) },
                    label = { Text(if (isImperial) "Pounds (lbs)" else "Kilograms (kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    colors = outlinedFieldColors(),
                    singleLine = true
                )
            }
        }

        // Next Button
        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            PrimaryButton(
                text = "Continue",
                onClick = { viewModel.nextStep() },
                modifier = Modifier.fillMaxWidth(),
                enabled = age >= BmiCalculator.MIN_SUPPORTED_AGE
            )
        }
    }
}

// -------------------------------------------------------------
// Step 2: Fitness Goal + Experience Level
// -------------------------------------------------------------
@Composable
private fun Step2GoalAndExperience(
    uiState: OnboardingUiState,
    viewModel: OnboardingViewModel
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md)
    ) {
        item {
            SectionHeader(
                title = "Goal & Experience",
                subtitle = "Configures rep ranges, volume, and periodization"
            )
        }

        item {
            Text(
                text = "Primary Fitness Goal",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextHighEmphasis
            )
        }

        items(FitnessGoal.values()) { goal ->
            val isSelected = uiState.goal == goal
            val description = when (goal) {
                FitnessGoal.BUILD_MUSCLE -> "Hypertrophy focus (3 sets of 8–12 reps, 90s rest)"
                FitnessGoal.STRENGTH -> "Max force & neural drive (3 sets of 5–8 reps, 150s rest)"
                FitnessGoal.ENDURANCE -> "Stamina & conditioning (2–3 sets of 12–20 reps, 45s rest)"
                FitnessGoal.GENERAL -> "Balanced health, mobility & moderate strength (3 sets of 8–12 reps)"
                FitnessGoal.MAINTAIN -> "Time-efficient split (2 days/wk, 4 exercises, 2 sets of 8–12 reps, 75s rest)"
            }

            SelectableOptionCard(
                title = goal.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() },
                description = description,
                isSelected = isSelected,
                onClick = { viewModel.setGoal(goal) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            Text(
                text = "Training Experience",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextHighEmphasis
            )
        }

        items(ExperienceLevel.values()) { exp ->
            val isSelected = uiState.experience == exp
            val description = when (exp) {
                ExperienceLevel.BEGINNER -> "Less than 1 year structured lifting (Full Body, max 3 days/wk)"
                ExperienceLevel.INTERMEDIATE -> "1–3 years progressive training (Upper/Lower or Push/Pull/Legs)"
                ExperienceLevel.ADVANCED -> "3+ years refined lifting mechanics and high work capacity"
            }

            SelectableOptionCard(
                title = exp.name.lowercase().replaceFirstChar { it.uppercase() },
                description = description,
                isSelected = isSelected,
                onClick = { viewModel.setExperience(exp) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            PrimaryButton(
                text = "Continue",
                onClick = { viewModel.nextStep() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// -------------------------------------------------------------
// Step 3: Location and Equipment
// -------------------------------------------------------------
@Composable
private fun Step3LocationAndEquipment(
    uiState: OnboardingUiState,
    viewModel: OnboardingViewModel
) {
    val equipmentOptions = listOf(
        "Bodyweight only",
        "Dumbbells",
        "Resistance band",
        "Pull-up bar",
        "Bench",
        "Full gym"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md)
    ) {
        item {
            SectionHeader(
                title = "Training Environment",
                subtitle = "We tailor exercises to what you actually have access to"
            )
        }

        item {
            Text(
                text = "Primary Location",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextHighEmphasis
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
            ) {
                UnitOptionButton(
                    text = "Home Workout",
                    isSelected = uiState.location == TrainingLocation.HOME,
                    onClick = { viewModel.setLocation(TrainingLocation.HOME) },
                    modifier = Modifier.weight(1f)
                )
                UnitOptionButton(
                    text = "Commercial Gym",
                    isSelected = uiState.location == TrainingLocation.GYM,
                    onClick = { viewModel.setLocation(TrainingLocation.GYM) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
            Text(
                text = "Available Equipment",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = TextHighEmphasis
            )
        }

        items(equipmentOptions) { item ->
            val isChecked = uiState.selectedEquipment.contains(item)
            val subText = when (item) {
                "Bodyweight only" -> "Calisthenics, push-ups, squats, floor core"
                "Dumbbells" -> "Adjustable or fixed dumbbell pairs"
                "Resistance band" -> "Loop or handle resistance bands"
                "Pull-up bar" -> "Doorframe or mounted pull-up bar"
                "Bench" -> "Flat or adjustable incline utility bench"
                "Full gym" -> "Machines, cables, racks, and barbells"
                else -> ""
            }

            RepwiseCard(
                onClick = { viewModel.toggleEquipment(item) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isChecked,
                        onCheckedChange = { viewModel.toggleEquipment(item) },
                        colors = CheckboxDefaults.colors(
                            checkedColor = RepwiseLime,
                            checkmarkColor = RepwiseOnLime,
                            uncheckedColor = TextSecondary
                        )
                    )
                    Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                    Column {
                        Text(
                            text = item,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                        Text(
                            text = subText,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            PrimaryButton(
                text = "Continue",
                onClick = { viewModel.nextStep() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// -------------------------------------------------------------
// Step 4: Available Training Days (Weekdays)
// -------------------------------------------------------------
@Composable
private fun Step4Schedule(
    uiState: OnboardingUiState,
    viewModel: OnboardingViewModel
) {
    val weekdays = listOf(
        1 to "Monday",
        2 to "Tuesday",
        3 to "Wednesday",
        4 to "Thursday",
        5 to "Friday",
        6 to "Saturday",
        7 to "Sunday"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md)
    ) {
        item {
            SectionHeader(
                title = "Available Training Days",
                subtitle = "Select which days of the week you can train"
            )
        }

        if (uiState.experience == ExperienceLevel.BEGINNER && uiState.selectedWeekdays.size > 3) {
            item {
                RepwiseCard(containerColor = CharcoalSurfaceElevated) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = RepwiseLime,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Beginners get better results starting with 3 days.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextHighEmphasis
                        )
                    }
                }
            }
        }

        items(weekdays) { (dayNum, dayName) ->
            val isChecked = uiState.selectedWeekdays.contains(dayNum)

            RepwiseCard(
                onClick = { viewModel.toggleWeekday(dayNum) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { viewModel.toggleWeekday(dayNum) },
                            colors = CheckboxDefaults.colors(
                                checkedColor = RepwiseLime,
                                checkmarkColor = RepwiseOnLime,
                                uncheckedColor = TextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                        Text(
                            text = dayName,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isChecked) TextHighEmphasis else TextSecondary
                        )
                    }

                    if (isChecked) {
                        Text(
                            text = "Workout",
                            style = MaterialTheme.typography.labelSmall,
                            color = RepwiseLime
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            SectionHeader(
                title = "Training style",
                subtitle = "Choose how your workouts are divided"
            )
        }

        val styles = listOf(
            Triple(TrainingStyle.AUTO, "Let REPWISE decide", "Picks a split from your days and experience."),
            Triple(TrainingStyle.FULL_BODY, "Full body", "Your whole body each session."),
            Triple(TrainingStyle.UPPER_LOWER, "Upper / lower", "Alternate upper-body and lower-body days."),
            Triple(TrainingStyle.PUSH_PULL_LEGS, "Push / pull / legs", "Pushing, pulling and leg days."),
            Triple(TrainingStyle.BODY_PART, "Body-part split", "One or two muscle groups per day, like chest day and leg day.")
        )

        items(styles) { (style, title, description) ->
            val isSelected = uiState.trainingStyle == style
            val range = PlanGenerator.styleDayRange(style)
            val numDays = uiState.selectedWeekdays.size

            val hint = if (isSelected && style != TrainingStyle.AUTO) {
                when {
                    numDays < range.first -> "Needs at least ${range.first} training days, we'll use Full Body instead."
                    numDays > range.last -> "Works with up to ${range.last} days."
                    else -> null
                }
            } else {
                null
            }

            RepwiseCard(
                onClick = { viewModel.selectTrainingStyle(style) },
                borderColor = if (isSelected) RepwiseLime else CharcoalBorderSubtle,
                containerColor = if (isSelected) CharcoalSurfaceElevated else CharcoalSurface
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) RepwiseLime else CharcoalSurfaceElevated)
                                .border(1.dp, if (isSelected) RepwiseLime else CharcoalBorder, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = RepwiseOnLime,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(RepwiseSpacing.md))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (isSelected) RepwiseLime else TextHighEmphasis
                            )
                            Text(
                                text = description,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    if (hint != null) {
                        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                        Text(
                            text = hint,
                            style = MaterialTheme.typography.labelSmall,
                            color = RepwiseLime,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            PrimaryButton(
                text = "Continue",
                onClick = { viewModel.nextStep() },
                modifier = Modifier.fillMaxWidth(),
                enabled = uiState.selectedWeekdays.isNotEmpty()
            )
        }
    }
}

// -------------------------------------------------------------
// Step 5: Health Notice
// -------------------------------------------------------------
@Composable
private fun Step5HealthNotice(
    uiState: OnboardingUiState,
    viewModel: OnboardingViewModel
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md)
    ) {
        item {
            SectionHeader(
                title = "Health & Safety Notice",
                subtitle = "Please read carefully before generating your program"
            )
        }

        item {
            RepwiseCard(containerColor = CharcoalSurfaceElevated) {
                Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                    Text(
                        text = "REPWISE gives general fitness guidance, not medical advice. If you have a health condition, injury, or are unsure whether exercise is safe for you, check with a doctor first.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextHighEmphasis
                    )
                }
            }
        }

        item {
            RepwiseCard(
                onClick = { viewModel.setHealthNoticeAcknowledged(!uiState.healthNoticeAcknowledged) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = uiState.healthNoticeAcknowledged,
                        onCheckedChange = { viewModel.setHealthNoticeAcknowledged(it) },
                        colors = CheckboxDefaults.colors(
                            checkedColor = RepwiseLime,
                            checkmarkColor = RepwiseOnLime,
                            uncheckedColor = TextSecondary
                        )
                    )
                    Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                    Text(
                        text = "I understand",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextHighEmphasis
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            PrimaryButton(
                text = "Continue to Assessment",
                onClick = { viewModel.nextStep() },
                modifier = Modifier.fillMaxWidth(),
                enabled = uiState.healthNoticeAcknowledged
            )
        }
    }
}

// -------------------------------------------------------------
// Step 6: Summary + BMI Result + "Create my plan"
// -------------------------------------------------------------
@Composable
private fun Step6SummaryAndBmi(
    uiState: OnboardingUiState,
    viewModel: OnboardingViewModel
) {
    val bmi = uiState.bmiResult

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md)
    ) {
        item {
            SectionHeader(
                title = "Assessment Summary",
                subtitle = "Review your baseline before generating your split"
            )
        }

        // Profile Details Card
        item {
            RepwiseCard {
                Text(
                    text = "Profile Baseline",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                SummaryRow("Age", "${uiState.ageText} years")
                val heightStr = if (uiState.unitSystem == "IMPERIAL") {
                    "${uiState.heightFeetText}' ${uiState.heightInchesText}\""
                } else {
                    "${uiState.heightCmText} cm"
                }
                SummaryRow("Height", heightStr)
                SummaryRow("Weight", "${uiState.weightText} ${if (uiState.unitSystem == "IMPERIAL") "lbs" else "kg"}")
                SummaryRow("Goal", uiState.goal.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() })
                SummaryRow("Experience", uiState.experience.name.lowercase().replaceFirstChar { it.uppercase() })
                SummaryRow("Location", uiState.location.name.lowercase().replaceFirstChar { it.uppercase() })
                SummaryRow("Weekly Days", "${uiState.selectedWeekdays.size} days selected")
            }
        }

        // BMI Card
        item {
            RepwiseCard(containerColor = CharcoalSurfaceElevated) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Calculated BMI",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                        Text(
                            text = bmi?.formattedBmi ?: "-",
                            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                            color = RepwiseLime
                        )
                    }

                    if (bmi?.category != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(RepwiseLimeMuted)
                                .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                        ) {
                            Text(
                                text = bmi.category,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                // Explanatory note
                if (bmi != null) {
                    Text(
                        text = bmi.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            PrimaryButton(
                text = "Create my plan",
                onClick = { viewModel.createPlan() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// -------------------------------------------------------------
// Step 7: Plan Preview
// -------------------------------------------------------------
@Composable
private fun Step7PlanPreview(
    uiState: OnboardingUiState,
    viewModel: OnboardingViewModel
) {
    val plan = uiState.generatedPlan

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md)
    ) {
        item {
            SectionHeader(
                title = plan?.title ?: "Personalized Split",
                subtitle = "Deterministic prescription based on your goal & equipment"
            )
        }

        // Notes and Beginner Advisories
        if (!plan?.notes.isNullOrEmpty()) {
            items(plan?.notes ?: emptyList()) { note ->
                RepwiseCard(containerColor = CharcoalSurfaceElevated) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = RepwiseLime,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = note,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextHighEmphasis
                        )
                    }
                }
            }
        }

        // Recovery Note
        item {
            RepwiseCard(containerColor = CharcoalSurfaceElevated) {
                Text(
                    text = "Recovery Guidance",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                Text(
                    text = plan?.recoveryNote ?: PlanGenerator.RECOVERY_NOTE,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        // Days & Exercises
        if (plan != null) {
            items(plan.days) { day ->
                RepwiseCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${day.weekdayName} • ${day.dayName}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                        Text(
                            text = "${day.exercises.size} movements",
                            style = MaterialTheme.typography.labelSmall,
                            color = RepwiseLime
                        )
                    }

                    Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                    Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                        day.exercises.forEachIndexed { idx, ex ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CharcoalSurfaceElevated),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${idx + 1}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = TextSecondary
                                    )
                                }

                                Spacer(modifier = Modifier.width(RepwiseSpacing.sm))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = ex.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = TextHighEmphasis
                                    )
                                    Text(
                                        text = ex.summaryText,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Buttons: "Use this plan" and "Back"
        item {
            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
            PrimaryButton(
                text = "Use this plan",
                onClick = { viewModel.requestUsePlan() },
                modifier = Modifier.fillMaxWidth(),
                enabled = !uiState.isLoading
            )
            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
            SecondaryButton(
                text = "Back",
                onClick = { viewModel.previousStep() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// -------------------------------------------------------------
// Shared UI Components
// -------------------------------------------------------------
@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = RepwiseSpacing.xxs),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = TextHighEmphasis)
    }
}

@Composable
private fun SelectableOptionCard(
    title: String,
    description: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    RepwiseCard(
        onClick = onClick,
        containerColor = if (isSelected) CharcoalSurfaceElevated else CharcoalSurface
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) RepwiseLime else CharcoalSurfaceElevated)
                    .border(1.dp, if (isSelected) RepwiseLime else CharcoalBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = RepwiseOnLime,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(RepwiseSpacing.md))

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    ),
                    color = if (isSelected) RepwiseLime else TextHighEmphasis
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun UnitOptionButton(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) RepwiseLime else CharcoalSurfaceElevated)
            .border(1.dp, if (isSelected) RepwiseLime else CharcoalBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = RepwiseSpacing.sm, horizontal = RepwiseSpacing.md),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isSelected) RepwiseOnLime else TextHighEmphasis
        )
    }
}

@Composable
private fun outlinedFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = RepwiseLime,
    unfocusedBorderColor = CharcoalBorder,
    focusedLabelColor = RepwiseLime,
    unfocusedLabelColor = TextSecondary,
    cursorColor = RepwiseLime,
    focusedTextColor = TextHighEmphasis,
    unfocusedTextColor = TextHighEmphasis
)
