package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.ui.navigation.RepwiseBottomBar
import com.example.ui.navigation.RepwiseDestination
import com.example.ui.navigation.RepwiseNavGraph
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.RepwiseTheme

import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RepwiseTheme {
                RepwiseApp()
            }
        }
    }
}

@Composable
fun RepwiseApp() {
    val context = LocalContext.current
    val repository = remember { RepwiseRepositoryImpl(context) }
    var isCheckingProfile by remember { mutableStateOf(true) }
    var shouldShowOnboarding by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        repository.ensureCatalogInitialized()
        val profile = repository.getUserProfileEntityOnce()
        if (profile != null) {
            com.example.util.WeightHelper.activeUnit = if (profile.unitSystem.equals("IMPERIAL", ignoreCase = true)) {
                com.example.util.WeightUnit.LBS
            } else {
                com.example.util.WeightUnit.KG
            }
        }
        shouldShowOnboarding = (profile == null || !profile.onboardingCompleted)
        isCheckingProfile = false
    }

    if (isCheckingProfile) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CharcoalBackground)
        )
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val isTopLevelDestination = RepwiseDestination.bottomNavDestinations.any { it.route == currentRoute }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBackground),
        containerColor = CharcoalBackground,
        bottomBar = {
            if (isTopLevelDestination) {
                RepwiseBottomBar(
                    currentRoute = currentRoute,
                    onNavigateToDestination = { destination ->
                        navController.navigate(destination.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        RepwiseNavGraph(
            navController = navController,
            startDestination = if (shouldShowOnboarding) RepwiseDestination.Onboarding.route else RepwiseDestination.Home.route,
            modifier = Modifier.padding(
                bottom = if (isTopLevelDestination) innerPadding.calculateBottomPadding() else 0.dp,
                top = if (isTopLevelDestination) innerPadding.calculateTopPadding() else 0.dp
            )
        )
    }
}

