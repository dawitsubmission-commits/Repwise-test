package com.example.data.local

import android.content.Context
import android.util.Log
import com.example.data.local.dao.ExerciseDao
import com.example.data.local.entities.ExerciseEntity
import com.example.data.local.entities.ExerciseSecondaryMuscleEntity
import com.example.domain.normalization.Normalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader

object ExerciseCatalogImporter {

    private const val TAG = "ExerciseCatalogImporter"

    /**
     * Imports or updates catalog/exercises.json into Room database tables `exercise`
     * and `exercise_secondary_muscle` in a single transaction if the record count
     * in assets differs from the database table count.
     * Runs at every app start.
     * Uses upsert (ON CONFLICT DO UPDATE) and rewrites secondary muscles.
     * Errors per record are caught and skipped so one bad value never leaves the library empty.
     */
    suspend fun importCatalogIfEmpty(context: Context, dao: ExerciseDao) = importCatalogIfNeeded(context, dao)

    suspend fun importCatalogIfNeeded(context: Context, dao: ExerciseDao) = withContext(Dispatchers.IO) {
        val jsonString = try {
            context.assets.open("catalog/exercises.json").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    reader.readText()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read catalog/exercises.json from assets", e)
            return@withContext
        }

        val jsonArray = try {
            JSONArray(jsonString)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse catalog JSON", e)
            return@withContext
        }

        val assetCount = jsonArray.length()
        val dbCount = dao.getExerciseCount()

        // If the record count in assets differs from exercise table count, upsert all
        if (assetCount != dbCount) {
            val exercises = ArrayList<ExerciseEntity>(assetCount)
            val secondaries = ArrayList<ExerciseSecondaryMuscleEntity>()

            for (i in 0 until assetCount) {
                try {
                    val item = jsonArray.getJSONObject(i)
                    val id = item.getString("id") // Keep leading zeros (String ID)
                    val name = item.getString("name")
                    val bodyPart = item.optString("bodyPart", "")
                    val rawEquipment = item.getString("equipment")
                    val rawTarget = item.getString("target")

                    // Normalize target and equipment using the unified normalizer
                    val normalizedTarget = Normalizer.normalizeMuscle(rawTarget)
                    val normalizedEquipment = Normalizer.normalizeEquipment(rawEquipment)

                    val movementPattern = if (item.has("movementPattern") && !item.isNull("movementPattern")) {
                        item.getString("movementPattern")
                    } else null

                    // Store instructions as JSON text
                    val instructionsJson = if (item.has("instructions") && !item.isNull("instructions")) {
                        item.getJSONArray("instructions").toString()
                    } else "[]"

                    val dataLicense = item.optString("dataLicense", null)
                    val mediaStatus = item.optString("mediaStatus", null)

                    // Animation details (can be null for entries like 0558, 1366)
                    var frame00: String? = null
                    var frame01: String? = null
                    var frame02: String? = null
                    var sequenceJson: String? = null
                    var frameDurationMs: Long? = null
                    var animationLicense: String? = null

                    if (item.has("animation") && !item.isNull("animation")) {
                        val animObj = item.getJSONObject("animation")
                        val frames = animObj.optJSONArray("frames")
                        if (frames != null && frames.length() >= 3) {
                            frame00 = frames.getString(0)
                            frame01 = frames.getString(1)
                            frame02 = frames.getString(2)
                        }
                        sequenceJson = animObj.optJSONArray("sequence")?.toString() ?: "[0,1,2,1]"
                        frameDurationMs = if (animObj.has("frameDurationMs")) animObj.getLong("frameDurationMs") else 180L
                        animationLicense = animObj.optString("license", null)
                    }

                    val exerciseEntity = ExerciseEntity(
                        id = id,
                        name = name,
                        bodyPart = bodyPart,
                        equipment = normalizedEquipment,
                        target = normalizedTarget,
                        movementPattern = movementPattern,
                        instructionsJson = instructionsJson,
                        dataLicense = dataLicense,
                        mediaStatus = mediaStatus,
                        frame00Path = frame00,
                        frame01Path = frame01,
                        frame02Path = frame02,
                        sequenceJson = sequenceJson,
                        frameDurationMs = frameDurationMs,
                        animationLicense = animationLicense
                    )
                    exercises.add(exerciseEntity)

                    // Normalize secondary muscles and collect entities
                    val secMusclesArray = item.optJSONArray("secondaryMuscles")
                    if (secMusclesArray != null) {
                        val seenMusclesForExercise = HashSet<String>()
                        for (j in 0 until secMusclesArray.length()) {
                            try {
                                val rawSec = secMusclesArray.getString(j)
                                val normalizedSec = Normalizer.normalizeMuscle(rawSec)
                                if (seenMusclesForExercise.add(normalizedSec)) {
                                    secondaries.add(
                                        ExerciseSecondaryMuscleEntity(
                                            exerciseId = id,
                                            muscle = normalizedSec
                                        )
                                    )
                                }
                            } catch (e: Exception) {
                                Log.w(TAG, "Skipping secondary muscle in exercise $id: ${e.message}")
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Catch errors per record, skip the bad record, and keep going
                    Log.e(TAG, "Error importing exercise at index $i, skipping", e)
                }
            }

            if (exercises.isNotEmpty()) {
                // Upsert all exercises and rewrite secondary muscles in one atomic transaction
                dao.upsertCatalog(exercises, secondaries)
            }
        }
    }
}
