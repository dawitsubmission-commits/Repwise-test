package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.SessionExerciseEntity
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: WorkoutSessionEntity): Long

    @Update
    suspend fun updateSession(session: WorkoutSessionEntity)

    @Delete
    suspend fun deleteSession(session: WorkoutSessionEntity)

    @Query("DELETE FROM workout_session WHERE id = :sessionId")
    suspend fun deleteSessionById(sessionId: Long)

    @Query("UPDATE workout_session SET status = :status, endedAt = :endedAt WHERE id = :sessionId")
    suspend fun updateSessionStatus(sessionId: Long, status: String, endedAt: Long?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionExercise(exercise: SessionExerciseEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionExercises(exercises: List<SessionExerciseEntity>): List<Long>

    @Update
    suspend fun updateSessionExercise(exercise: SessionExerciseEntity)

    @Query("SELECT * FROM session_exercise WHERE id = :sessionExerciseId")
    suspend fun getSessionExerciseById(sessionExerciseId: Long): SessionExerciseEntity?

    @Query("UPDATE session_exercise SET note = :note WHERE id = :id")
    suspend fun updateExerciseNote(id: Long, note: String?)

    @Query("DELETE FROM session_exercise WHERE id = :sessionExerciseId")
    suspend fun deleteSessionExerciseById(sessionExerciseId: Long)

    @Query("UPDATE session_exercise SET position = position + 1 WHERE sessionId = :sessionId AND position > :afterPosition")
    suspend fun shiftLaterExercisePositions(sessionId: Long, afterPosition: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetLog(setLog: SetLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetLogs(setLogs: List<SetLogEntity>): List<Long>

    @Update
    suspend fun updateSetLog(setLog: SetLogEntity)

    @Query("DELETE FROM set_log WHERE id = :setLogId")
    suspend fun deleteSetLogById(setLogId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPersonalRecord(pr: PersonalRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPersonalRecords(prs: List<PersonalRecordEntity>): List<Long>

    @Query("SELECT * FROM personal_record WHERE exerciseId = :exerciseId ORDER BY achievedAt DESC")
    fun getPersonalRecordsForExercise(exerciseId: String): Flow<List<PersonalRecordEntity>>

    @Query("SELECT * FROM personal_record WHERE exerciseId = :exerciseId ORDER BY achievedAt DESC")
    suspend fun getPersonalRecordsForExerciseOnce(exerciseId: String): List<PersonalRecordEntity>

    @Query("SELECT * FROM personal_record ORDER BY achievedAt DESC")
    fun getAllPersonalRecords(): Flow<List<PersonalRecordEntity>>

    @Query("SELECT * FROM personal_record ORDER BY achievedAt DESC")
    suspend fun getAllPersonalRecordsOnce(): List<PersonalRecordEntity>

    @Transaction
    @Query("SELECT * FROM workout_session WHERE id = :sessionId")
    fun getSessionWithExercisesById(sessionId: Long): Flow<WorkoutSessionWithExercises?>

    @Transaction
    @Query("SELECT * FROM workout_session WHERE id = :sessionId")
    suspend fun getSessionWithExercisesByIdOnce(sessionId: Long): WorkoutSessionWithExercises?

    @Transaction
    @Query("SELECT * FROM workout_session WHERE status = 'IN_PROGRESS' ORDER BY startedAt DESC LIMIT 1")
    fun getActiveInProgressSession(): Flow<WorkoutSessionWithExercises?>

    @Transaction
    @Query("SELECT * FROM workout_session WHERE status = 'IN_PROGRESS' ORDER BY startedAt DESC LIMIT 1")
    suspend fun getActiveInProgressSessionOnce(): WorkoutSessionWithExercises?

    @Transaction
    @Query("SELECT * FROM workout_session WHERE status = 'COMPLETED' ORDER BY endedAt DESC")
    fun getCompletedSessions(): Flow<List<WorkoutSessionWithExercises>>

    @Transaction
    @Query("SELECT * FROM workout_session WHERE status = 'COMPLETED' ORDER BY endedAt DESC")
    suspend fun getCompletedSessionsOnce(): List<WorkoutSessionWithExercises>

    @Transaction
    @Query("SELECT * FROM workout_session ORDER BY startedAt DESC")
    fun getAllSessions(): Flow<List<WorkoutSessionWithExercises>>

    @Transaction
    @Query("SELECT * FROM workout_session ORDER BY startedAt DESC")
    suspend fun getAllSessionsOnce(): List<WorkoutSessionWithExercises>

    @Query("SELECT * FROM set_log WHERE sessionExerciseId = :sessionExerciseId ORDER BY setIndex ASC")
    suspend fun getSetsForSessionExercise(sessionExerciseId: Long): List<SetLogEntity>
}
