package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey
    val id: Int = 1,
    val age: Int,
    val heightCm: Double,
    val weightKg: Double,
    val experience: String, // BEGINNER, INTERMEDIATE, ADVANCED
    val goal: String, // BUILD_MUSCLE, STRENGTH, ENDURANCE, GENERAL, MAINTAIN
    val equipment: String, // comma separated keys
    val location: String, // HOME, GYM
    val trainingWeekdays: String, // comma separated 1-7 (1=Monday ... 7=Sunday)
    val unitSystem: String, // METRIC, IMPERIAL
    val healthNoticeAcknowledged: Boolean,
    val onboardingCompleted: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)
