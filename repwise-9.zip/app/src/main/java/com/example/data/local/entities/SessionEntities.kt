package com.example.data.local.entities

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

object WorkoutSessionStatus {
    const val IN_PROGRESS = "IN_PROGRESS"
    const val COMPLETED = "COMPLETED"
    const val DISCARDED = "DISCARDED"
}

object PersonalRecordType {
    const val HEAVIEST_WEIGHT = "HEAVIEST_WEIGHT"
    const val BEST_E1RM = "BEST_E1RM"
    const val BEST_REPS_AT_WEIGHT = "BEST_REPS_AT_WEIGHT"
}

@Entity(
    tableName = "workout_session",
    indices = [
        Index("status"),
        Index("planDayId"),
        Index("startedAt")
    ]
)
data class WorkoutSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val planDayId: Long? = null,
    val dayName: String,
    val startedAt: Long = System.currentTimeMillis(),
    val endedAt: Long? = null,
    val status: String = WorkoutSessionStatus.IN_PROGRESS,
    val note: String? = null
)

@Entity(
    tableName = "session_exercise",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("sessionId"),
        Index("exerciseId")
    ]
)
data class SessionExerciseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionId: Long,
    val exerciseId: String, // String ID keeping leading zeros
    val position: Int = 0,
    val note: String? = null,
    val replacedExerciseId: String? = null
)

@Entity(
    tableName = "set_log",
    foreignKeys = [
        ForeignKey(
            entity = SessionExerciseEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionExerciseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("sessionExerciseId")
    ]
)
data class SetLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionExerciseId: Long,
    val setIndex: Int,
    val reps: Int,
    val weightKg: Double,
    val isWarmup: Boolean = false,
    val completedAt: Long? = null
)

@Entity(
    tableName = "personal_record",
    indices = [
        Index("exerciseId"),
        Index("type"),
        Index("setLogId")
    ]
)
data class PersonalRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val exerciseId: String,
    val type: String, // HEAVIEST_WEIGHT, BEST_E1RM, BEST_REPS_AT_WEIGHT
    val value: Double,
    val setLogId: Long,
    val achievedAt: Long = System.currentTimeMillis()
)

data class SessionExerciseWithSets(
    @Embedded
    val exercise: SessionExerciseEntity,

    @Relation(
        parentColumn = "id",
        entityColumn = "sessionExerciseId"
    )
    val sets: List<SetLogEntity>
)

data class WorkoutSessionWithExercises(
    @Embedded
    val session: WorkoutSessionEntity,

    @Relation(
        entity = SessionExerciseEntity::class,
        parentColumn = "id",
        entityColumn = "sessionId"
    )
    val exercises: List<SessionExerciseWithSets>
)
