package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entities.PlanDayEntity
import com.example.data.local.entities.PlanDayWithExercises
import com.example.data.local.entities.PlanExerciseEntity
import com.example.data.local.entities.WorkoutPlanEntity
import com.example.data.local.entities.WorkoutPlanWithDays
import kotlinx.coroutines.flow.Flow

@Dao
interface PlanDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: WorkoutPlanEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDays(days: List<PlanDayEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDay(day: PlanDayEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlanExercises(exercises: List<PlanExerciseEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlanExercise(exercise: PlanExerciseEntity): Long

    @Update
    suspend fun updatePlan(plan: WorkoutPlanEntity)

    @Update
    suspend fun updateDay(day: PlanDayEntity)

    @Update
    suspend fun updateDays(days: List<PlanDayEntity>)

    @Update
    suspend fun updatePlanExercise(exercise: PlanExerciseEntity)

    @Update
    suspend fun updatePlanExercises(exercises: List<PlanExerciseEntity>)

    @Delete
    suspend fun deletePlan(plan: WorkoutPlanEntity)

    @Delete
    suspend fun deleteDay(day: PlanDayEntity)

    @Delete
    suspend fun deletePlanExercise(exercise: PlanExerciseEntity)

    @Query("DELETE FROM plan_exercise WHERE id = :id")
    suspend fun deletePlanExerciseById(id: Long)

    @Query("DELETE FROM plan_day WHERE id = :id")
    suspend fun deleteDayById(id: Long)

    @Query("DELETE FROM workout_plan WHERE id = :id")
    suspend fun deletePlanById(id: Long)

    @Transaction
    @Query("SELECT * FROM workout_plan ORDER BY createdAt DESC")
    fun getAllPlansWithDays(): Flow<List<WorkoutPlanWithDays>>

    @Transaction
    @Query("SELECT * FROM workout_plan WHERE id = :planId")
    fun getPlanWithDaysById(planId: Long): Flow<WorkoutPlanWithDays?>

    @Transaction
    @Query("SELECT * FROM workout_plan WHERE id = :planId")
    suspend fun getPlanWithDaysByIdOnce(planId: Long): WorkoutPlanWithDays?

    @Transaction
    @Query("SELECT * FROM workout_plan WHERE isActive = 1 LIMIT 1")
    fun getActivePlanWithDays(): Flow<WorkoutPlanWithDays?>

    @Transaction
    @Query("SELECT * FROM workout_plan WHERE isActive = 1 LIMIT 1")
    suspend fun getActivePlanWithDaysOnce(): WorkoutPlanWithDays?

    @Transaction
    @Query("SELECT * FROM plan_day WHERE id = :dayId")
    suspend fun getPlanDayWithExercisesByIdOnce(dayId: Long): PlanDayWithExercises?

    @Query("UPDATE workout_plan SET isActive = CASE WHEN id = :activePlanId THEN 1 ELSE 0 END")
    suspend fun setActivePlan(activePlanId: Long)

    @Query("SELECT COUNT(*) FROM workout_plan")
    suspend fun getPlanCount(): Int

    @Query("DELETE FROM workout_plan WHERE templateKey = 'generated'")
    suspend fun deleteGeneratedPlans()
}
