package com.example.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.data.local.ExerciseCatalogImporter
import com.example.data.local.RepwiseDatabase
import com.example.data.local.entities.ExerciseWithSecondaries
import com.example.data.local.entities.PlanDayEntity
import com.example.data.local.entities.PlanExerciseEntity
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.SessionExerciseEntity
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.domain.PersonalRecordDetector
import com.example.domain.PreviousPerformance
import com.example.domain.PreviousPerformanceFinder
import com.example.domain.models.CatalogExercise
import com.example.domain.models.Exercise
import com.example.domain.models.MuscleGroup
import com.example.domain.models.PlanDay
import com.example.domain.models.UserProfile
import com.example.domain.models.WorkoutStat
import com.example.domain.models.WorkoutTemplate
import com.example.domain.repository.RepwiseRepository
import com.example.domain.repository.StartWorkoutResult
import com.example.domain.templates.TemplateRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import org.json.JSONArray

class RepwiseRepositoryImpl(
    private val context: Context? = null
) : RepwiseRepository {

    private val database: RepwiseDatabase? = context?.let { RepwiseDatabase.getInstance(it) }

    override fun getComputedStatsFlow(): Flow<com.example.domain.stats.ComputedWorkoutStats> {
        val completedFlow = getCompletedSessions()
        val prsFlow = getAllPersonalRecords()
        return kotlinx.coroutines.flow.combine(completedFlow, prsFlow) { sessions, prs ->
            com.example.domain.stats.WorkoutStatsCalculator.computeStats(sessions, prs)
        }
    }

    override suspend fun ensureCatalogInitialized() {
        if (context != null && database != null) {
            ExerciseCatalogImporter.importCatalogIfEmpty(context, database.exerciseDao())
        }
    }

    override fun getCatalogExercises(): Flow<List<CatalogExercise>> {
        val dao = database?.exerciseDao()
        return if (dao != null) {
            dao.getAllExercises().map { list ->
                list.map { it.toDomain() }
            }
        } else {
            flowOf(emptyList())
        }
    }

    override fun getCatalogExerciseById(id: String): Flow<CatalogExercise?> {
        val dao = database?.exerciseDao()
        return if (dao != null) {
            dao.getExerciseById(id).map { it?.toDomain() }
        } else {
            flowOf(null)
        }
    }

    override fun getAllWorkoutPlans(): Flow<List<WorkoutPlanWithDays>> {
        val dao = database?.planDao()
        return dao?.getAllPlansWithDays() ?: flowOf(emptyList())
    }

    override fun getWorkoutPlanById(planId: Long): Flow<WorkoutPlanWithDays?> {
        val dao = database?.planDao()
        return dao?.getPlanWithDaysById(planId) ?: flowOf(null)
    }

    override fun getActiveWorkoutPlan(): Flow<WorkoutPlanWithDays?> {
        val dao = database?.planDao()
        return dao?.getActivePlanWithDays() ?: flowOf(null)
    }

    override suspend fun saveWorkoutPlan(planWithDays: WorkoutPlanWithDays): Long {
        val db = database ?: return 0L
        val planDao = db.planDao()

        return db.withTransaction {
            // Check if this is the first plan in DB; if so, make it active
            val existingCount = planDao.getPlanCount()
            val shouldBeActive = planWithDays.plan.isActive || existingCount == 0

            val planToInsert = planWithDays.plan.copy(
                id = 0,
                isActive = shouldBeActive,
                createdAt = System.currentTimeMillis()
            )
            val newPlanId = planDao.insertPlan(planToInsert)

            if (shouldBeActive) {
                planDao.setActivePlan(newPlanId)
            }

            planWithDays.days.forEachIndexed { dayIdx, dayWithEx ->
                val dayToInsert = dayWithEx.day.copy(
                    id = 0,
                    planId = newPlanId,
                    position = dayIdx
                )
                val newDayId = planDao.insertDay(dayToInsert)

                val exercisesToInsert = dayWithEx.exercises.mapIndexed { exIdx, ex ->
                    ex.copy(
                        id = 0,
                        planDayId = newDayId,
                        position = exIdx
                    )
                }
                if (exercisesToInsert.isNotEmpty()) {
                    planDao.insertPlanExercises(exercisesToInsert)
                }
            }
            newPlanId
        }
    }

    override suspend fun updateWorkoutPlan(planWithDays: WorkoutPlanWithDays) {
        val db = database ?: return
        val planDao = db.planDao()

        db.withTransaction {
            planDao.updatePlan(planWithDays.plan)

            // Re-sync days: delete old days not in updated list, update or insert days
            val existingPlan = planDao.getPlanWithDaysByIdOnce(planWithDays.plan.id)
            val existingDayIds = existingPlan?.days?.map { it.day.id }?.toSet() ?: emptySet()
            val incomingDayIds = planWithDays.days.map { it.day.id }.filter { it > 0 }.toSet()

            // Delete removed days
            val toDeleteDayIds = existingDayIds - incomingDayIds
            toDeleteDayIds.forEach { planDao.deleteDayById(it) }

            // Insert or update incoming days
            planWithDays.days.forEachIndexed { dayIdx, dayWithEx ->
                val dayId = if (dayWithEx.day.id == 0L) {
                    planDao.insertDay(dayWithEx.day.copy(planId = planWithDays.plan.id, position = dayIdx))
                } else {
                    planDao.updateDay(dayWithEx.day.copy(position = dayIdx))
                    dayWithEx.day.id
                }

                // Sync exercises in this day
                val existingExIds = existingPlan?.days?.find { it.day.id == dayId }?.exercises?.map { it.id }?.toSet() ?: emptySet()
                val incomingExIds = dayWithEx.exercises.map { it.id }.filter { it > 0 }.toSet()

                val toDeleteExIds = existingExIds - incomingExIds
                toDeleteExIds.forEach { planDao.deletePlanExerciseById(it) }

                dayWithEx.exercises.forEachIndexed { exIdx, ex ->
                    if (ex.id == 0L) {
                        planDao.insertPlanExercise(ex.copy(planDayId = dayId, position = exIdx))
                    } else {
                        planDao.updatePlanExercise(ex.copy(planDayId = dayId, position = exIdx))
                    }
                }
            }
        }
    }

    override suspend fun deleteWorkoutPlan(planId: Long) {
        val db = database ?: return
        val planDao = db.planDao()
        db.withTransaction {
            val wasActive = planDao.getPlanWithDaysByIdOnce(planId)?.plan?.isActive == true
            planDao.deletePlanById(planId)

            if (wasActive) {
                // If the deleted plan was active, make another one active if available
                val remainingPlans = planDao.getActivePlanWithDaysOnce()
                if (remainingPlans == null) {
                    val firstRemaining = planDao.getPlanWithDaysByIdOnce(
                        // Find first remaining plan
                        0
                    )
                }
            }
        }
    }

    override suspend fun setActiveWorkoutPlan(planId: Long) {
        database?.planDao()?.setActivePlan(planId)
    }

    override suspend fun duplicateWorkoutPlan(planId: Long): Long {
        val original = database?.planDao()?.getPlanWithDaysByIdOnce(planId) ?: return 0L
        val cloned = TemplateRepository.duplicatePlan(original)
        return saveWorkoutPlan(cloned)
    }

    override suspend fun replaceExerciseInPlan(planExerciseId: Long, newExerciseId: String) {
        val db = database ?: return
        db.withTransaction {
            // Update exerciseId in place keeping sets, reps, rest
            db.openHelper.writableDatabase.execSQL(
                "UPDATE plan_exercise SET exerciseId = ? WHERE id = ?",
                arrayOf(newExerciseId, planExerciseId)
            )
        }
    }

    override suspend fun addExerciseToPlanDay(
        dayId: Long,
        exerciseId: String,
        sets: Int,
        repMin: Int,
        repMax: Int,
        restSeconds: Int
    ) {
        val dao = database?.planDao() ?: return
        val existingDay = dao.getPlanWithDaysByIdOnce(dayId) // check
        val position = 999
        dao.insertPlanExercise(
            PlanExerciseEntity(
                id = 0,
                planDayId = dayId,
                exerciseId = exerciseId,
                position = position,
                sets = sets,
                repMin = repMin,
                repMax = repMax,
                restSeconds = restSeconds
            )
        )
    }

    override suspend fun deletePlanExercise(planExerciseId: Long) {
        database?.planDao()?.deletePlanExerciseById(planExerciseId)
    }

    override suspend fun startWorkoutFromPlanDay(planDayId: Long): StartWorkoutResult {
        val inProgress = getActiveInProgressSessionOnce()
        if (inProgress != null) {
            return StartWorkoutResult.ExistingInProgress(inProgress.session.id)
        }

        val planDao = database?.planDao() ?: return StartWorkoutResult.Started(0L)
        val sessionDao = database.sessionDao()
        val dayWithExercises = planDao.getPlanDayWithExercisesByIdOnce(planDayId) ?: return StartWorkoutResult.Started(0L)

        val sessionId = sessionDao.insertSession(
            WorkoutSessionEntity(
                planDayId = planDayId,
                dayName = dayWithExercises.day.name,
                startedAt = System.currentTimeMillis(),
                status = WorkoutSessionStatus.IN_PROGRESS
            )
        )

        val allSessions = sessionDao.getAllSessionsOnce()
        val sortedExercises = dayWithExercises.exercises.sortedBy { it.position }

        for ((idx, planEx) in sortedExercises.withIndex()) {
            val prevPerf = PreviousPerformanceFinder.findPreviousPerformance(planEx.exerciseId, allSessions)
            val sessionExId = sessionDao.insertSessionExercise(
                SessionExerciseEntity(
                    sessionId = sessionId,
                    exerciseId = planEx.exerciseId,
                    position = idx,
                    note = planEx.note
                )
            )

            val setsCount = maxOf(1, planEx.sets)
            for (s in 0 until setsCount) {
                val prevSet = prevPerf?.sets?.getOrNull(s) ?: prevPerf?.sets?.lastOrNull()
                val reps = prevSet?.reps ?: planEx.repMin
                val weight = prevSet?.weightKg ?: 0.0

                sessionDao.insertSetLog(
                    SetLogEntity(
                        sessionExerciseId = sessionExId,
                        setIndex = s,
                        reps = reps,
                        weightKg = weight,
                        isWarmup = false,
                        completedAt = null
                    )
                )
            }
        }

        return StartWorkoutResult.Started(sessionId)
    }

    override suspend fun startEmptyWorkout(dayName: String): StartWorkoutResult {
        val inProgress = getActiveInProgressSessionOnce()
        if (inProgress != null) {
            return StartWorkoutResult.ExistingInProgress(inProgress.session.id)
        }

        val sessionDao = database?.sessionDao() ?: return StartWorkoutResult.Started(0L)
        val sessionId = sessionDao.insertSession(
            WorkoutSessionEntity(
                planDayId = null,
                dayName = dayName,
                startedAt = System.currentTimeMillis(),
                status = WorkoutSessionStatus.IN_PROGRESS
            )
        )
        return StartWorkoutResult.Started(sessionId)
    }

    override fun getActiveInProgressSession(): Flow<WorkoutSessionWithExercises?> {
        return database?.sessionDao()?.getActiveInProgressSession() ?: flowOf(null)
    }

    override suspend fun getActiveInProgressSessionOnce(): WorkoutSessionWithExercises? {
        return database?.sessionDao()?.getActiveInProgressSessionOnce()
    }

    override fun getSessionById(sessionId: Long): Flow<WorkoutSessionWithExercises?> {
        return database?.sessionDao()?.getSessionWithExercisesById(sessionId) ?: flowOf(null)
    }

    override suspend fun getSessionByIdOnce(sessionId: Long): WorkoutSessionWithExercises? {
        return database?.sessionDao()?.getSessionWithExercisesByIdOnce(sessionId)
    }

    override suspend fun updateSessionNote(sessionId: Long, note: String?) {
        val sessionDao = database?.sessionDao() ?: return
        val sessionWithEx = sessionDao.getSessionWithExercisesByIdOnce(sessionId) ?: return
        sessionDao.updateSession(sessionWithEx.session.copy(note = note))
    }

    override suspend fun updateExerciseNote(sessionExerciseId: Long, note: String?) {
        database?.sessionDao()?.updateExerciseNote(sessionExerciseId, note)
    }

    override suspend fun addExerciseToSession(
        sessionId: Long,
        exerciseId: String,
        setsCount: Int,
        repMin: Int,
        restSeconds: Int
    ): Long {
        val sessionDao = database?.sessionDao() ?: return 0L
        val sessionWithEx = sessionDao.getSessionWithExercisesByIdOnce(sessionId)
        val nextPos = (sessionWithEx?.exercises?.size ?: 0)

        val sessionExId = sessionDao.insertSessionExercise(
            SessionExerciseEntity(
                sessionId = sessionId,
                exerciseId = exerciseId,
                position = nextPos
            )
        )

        val allSessions = sessionDao.getAllSessionsOnce()
        val prevPerf = PreviousPerformanceFinder.findPreviousPerformance(exerciseId, allSessions)

        val count = maxOf(1, setsCount)
        for (s in 0 until count) {
            val prevSet = prevPerf?.sets?.getOrNull(s) ?: prevPerf?.sets?.lastOrNull()
            val reps = prevSet?.reps ?: repMin
            val weight = prevSet?.weightKg ?: 0.0

            sessionDao.insertSetLog(
                SetLogEntity(
                    sessionExerciseId = sessionExId,
                    setIndex = s,
                    reps = reps,
                    weightKg = weight,
                    isWarmup = false,
                    completedAt = null
                )
            )
        }

        return sessionExId
    }

    override suspend fun removeExerciseFromSession(sessionExerciseId: Long) {
        database?.sessionDao()?.deleteSessionExerciseById(sessionExerciseId)
    }

    override suspend fun addSetToExercise(
        sessionExerciseId: Long,
        weightKg: Double,
        reps: Int,
        isWarmup: Boolean
    ): Long {
        val sessionDao = database?.sessionDao() ?: return 0L
        val sets = sessionDao.getSetsForSessionExercise(sessionExerciseId)
        val nextIndex = sets.size
        return sessionDao.insertSetLog(
            SetLogEntity(
                sessionExerciseId = sessionExerciseId,
                setIndex = nextIndex,
                reps = reps,
                weightKg = weightKg,
                isWarmup = isWarmup,
                completedAt = null
            )
        )
    }

    override suspend fun updateSetLog(setLog: SetLogEntity) {
        database?.sessionDao()?.updateSetLog(setLog)
    }

    override suspend fun deleteSetLog(setLogId: Long) {
        database?.sessionDao()?.deleteSetLogById(setLogId)
    }

    override suspend fun substituteExercise(sessionExerciseId: Long, newExerciseId: String) {
        val db = database ?: return
        db.withTransaction {
            val sessionDao = db.sessionDao()
            val currentEx = sessionDao.getSessionExerciseById(sessionExerciseId) ?: return@withTransaction
            val sets = sessionDao.getSetsForSessionExercise(sessionExerciseId)

            val completedSets = sets.filter { it.completedAt != null }
            val pendingSets = sets.filter { it.completedAt == null }

            if (completedSets.isEmpty()) {
                // No sets were completed yet: directly update exerciseId and note replacedExerciseId
                sessionDao.updateSessionExercise(
                    currentEx.copy(
                        exerciseId = newExerciseId,
                        replacedExerciseId = currentEx.exerciseId
                    )
                )
            } else {
                // Do not create an empty replacement exercise if there are no pending sets
                if (pendingSets.isEmpty()) return@withTransaction

                // Shift positions of later exercises so positions stay unique
                sessionDao.shiftLaterExercisePositions(currentEx.sessionId, currentEx.position)

                // Keep done sets on the old exercise, move remaining sets to the replacement
                val replacementExerciseId = sessionDao.insertSessionExercise(
                    SessionExerciseEntity(
                        sessionId = currentEx.sessionId,
                        exerciseId = newExerciseId,
                        position = currentEx.position + 1,
                        replacedExerciseId = currentEx.exerciseId,
                        note = currentEx.note
                    )
                )

                // Re-assign pending sets to new exercise
                for (pending in pendingSets) {
                    sessionDao.updateSetLog(
                        pending.copy(sessionExerciseId = replacementExerciseId)
                    )
                }
            }
        }
    }

    override suspend fun finishSession(sessionId: Long): List<PersonalRecordEntity> {
        val db = database ?: return emptyList()
        return db.withTransaction {
            val sessionDao = db.sessionDao()
            val sessionWithEx = sessionDao.getSessionWithExercisesByIdOnce(sessionId) ?: return@withTransaction emptyList()

            // Idempotent: if already COMPLETED, return an empty list
            if (sessionWithEx.session.status == WorkoutSessionStatus.COMPLETED) {
                return@withTransaction emptyList()
            }

            val finishTime = System.currentTimeMillis()

            // 1. Mark session COMPLETED with endedAt
            sessionDao.updateSession(
                sessionWithEx.session.copy(
                    status = WorkoutSessionStatus.COMPLETED,
                    endedAt = finishTime
                )
            )

            // 2. Fetch all historical completed sessions excluding this session
            val allCompletedSessions = sessionDao.getCompletedSessionsOnce()
                .filter { it.session.id != sessionId }

            val newPRs = mutableListOf<PersonalRecordEntity>()

            // 3. For each exercise, detect PRs achieved from completed working sets
            for (sessionExWithSets in sessionWithEx.exercises) {
                val exId = sessionExWithSets.exercise.exerciseId
                val historicalSetsForEx = allCompletedSessions
                    .flatMap { cs ->
                        cs.exercises.filter { it.exercise.exerciseId == exId }.flatMap { it.sets }
                    }

                val detected = PersonalRecordDetector.detectNewPRsForExercise(
                    exerciseId = exId,
                    sessionSets = sessionExWithSets.sets,
                    priorHistoricalSets = historicalSetsForEx,
                    achievedAt = finishTime
                )

                if (detected.isNotEmpty()) {
                    sessionDao.insertPersonalRecords(detected)
                    newPRs.addAll(detected)
                }
            }

            newPRs
        }
    }

    override suspend fun discardSession(sessionId: Long) {
        val sessionDao = database?.sessionDao() ?: return
        sessionDao.updateSessionStatus(
            sessionId = sessionId,
            status = WorkoutSessionStatus.DISCARDED,
            endedAt = System.currentTimeMillis()
        )
    }

    override suspend fun getPreviousPerformance(exerciseId: String): PreviousPerformance? {
        val sessionDao = database?.sessionDao() ?: return null
        val allSessions = sessionDao.getAllSessionsOnce()
        return PreviousPerformanceFinder.findPreviousPerformance(exerciseId, allSessions)
    }

    override fun getCompletedSessions(): Flow<List<WorkoutSessionWithExercises>> {
        return database?.sessionDao()?.getCompletedSessions() ?: flowOf(emptyList())
    }

    override fun getAllPersonalRecords(): Flow<List<PersonalRecordEntity>> {
        return database?.sessionDao()?.getAllPersonalRecords() ?: flowOf(emptyList())
    }

    override fun getUserProfileFlow(): Flow<com.example.data.local.entities.UserProfileEntity?> {
        return database?.userProfileDao()?.getUserProfile() ?: flowOf(null)
    }

    override suspend fun getUserProfileEntityOnce(): com.example.data.local.entities.UserProfileEntity? {
        val profile = database?.userProfileDao()?.getUserProfileOnce()
        if (profile != null) {
            com.example.util.WeightHelper.activeUnit = if (profile.unitSystem.equals("IMPERIAL", ignoreCase = true)) {
                com.example.util.WeightUnit.LBS
            } else {
                com.example.util.WeightUnit.KG
            }
        }
        return profile
    }

    override suspend fun saveUserProfile(profile: com.example.data.local.entities.UserProfileEntity) {
        database?.userProfileDao()?.insertOrUpdateProfile(profile)
        com.example.util.WeightHelper.activeUnit = if (profile.unitSystem.equals("IMPERIAL", ignoreCase = true)) {
            com.example.util.WeightUnit.LBS
        } else {
            com.example.util.WeightUnit.KG
        }
    }

    override suspend fun saveGeneratedPlan(generatedPlan: com.example.domain.planner.GeneratedPlan): Long {
        val db = database ?: return 0L
        return db.withTransaction {
            val planDao = db.planDao()
            planDao.deleteGeneratedPlans()
            val planId = planDao.insertPlan(
                com.example.data.local.entities.WorkoutPlanEntity(
                    name = generatedPlan.title,
                    templateKey = "generated",
                    isActive = true
                )
            )
            planDao.setActivePlan(planId)

            for ((dayIndex, day) in generatedPlan.days.withIndex()) {
                val dayId = planDao.insertDay(
                    com.example.data.local.entities.PlanDayEntity(
                        planId = planId,
                        name = day.dayName,
                        weekday = day.assignedWeekday,
                        position = dayIndex
                    )
                )

                val planExercises = day.exercises.mapIndexed { exIndex, ex ->
                    com.example.data.local.entities.PlanExerciseEntity(
                        planDayId = dayId,
                        exerciseId = ex.exerciseId,
                        position = exIndex,
                        sets = ex.sets,
                        repMin = ex.repMin,
                        repMax = ex.repMax,
                        restSeconds = ex.restSeconds
                    )
                }
                planDao.insertPlanExercises(planExercises)
            }
            planId
        }
    }

    private fun ExerciseWithSecondaries.toDomain(): CatalogExercise {
        val instructionsList = try {
            val arr = JSONArray(exercise.instructionsJson)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }

        val sequenceList = try {
            if (exercise.sequenceJson != null) {
                val arr = JSONArray(exercise.sequenceJson)
                (0 until arr.length()).map { arr.getInt(it) }
            } else {
                listOf(0, 1, 2, 1)
            }
        } catch (e: Exception) {
            listOf(0, 1, 2, 1)
        }

        return CatalogExercise(
            id = exercise.id,
            name = exercise.name,
            bodyPart = exercise.bodyPart,
            equipment = exercise.equipment,
            target = exercise.target,
            secondaryMuscles = secondaryMuscles.map { it.muscle },
            instructions = instructionsList,
            movementPattern = exercise.movementPattern,
            frame00Path = exercise.frame00Path,
            frame01Path = exercise.frame01Path,
            frame02Path = exercise.frame02Path,
            frameDurationMs = exercise.frameDurationMs,
            sequence = sequenceList
        )
    }
}
