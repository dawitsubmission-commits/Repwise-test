package com.example.data.local.entities

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(
    tableName = "workout_plan",
    indices = [Index("isActive")]
)
data class WorkoutPlanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val templateKey: String? = null,
    val isActive: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "plan_day",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutPlanEntity::class,
            parentColumns = ["id"],
            childColumns = ["planId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("planId"),
        Index("weekday")
    ]
)
data class PlanDayEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val planId: Long,
    val name: String,
    val weekday: Int? = null, // 1 = Monday, 2 = Tuesday, ..., 7 = Sunday
    val position: Int = 0
)

@Entity(
    tableName = "plan_exercise",
    foreignKeys = [
        ForeignKey(
            entity = PlanDayEntity::class,
            parentColumns = ["id"],
            childColumns = ["planDayId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("planDayId"),
        Index("exerciseId")
    ]
)
data class PlanExerciseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val planDayId: Long,
    val exerciseId: String, // String ID keeping leading zeros
    val position: Int = 0,
    val sets: Int = 3,
    val repMin: Int = 8,
    val repMax: Int = 12,
    val restSeconds: Int = 90,
    val note: String? = null
)

data class PlanDayWithExercises(
    @Embedded
    val day: PlanDayEntity,

    @Relation(
        parentColumn = "id",
        entityColumn = "planDayId"
    )
    val exercises: List<PlanExerciseEntity>
)

data class WorkoutPlanWithDays(
    @Embedded
    val plan: WorkoutPlanEntity,

    @Relation(
        entity = PlanDayEntity::class,
        parentColumn = "id",
        entityColumn = "planId"
    )
    val days: List<PlanDayWithExercises>
)
