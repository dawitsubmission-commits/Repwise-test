package com.example.data.local.entities

import androidx.room.Embedded
import androidx.room.Relation

data class ExerciseWithSecondaries(
    @Embedded
    val exercise: ExerciseEntity,

    @Relation(
        parentColumn = "id",
        entityColumn = "exerciseId"
    )
    val secondaryMuscles: List<ExerciseSecondaryMuscleEntity>
)
