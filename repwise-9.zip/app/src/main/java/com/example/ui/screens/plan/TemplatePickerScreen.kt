package com.example.ui.screens.plan

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.models.CatalogExercise
import com.example.domain.templates.TemplateRepository
import com.example.domain.templates.WorkoutTemplateSpec
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun TemplatePickerScreen(
    onBack: () -> Unit,
    onTemplateCopied: (Long) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlanViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val templates = TemplateRepository.getAllTemplates()

    BackHandler {
        onBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .padding(WindowInsets.statusBars.asPaddingValues())
            .testTag("screen_template_picker")
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(CharcoalSurfaceElevated)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextHighEmphasis
                )
            }

            Spacer(modifier = Modifier.width(RepwiseSpacing.md))

            Column {
                Text(
                    text = "Workout Templates",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )
                Text(
                    text = "Choose a program to copy into your routines",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(RepwiseSpacing.md),
            verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.lg)
        ) {
            items(templates, key = { it.key }) { template ->
                TemplateCard(
                    template = template,
                    catalogMap = uiState.catalogMap,
                    onUseTemplate = {
                        viewModel.useTemplate(template.key) { newId ->
                            onTemplateCopied(newId)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun TemplateCard(
    template: WorkoutTemplateSpec,
    catalogMap: Map<String, CatalogExercise>,
    onUseTemplate: () -> Unit
) {
    RepwiseCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = template.name,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                Text(
                    text = template.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            // Level Pill
            val levelBg = when (template.level) {
                "Beginner" -> RepwiseLime
                "Intermediate" -> WarningAmber
                else -> DangerRed
            }
            val levelFg = when (template.level) {
                "Beginner" -> RepwiseOnLime
                else -> CharcoalBackground
            }

            Box(
                modifier = Modifier
                    .clip(PillShape)
                    .background(levelBg)
                    .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
            ) {
                Text(
                    text = template.level,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = levelFg
                )
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

        Text(
            text = "${template.daysCount} days per week",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = RepwiseLime
        )

        // Note: A 6-day or Advanced template shows the note "Not recommended for beginners."
        if (template.isNotRecommendedForBeginners) {
            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CharcoalSurfaceElevated)
                    .border(1.dp, CharcoalBorderSubtle, RoundedCornerShape(8.dp))
                    .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = WarningAmber,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                Text(
                    text = "Not recommended for beginners.",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = WarningAmber
                )
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

        // Days & Exercise Preview
        Text(
            text = "DAYS PREVIEW",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)) {
            template.days.forEach { daySpec ->
                val exerciseNames = daySpec.exerciseIds.map { id ->
                    catalogMap[id]?.name?.replaceFirstChar { it.uppercase() } ?: "Exercise $id"
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalSurfaceElevated)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${daySpec.name}:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = RepwiseLime,
                        modifier = Modifier.width(68.dp)
                    )
                    Text(
                        text = exerciseNames.take(3).joinToString(", ") + if (exerciseNames.size > 3) " +${exerciseNames.size - 3} more" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.lg))

        // Use this template button (copies into user's own routines)
        PrimaryButton(
            text = "Use This Template",
            onClick = onUseTemplate,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
