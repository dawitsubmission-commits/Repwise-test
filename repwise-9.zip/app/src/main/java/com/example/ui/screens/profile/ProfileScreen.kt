package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatTile
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.HeightHelper
import com.example.util.WeightHelper
import com.example.util.TestTags

@Composable
fun ProfileScreen(
    onNavigateToLicenses: () -> Unit = {},
    onRetakeAssessment: () -> Unit = {},
    modifier: Modifier = Modifier,
    viewModel: ProfileViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val stats = uiState.stats
    val entity = uiState.profileEntity
    val bmi = uiState.bmiResult

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .testTag(TestTags.SCREEN_PROFILE),
        contentPadding = PaddingValues(RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.lg)
    ) {
        // User Profile Header Card
        item {
            RepwiseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(RepwiseLimeMuted),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "User Avatar",
                            tint = RepwiseLime,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(RepwiseSpacing.md))

                    Column {
                        Text(
                            text = "REPWISE Athlete",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                        Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                        Text(
                            text = if (entity != null) "${entity.experience.lowercase().replaceFirstChar { it.uppercase() }} • ${entity.goal.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}" else "Offline Fitness",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(RepwiseSpacing.md))

                PrimaryButton(
                    text = "Retake assessment",
                    onClick = onRetakeAssessment,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Saved Assessment Summary & BMI Section
        if (entity != null) {
            item {
                SectionHeader(
                    title = "Fitness Assessment",
                    subtitle = "Baseline parameters and screening metrics"
                )

                Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                    // Assessment Summary Card
                    RepwiseCard {
                        Text(
                            text = "Assessment Summary",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                        val isImperial = entity.unitSystem.equals("IMPERIAL", ignoreCase = true)
                        ProfileDetailRow("Age", "${entity.age} years")
                        ProfileDetailRow("Height", HeightHelper.formatHeight(entity.heightCm, isImperial))
                        ProfileDetailRow("Weight", WeightHelper.format(entity.weightKg))
                        ProfileDetailRow("Goal", entity.goal.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() })
                        ProfileDetailRow("Experience", entity.experience.lowercase().replaceFirstChar { it.uppercase() })
                        ProfileDetailRow("Location", entity.location.lowercase().replaceFirstChar { it.uppercase() })
                        ProfileDetailRow("Equipment", entity.equipment)
                        val weekdaysCount = entity.trainingWeekdays.split(",").filter { it.isNotBlank() }.size
                        ProfileDetailRow("Training Days", "$weekdaysCount days per week")
                    }

                    // BMI Screening Card
                    RepwiseCard(containerColor = CharcoalSurfaceElevated) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Screening BMI",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary
                                )
                                Text(
                                    text = bmi?.formattedBmi ?: "-",
                                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                                    color = RepwiseLime
                                )
                            }

                            if (bmi?.category != null) {
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(RepwiseLimeMuted)
                                        .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
                                ) {
                                    Text(
                                        text = bmi.category,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = RepwiseLime
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                        if (bmi != null) {
                            Text(
                                text = bmi.note,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Lifetime Stats
        item {
            SectionHeader(
                title = "Lifetime Totals",
                subtitle = "Strength milestones tracked in Repwise"
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
            ) {
                StatTile(
                    label = "Total Sessions",
                    value = "${stats.totalCompletedSessions}",
                    change = if (stats.totalCompletedSessions > 0) "${stats.streakWeeks}w active streak" else "No workouts yet",
                    isPositive = stats.totalCompletedSessions > 0,
                    modifier = Modifier.weight(1f)
                )
                StatTile(
                    label = "Total Weight Moved",
                    value = WeightHelper.format(stats.totalVolumeKg),
                    change = if (stats.totalCompletedSessions > 0) "Lifetime volume" else "No workouts yet",
                    isPositive = stats.totalCompletedSessions > 0,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Preferences Section
        item {
            SectionHeader(
                title = "App Preferences",
                subtitle = "Workout timers & local configuration"
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                RepwiseCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = RepwiseLime,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(RepwiseSpacing.md))
                            Column {
                                Text(
                                    text = "Rest Timer Default",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextHighEmphasis
                                )
                                Text(
                                    text = "90 seconds between compound sets",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                }

                RepwiseCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = RepwiseLime,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(RepwiseSpacing.md))
                            Column {
                                Text(
                                    text = "Weight Unit",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextHighEmphasis
                                )
                                Text(
                                    text = uiState.units,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                }
                RepwiseCard(
                    onClick = onNavigateToLicenses
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = RepwiseLime,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(RepwiseSpacing.md))
                            Column {
                                Text(
                                    text = "Licenses & Notices",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextHighEmphasis
                                )
                                Text(
                                    text = "MIT and CC0-1.0 artwork attribution notices",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                }
            }
        }

        // App Information Note
        item {
            RepwiseCard(containerColor = CharcoalSurfaceElevated) {
                Text(
                    text = "REPWISE v2.0 • Phase 3+4 Architecture",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime
                )
                Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                Text(
                    text = "Offline strength catalog with 44 exercises, Room persistence, and AndroidSVG motion animation engine.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = RepwiseSpacing.xxs),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = TextHighEmphasis
        )
    }
}
