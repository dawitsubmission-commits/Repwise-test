package com.example.ui.screens.workoutdetail

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.RepwiseCard
import com.example.ui.components.StatTile
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.WeightHelper

@Composable
fun WorkoutDetailScreen(
    sessionId: Long,
    onBack: () -> Unit,
    onExerciseClick: (String) -> Unit = {},
    modifier: Modifier = Modifier,
    viewModel: WorkoutDetailViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    BackHandler {
        onBack()
    }

    LaunchedEffect(sessionId) {
        viewModel.loadSession(sessionId)
    }

    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .testTag("screen_workout_detail")
    ) {
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RepwiseLime)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    top = statusBarPadding + RepwiseSpacing.sm,
                    bottom = RepwiseSpacing.xxl
                ),
                verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
            ) {
                // Top App Bar
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = RepwiseSpacing.sm),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextHighEmphasis
                            )
                        }
                        Column(modifier = Modifier.padding(start = RepwiseSpacing.xs)) {
                            Text(
                                text = uiState.session?.dayName ?: "Workout Summary",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = TextHighEmphasis
                            )
                            Text(
                                text = uiState.dateText,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }

                // Summary Stats Grid
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = RepwiseSpacing.md),
                        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                        ) {
                            StatTile(
                                label = "Total Volume",
                                value = WeightHelper.format(uiState.totalVolumeKg),
                                change = "Completed volume",
                                isPositive = true,
                                modifier = Modifier.weight(1f)
                            )
                            StatTile(
                                label = "Duration",
                                value = uiState.durationText,
                                change = "Session time",
                                isPositive = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (uiState.prCount > 0) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(PillShape)
                                    .background(RepwiseLimeMuted)
                                    .border(1.dp, RepwiseLime.copy(alpha = 0.5f), PillShape)
                                    .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = RepwiseLime,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                                    Text(
                                        text = "${uiState.prCount} Personal Record${if (uiState.prCount > 1) "s" else ""} Set!",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = RepwiseLime
                                    )
                                }
                            }
                        }
                    }
                }

                // Session Note (if any)
                uiState.session?.note?.let { noteText ->
                    if (noteText.isNotBlank()) {
                        item {
                            Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                                RepwiseCard {
                                    Row(verticalAlignment = Alignment.Top) {
                                        Icon(
                                            imageVector = Icons.Default.Notes,
                                            contentDescription = null,
                                            tint = RepwiseLime,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                                        Column {
                                            Text(
                                                text = "Workout Notes",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = TextSecondary
                                            )
                                            Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                                            Text(
                                                text = noteText,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = TextHighEmphasis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Exercises List
                item {
                    Text(
                        text = "EXERCISES (${uiState.exercises.size})",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
                    )
                }

                items(uiState.exercises, key = { it.sessionExerciseId }) { exercise ->
                    Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                        RepwiseCard {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = exercise.exerciseName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = TextHighEmphasis,
                                            modifier = Modifier.clickable { onExerciseClick(exercise.exerciseId) }
                                        )
                                        if (exercise.targetMuscle.isNotBlank()) {
                                            Text(
                                                text = "${exercise.targetMuscle.replaceFirstChar { it.uppercase() }} • ${exercise.equipment}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextSecondary
                                            )
                                        }
                                    }
                                }

                                // Replaced from line
                                exercise.replacedFromExerciseName?.let { originalName ->
                                    Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(CharcoalSurfaceElevated)
                                            .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xxs)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SwapHoriz,
                                            contentDescription = null,
                                            tint = RepwiseLime,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(RepwiseSpacing.xxs))
                                        Text(
                                            text = "Replaced from $originalName",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = RepwiseLime
                                        )
                                    }
                                }

                                // Exercise note
                                exercise.note?.let { exNote ->
                                    if (exNote.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                                        Text(
                                            text = "Note: $exNote",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                                // Sets list
                                Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)) {
                                    exercise.sets.forEach { setItem ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(CharcoalSurfaceElevated)
                                                .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                // Set badge (number or "W")
                                                Box(
                                                    modifier = Modifier
                                                        .size(24.dp)
                                                        .clip(CircleShape)
                                                        .background(if (setItem.isWarmup) CharcoalSurface else RepwiseLimeMuted),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = if (setItem.isWarmup) "W" else "${setItem.setIndex + 1}",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                        color = if (setItem.isWarmup) TextSecondary else RepwiseLime
                                                    )
                                                }

                                                Spacer(modifier = Modifier.width(RepwiseSpacing.sm))

                                                // Weight x Reps
                                                val weightText = if (setItem.weightKg <= 0.0) {
                                                    "Bodyweight"
                                                } else {
                                                    WeightHelper.format(setItem.weightKg)
                                                }
                                                Text(
                                                    text = "$weightText × ${setItem.reps} reps",
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                                    color = TextHighEmphasis
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (setItem.isPr) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(PillShape)
                                                            .background(RepwiseLime)
                                                            .padding(horizontal = RepwiseSpacing.xs, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = "PR",
                                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                                            color = RepwiseOnLime
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                                                }

                                                if (setItem.isCompleted) {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Completed",
                                                        tint = RepwiseLime,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
