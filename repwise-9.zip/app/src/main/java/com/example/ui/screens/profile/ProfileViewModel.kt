package com.example.ui.screens.profile

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.UserProfileEntity
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.bmi.BmiCalculator
import com.example.domain.bmi.BmiResult
import com.example.domain.repository.RepwiseRepository
import com.example.domain.stats.ComputedWorkoutStats
import com.example.util.WeightHelper
import com.example.util.WeightUnit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUiState(
    val profileEntity: UserProfileEntity? = null,
    val bmiResult: BmiResult? = null,
    val units: String = "Kilograms (kg)",
    val restTimerDefaultSecs: Int = 90,
    val stats: ComputedWorkoutStats = ComputedWorkoutStats()
)

class ProfileViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        loadProfile()
    }

    private fun loadProfile() {
        viewModelScope.launch {
            launch {
                repository.getComputedStatsFlow().collect { computedStats ->
                    _uiState.update { it.copy(stats = computedStats) }
                }
            }

            launch {
                repository.getUserProfileFlow().collect { entity ->
                    if (entity != null) {
                        val bmi = BmiCalculator.calculateMetric(entity.heightCm, entity.weightKg, entity.age)
                        val unitLabel = if (entity.unitSystem.equals("IMPERIAL", ignoreCase = true)) {
                            WeightHelper.activeUnit = WeightUnit.LBS
                            "Pounds (lbs)"
                        } else {
                            WeightHelper.activeUnit = WeightUnit.KG
                            "Kilograms (kg)"
                        }

                        _uiState.update {
                            it.copy(
                                profileEntity = entity,
                                bmiResult = bmi,
                                units = unitLabel
                            )
                        }
                    }
                }
            }
        }
    }
}
