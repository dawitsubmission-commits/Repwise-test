package com.example.ui.screens.progress

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.charts.ChartDataBuilder
import com.example.domain.charts.ConsistencySummary
import com.example.domain.charts.MonthBucket
import com.example.domain.charts.StrengthPoint
import com.example.domain.charts.WeekBucket
import com.example.domain.history.ExerciseRecordItem
import com.example.domain.history.SessionHistoryItem
import com.example.domain.history.WorkoutHistoryHelper
import com.example.domain.repository.RepwiseRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch

enum class ProgressSubTab(val label: String) {
    HISTORY("History"),
    RECORDS("Records"),
    CHARTS("Charts")
}

data class ProgressUiState(
    val selectedTab: ProgressSubTab = ProgressSubTab.HISTORY,
    val historyByMonth: Map<String, List<SessionHistoryItem>> = emptyMap(),
    val records: List<ExerciseRecordItem> = emptyList(),
    val hasCompletedSessions: Boolean = false,
    val hasRecords: Boolean = false,
    val isLoading: Boolean = true,
    // Phase 8B Chart data
    val weeklyBuckets: List<WeekBucket> = emptyList(),
    val monthlyBuckets: List<MonthBucket> = emptyList(),
    val loggedExercises: List<Pair<String, String>> = emptyList(),
    val selectedExerciseId: String? = null,
    val strengthRange: String = "All",
    val strengthPoints: List<StrengthPoint> = emptyList(),
    val consistency: ConsistencySummary = ConsistencySummary(0, 0.0)
)

class ProgressViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _selectedTab = MutableStateFlow(ProgressSubTab.HISTORY)
    private val _selectedExerciseId = MutableStateFlow<String?>(null)
    private val _strengthRange = MutableStateFlow("All")

    private val _uiState = MutableStateFlow(ProgressUiState())
    val uiState: StateFlow<ProgressUiState> = _uiState.asStateFlow()

    init {
        loadProgressData()
    }

    private fun loadProgressData() {
        viewModelScope.launch {
            val repoDataFlow = combine(
                repository.getCompletedSessions(),
                repository.getAllPersonalRecords(),
                repository.getCatalogExercises()
            ) { completedSessions, prs, catalog ->
                Triple(completedSessions, prs, catalog)
            }

            combine(
                repoDataFlow,
                _selectedTab,
                _selectedExerciseId,
                _strengthRange
            ) { (completedSessions, prs, catalog), tab, userSelectedExerciseId, range ->
                val completedOnly = WorkoutHistoryHelper.filterCompletedSessions(completedSessions)
                val historyMap = WorkoutHistoryHelper.buildHistoryItems(completedOnly, prs)

                val catalogNameMap = catalog.associate { it.id to it.name.replaceFirstChar { c -> c.uppercase() } }
                val catalogBodyweightMap = catalog.associate {
                    it.id to it.equipment.equals("body weight", ignoreCase = true)
                }

                val recordsList = WorkoutHistoryHelper.extractBestRecordsPerExercise(
                    records = prs,
                    exerciseNames = catalogNameMap,
                    isBodyweightOverride = { id -> catalogBodyweightMap[id] ?: false }
                )

                // Phase 8B: Charts computation
                val weekly = ChartDataBuilder.weeklyBuckets(completedOnly, weeks = 8)
                val monthly = ChartDataBuilder.monthlyBuckets(completedOnly, months = 6)
                val consistencyMetrics = ChartDataBuilder.consistencySummary(weekly)

                val loggedIds = ChartDataBuilder.loggedExerciseIds(completedOnly)
                val loggedExList = loggedIds.map { id ->
                    val name = catalogNameMap[id] ?: "Exercise $id"
                    id to name
                }

                val activeExerciseId = when {
                    userSelectedExerciseId != null && loggedIds.contains(userSelectedExerciseId) -> userSelectedExerciseId
                    loggedIds.isNotEmpty() -> loggedIds.first()
                    else -> null
                }

                val rangeDays = when (range) {
                    "1M" -> 30
                    "3M" -> 90
                    "6M" -> 180
                    else -> null
                }

                val strengthSeries = if (activeExerciseId != null) {
                    ChartDataBuilder.strengthSeries(
                        sessions = completedOnly,
                        exerciseId = activeExerciseId,
                        rangeDays = rangeDays
                    )
                } else {
                    emptyList()
                }

                ProgressUiState(
                    selectedTab = tab,
                    historyByMonth = historyMap,
                    records = recordsList,
                    hasCompletedSessions = historyMap.isNotEmpty(),
                    hasRecords = recordsList.isNotEmpty(),
                    isLoading = false,
                    weeklyBuckets = weekly,
                    monthlyBuckets = monthly,
                    loggedExercises = loggedExList,
                    selectedExerciseId = activeExerciseId,
                    strengthRange = range,
                    strengthPoints = strengthSeries,
                    consistency = consistencyMetrics
                )
            }
                .flowOn(Dispatchers.Default)
                .collect { updatedState ->
                    _uiState.value = updatedState
                }
        }
    }

    fun selectTab(tab: ProgressSubTab) {
        _selectedTab.value = tab
    }

    fun selectExercise(id: String) {
        _selectedExerciseId.value = id
    }

    fun selectRange(range: String) {
        _strengthRange.value = range
    }
}
