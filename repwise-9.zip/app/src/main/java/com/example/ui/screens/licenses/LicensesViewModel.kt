package com.example.ui.screens.licenses

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

data class LicensesUiState(
    val licenseText: String = "",
    val noticeText: String = "",
    val selectedTab: Int = 0, // 0 for LICENSE, 1 for NOTICE.md
    val isLoading: Boolean = true
)

class LicensesViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(LicensesUiState())
    val uiState: StateFlow<LicensesUiState> = _uiState.asStateFlow()

    init {
        loadLicenseFiles()
    }

    private fun loadLicenseFiles() {
        viewModelScope.launch {
            val app = getApplication<Application>()
            val license = withContext(Dispatchers.IO) {
                try {
                    app.assets.open("licenses/LICENSE").use { stream ->
                        BufferedReader(InputStreamReader(stream)).readText()
                    }
                } catch (e: Exception) {
                    "Error loading LICENSE: ${e.message}"
                }
            }

            val notice = withContext(Dispatchers.IO) {
                try {
                    app.assets.open("licenses/NOTICE.md").use { stream ->
                        BufferedReader(InputStreamReader(stream)).readText()
                    }
                } catch (e: Exception) {
                    "Error loading NOTICE.md: ${e.message}"
                }
            }

            _uiState.value = LicensesUiState(
                licenseText = license,
                noticeText = notice,
                selectedTab = 0,
                isLoading = false
            )
        }
    }

    fun selectTab(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(selectedTab = tabIndex)
    }
}
