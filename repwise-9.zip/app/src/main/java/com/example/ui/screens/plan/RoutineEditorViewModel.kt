package com.example.ui.screens.plan

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.PlanDayEntity
import com.example.data.local.entities.PlanDayWithExercises
import com.example.data.local.entities.PlanExerciseEntity
import com.example.data.local.entities.WorkoutPlanEntity
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.models.CatalogExercise
import com.example.domain.repository.RepwiseRepository
import com.example.domain.repository.StartWorkoutResult
import com.example.domain.templates.TemplateRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class EditableExercise(
    val id: Long = 0,
    val exerciseId: String,
    val sets: Int = 3,
    val repMin: Int = 8,
    val repMax: Int = 12,
    val restSeconds: Int = 90,
    val note: String? = null
)

data class EditableDay(
    val id: Long = 0,
    val name: String,
    val weekday: Int? = null, // 1 = Mon, ..., 7 = Sun, null = Rest / Unassigned
    val exercises: List<EditableExercise> = emptyList()
)

data class RoutineEditorUiState(
    val planId: Long = 0,
    val planName: String = "",
    val isActive: Boolean = false,
    val days: List<EditableDay> = emptyList(),
    val selectedDayIndex: Int = 0,
    val catalogMap: Map<String, CatalogExercise> = emptyMap(),
    val allCatalogExercises: List<CatalogExercise> = emptyList(),
    val isLoading: Boolean = true
)

class RoutineEditorViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _uiState = MutableStateFlow(RoutineEditorUiState())
    val uiState: StateFlow<RoutineEditorUiState> = _uiState.asStateFlow()

    fun loadPlan(planId: Long) {
        viewModelScope.launch {
            repository.ensureCatalogInitialized()
            val catalogList = repository.getCatalogExercises().first()
            val catalogMap = catalogList.associateBy { it.id }

            val planWithDays = repository.getWorkoutPlanById(planId).first()
            if (planWithDays != null) {
                val editableDays = planWithDays.days.map { dayWithEx ->
                    EditableDay(
                        id = dayWithEx.day.id,
                        name = dayWithEx.day.name,
                        weekday = dayWithEx.day.weekday,
                        exercises = dayWithEx.exercises.sortedBy { it.position }.map { ex ->
                            EditableExercise(
                                id = ex.id,
                                exerciseId = ex.exerciseId,
                                sets = ex.sets,
                                repMin = ex.repMin,
                                repMax = ex.repMax,
                                restSeconds = ex.restSeconds,
                                note = ex.note
                            )
                        }
                    )
                }

                _uiState.value = RoutineEditorUiState(
                    planId = planId,
                    planName = planWithDays.plan.name,
                    isActive = planWithDays.plan.isActive,
                    days = editableDays,
                    selectedDayIndex = 0,
                    catalogMap = catalogMap,
                    allCatalogExercises = catalogList,
                    isLoading = false
                )
            }
        }
    }

    fun onPlanNameChange(newName: String) {
        _uiState.value = _uiState.value.copy(planName = newName)
    }

    fun selectDay(index: Int) {
        _uiState.value = _uiState.value.copy(selectedDayIndex = index.coerceIn(0, (_uiState.value.days.size - 1).coerceAtLeast(0)))
    }

    fun addDay() {
        val currentDays = _uiState.value.days.toMutableList()
        val newDayNumber = currentDays.size + 1
        currentDays.add(
            EditableDay(
                id = 0,
                name = "Day $newDayNumber",
                weekday = null,
                exercises = emptyList()
            )
        )
        _uiState.value = _uiState.value.copy(
            days = currentDays,
            selectedDayIndex = currentDays.size - 1
        )
    }

    fun removeDay(dayIndex: Int) {
        val currentDays = _uiState.value.days.toMutableList()
        if (currentDays.size > 1 && dayIndex in currentDays.indices) {
            currentDays.removeAt(dayIndex)
            val newIdx = (dayIndex - 1).coerceAtLeast(0)
            _uiState.value = _uiState.value.copy(
                days = currentDays,
                selectedDayIndex = newIdx
            )
        }
    }

    fun renameDay(dayIndex: Int, newName: String) {
        val currentDays = _uiState.value.days.toMutableList()
        if (dayIndex in currentDays.indices) {
            currentDays[dayIndex] = currentDays[dayIndex].copy(name = newName)
            _uiState.value = _uiState.value.copy(days = currentDays)
        }
    }

    fun assignWeekday(dayIndex: Int, weekday: Int?) {
        val currentDays = _uiState.value.days.toMutableList()
        if (dayIndex in currentDays.indices) {
            currentDays[dayIndex] = currentDays[dayIndex].copy(weekday = weekday)
            _uiState.value = _uiState.value.copy(days = currentDays)
        }
    }

    fun moveExerciseUp(dayIndex: Int, exIndex: Int) {
        if (exIndex <= 0) return
        val currentDays = _uiState.value.days.toMutableList()
        val targetDay = currentDays[dayIndex]
        val exList = targetDay.exercises.toMutableList()
        if (exIndex in exList.indices) {
            val item = exList.removeAt(exIndex)
            exList.add(exIndex - 1, item)
            currentDays[dayIndex] = targetDay.copy(exercises = exList)
            _uiState.value = _uiState.value.copy(days = currentDays)
        }
    }

    fun moveExerciseDown(dayIndex: Int, exIndex: Int) {
        val currentDays = _uiState.value.days.toMutableList()
        val targetDay = currentDays[dayIndex]
        val exList = targetDay.exercises.toMutableList()
        if (exIndex < exList.size - 1 && exIndex in exList.indices) {
            val item = exList.removeAt(exIndex)
            exList.add(exIndex + 1, item)
            currentDays[dayIndex] = targetDay.copy(exercises = exList)
            _uiState.value = _uiState.value.copy(days = currentDays)
        }
    }

    fun updateExerciseParams(
        dayIndex: Int,
        exIndex: Int,
        sets: Int,
        repMin: Int,
        repMax: Int,
        restSeconds: Int,
        note: String?
    ) {
        val currentDays = _uiState.value.days.toMutableList()
        val targetDay = currentDays[dayIndex]
        val exList = targetDay.exercises.toMutableList()
        if (exIndex in exList.indices) {
            exList[exIndex] = exList[exIndex].copy(
                sets = sets,
                repMin = repMin,
                repMax = repMax,
                restSeconds = restSeconds,
                note = note
            )
            currentDays[dayIndex] = targetDay.copy(exercises = exList)
            _uiState.value = _uiState.value.copy(days = currentDays)
        }
    }

    fun removeExercise(dayIndex: Int, exIndex: Int) {
        val currentDays = _uiState.value.days.toMutableList()
        val targetDay = currentDays[dayIndex]
        val exList = targetDay.exercises.toMutableList()
        if (exIndex in exList.indices) {
            exList.removeAt(exIndex)
            currentDays[dayIndex] = targetDay.copy(exercises = exList)
            _uiState.value = _uiState.value.copy(days = currentDays)
        }
    }

    fun addExerciseToDay(dayIndex: Int, exerciseId: String) {
        val currentDays = _uiState.value.days.toMutableList()
        val targetDay = currentDays[dayIndex]
        val exList = targetDay.exercises.toMutableList()
        val catalogEx = _uiState.value.catalogMap[exerciseId]
        val (sets, reps, rest) = TemplateRepository.classifyDefaults(catalogEx)

        exList.add(
            EditableExercise(
                id = 0,
                exerciseId = exerciseId,
                sets = sets,
                repMin = reps.first,
                repMax = reps.second,
                restSeconds = rest,
                note = null
            )
        )
        currentDays[dayIndex] = targetDay.copy(exercises = exList)
        _uiState.value = _uiState.value.copy(days = currentDays)
    }

    fun replaceExercise(dayIndex: Int, exIndex: Int, newExerciseId: String) {
        val currentDays = _uiState.value.days.toMutableList()
        val targetDay = currentDays[dayIndex]
        val exList = targetDay.exercises.toMutableList()
        if (exIndex in exList.indices) {
            // Keep sets/reps/rest on replace as mandated by prompt
            exList[exIndex] = exList[exIndex].copy(exerciseId = newExerciseId)
            currentDays[dayIndex] = targetDay.copy(exercises = exList)
            _uiState.value = _uiState.value.copy(days = currentDays)
        }
    }

    fun saveRoutine(onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            val state = _uiState.value
            val planEntity = WorkoutPlanEntity(
                id = state.planId,
                name = state.planName.ifBlank { "Routine" },
                isActive = state.isActive,
                createdAt = System.currentTimeMillis()
            )

            val daysWithExercises = state.days.mapIndexed { dIdx, d ->
                val dayEntity = PlanDayEntity(
                    id = d.id,
                    planId = state.planId,
                    name = d.name.ifBlank { "Day ${dIdx + 1}" },
                    weekday = d.weekday,
                    position = dIdx
                )
                val exEntities = d.exercises.mapIndexed { eIdx, e ->
                    PlanExerciseEntity(
                        id = e.id,
                        planDayId = d.id,
                        exerciseId = e.exerciseId,
                        position = eIdx,
                        sets = e.sets,
                        repMin = e.repMin,
                        repMax = e.repMax,
                        restSeconds = e.restSeconds,
                        note = e.note
                    )
                }
                PlanDayWithExercises(day = dayEntity, exercises = exEntities)
            }

            repository.updateWorkoutPlan(
                WorkoutPlanWithDays(plan = planEntity, days = daysWithExercises)
            )
            onSaved()
        }
    }

    fun deleteRoutine(onDeleted: () -> Unit) {
        viewModelScope.launch {
            repository.deleteWorkoutPlan(_uiState.value.planId)
            onDeleted()
        }
    }

    fun startDayWorkout(
        dayIndex: Int,
        onStarted: (Long) -> Unit,
        onConflict: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val state = _uiState.value
            val targetDay = state.days.getOrNull(dayIndex) ?: return@launch
            val inProgress = repository.getActiveInProgressSessionOnce()
            if (inProgress != null) {
                onConflict(inProgress.session.id)
                return@launch
            }
            // Save any pending changes
            saveRoutine()
            when (val result = repository.startWorkoutFromPlanDay(targetDay.id)) {
                is StartWorkoutResult.Started -> onStarted(result.sessionId)
                is StartWorkoutResult.ExistingInProgress -> onConflict(result.sessionId)
            }
        }
    }

    fun discardInProgressAndStartDay(
        inProgressSessionId: Long,
        dayIndex: Int,
        onStarted: (Long) -> Unit
    ) {
        viewModelScope.launch {
            repository.discardSession(inProgressSessionId)
            val state = _uiState.value
            val targetDay = state.days.getOrNull(dayIndex) ?: return@launch
            saveRoutine()
            when (val result = repository.startWorkoutFromPlanDay(targetDay.id)) {
                is StartWorkoutResult.Started -> onStarted(result.sessionId)
                is StartWorkoutResult.ExistingInProgress -> onStarted(result.sessionId)
            }
        }
    }
}
