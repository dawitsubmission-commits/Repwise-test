package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.DangerRed
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary

@Composable
fun WorkoutInProgressConflictDialog(
    onDismissRequest: () -> Unit,
    onResume: () -> Unit,
    onDiscardConfirmed: () -> Unit,
    sessionName: String? = null
) {
    var showDiscardConfirm by remember { mutableStateOf(false) }

    if (!showDiscardConfirm) {
        AlertDialog(
            onDismissRequest = onDismissRequest,
            title = {
                Text(
                    text = "You have a workout in progress",
                    style = androidx.compose.material3.MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                val detail = if (!sessionName.isNullOrBlank()) " ($sessionName)" else ""
                Text(
                    text = "A workout is already in progress$detail. Would you like to resume it or discard it?",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onResume,
                    modifier = Modifier.testTag("dialog_resume_in_progress_button")
                ) {
                    Text("Resume", color = RepwiseLime, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)) {
                    TextButton(onClick = onDismissRequest) {
                        Text("Cancel", color = TextSecondary)
                    }
                    TextButton(
                        onClick = { showDiscardConfirm = true },
                        modifier = Modifier.testTag("dialog_discard_in_progress_button")
                    ) {
                        Text("Discard", color = DangerRed, fontWeight = FontWeight.Bold)
                    }
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis,
            textContentColor = TextSecondary
        )
    } else {
        AlertDialog(
            onDismissRequest = { showDiscardConfirm = false },
            title = {
                Text(
                    text = "Discard workout in progress?",
                    style = androidx.compose.material3.MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to discard your workout in progress? All unfinished sets and tracked duration will be lost.",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onDiscardConfirmed,
                    modifier = Modifier.testTag("dialog_confirm_discard_button")
                ) {
                    Text("Discard", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDiscardConfirm = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis,
            textContentColor = TextSecondary
        )
    }
}
