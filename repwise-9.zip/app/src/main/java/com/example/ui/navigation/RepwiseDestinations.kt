package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.util.TestTags

sealed class RepwiseDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
    val testTag: String
) {
    data object Home : RepwiseDestination(
        route = "home",
        label = "Home",
        icon = Icons.Outlined.Home,
        selectedIcon = Icons.Filled.Home,
        testTag = TestTags.NAV_HOME
    )

    data object Plan : RepwiseDestination(
        route = "plan",
        label = "Plan",
        icon = Icons.Outlined.CalendarMonth,
        selectedIcon = Icons.Filled.CalendarMonth,
        testTag = TestTags.NAV_PLAN
    )

    data object Library : RepwiseDestination(
        route = "library",
        label = "Library",
        icon = Icons.Outlined.FitnessCenter,
        selectedIcon = Icons.Filled.FitnessCenter,
        testTag = TestTags.NAV_LIBRARY
    )

    data object Progress : RepwiseDestination(
        route = "progress",
        label = "Progress",
        icon = Icons.Outlined.TrendingUp,
        selectedIcon = Icons.Filled.TrendingUp,
        testTag = TestTags.NAV_PROGRESS
    )

    data object Profile : RepwiseDestination(
        route = "profile",
        label = "Profile",
        icon = Icons.Outlined.Person,
        selectedIcon = Icons.Filled.Person,
        testTag = TestTags.NAV_PROFILE
    )

    data object Train : RepwiseDestination(
        route = "train",
        label = "Train",
        icon = Icons.Outlined.FitnessCenter,
        selectedIcon = Icons.Filled.FitnessCenter,
        testTag = TestTags.SCREEN_TRAIN
    )

    data object ActiveWorkout : RepwiseDestination(
        route = "active_workout/{sessionId}",
        label = "Active Workout",
        icon = Icons.Outlined.FitnessCenter,
        selectedIcon = Icons.Filled.FitnessCenter,
        testTag = "screen_active_workout"
    ) {
        fun createRoute(sessionId: Long): String = "active_workout/$sessionId"
    }

    data object ExerciseDetail : RepwiseDestination(
        route = "exercise_detail/{exerciseId}",
        label = "Exercise Detail",
        icon = Icons.Outlined.FitnessCenter,
        selectedIcon = Icons.Filled.FitnessCenter,
        testTag = "screen_exercise_detail"
    ) {
        fun createRoute(exerciseId: String): String = "exercise_detail/$exerciseId"
    }

    data object Licenses : RepwiseDestination(
        route = "licenses",
        label = "Licenses",
        icon = Icons.Outlined.Description,
        selectedIcon = Icons.Filled.Description,
        testTag = "screen_licenses"
    )

    data object RoutineEditor : RepwiseDestination(
        route = "routine_editor/{planId}",
        label = "Routine Editor",
        icon = Icons.Outlined.CalendarMonth,
        selectedIcon = Icons.Filled.CalendarMonth,
        testTag = "screen_routine_editor"
    ) {
        fun createRoute(planId: Long): String = "routine_editor/$planId"
    }

    data object TemplatePicker : RepwiseDestination(
        route = "template_picker",
        label = "Workout Templates",
        icon = Icons.Outlined.CalendarMonth,
        selectedIcon = Icons.Filled.CalendarMonth,
        testTag = "screen_template_picker"
    )

    data object Onboarding : RepwiseDestination(
        route = "onboarding",
        label = "Assessment",
        icon = Icons.Outlined.Person,
        selectedIcon = Icons.Filled.Person,
        testTag = "screen_onboarding"
    )

    data object WorkoutDetail : RepwiseDestination(
        route = "workout_detail/{sessionId}",
        label = "Workout Details",
        icon = Icons.Outlined.FitnessCenter,
        selectedIcon = Icons.Filled.FitnessCenter,
        testTag = "screen_workout_detail"
    ) {
        fun createRoute(sessionId: Long): String = "workout_detail/$sessionId"
    }

    companion object {
        val bottomNavDestinations = listOf(Home, Plan, Library, Progress, Profile)
    }
}
