package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextTertiary
import com.example.util.TestTags

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = PillShape,
        border = BorderStroke(1.dp, CharcoalBorder),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = CharcoalSurfaceElevated,
            contentColor = TextHighEmphasis,
            disabledContainerColor = CharcoalSurfaceElevated.copy(alpha = 0.5f),
            disabledContentColor = TextTertiary
        ),
        modifier = modifier
            .heightIn(min = 48.dp)
            .testTag(TestTags.SECONDARY_BUTTON)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (leadingIcon != null) {
                leadingIcon()
                Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.SemiBold
                )
            )
            if (trailingIcon != null) {
                Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                trailingIcon()
            }
        }
    }
}
