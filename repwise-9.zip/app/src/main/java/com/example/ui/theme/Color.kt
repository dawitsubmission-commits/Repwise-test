package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Lime Accent (Restrained, used for primary highlights and active cues)
val RepwiseLime = Color(0xFFB8F04A)
val RepwiseLimeMuted = Color(0x33B8F04A) // 20% alpha
val RepwiseLimeSubtle = Color(0x1AB8F04A) // 10% alpha
val RepwiseOnLime = Color(0xFF101900)

// Charcoal Dark Surfaces
val CharcoalBackground = Color(0xFF121212)
val CharcoalSurface = Color(0xFF1C1C1E)
val CharcoalSurfaceElevated = Color(0xFF242426)
val CharcoalSurfaceVariant = Color(0xFF2C2C2E)
val CharcoalBorder = Color(0xFF38383C)
val CharcoalBorderSubtle = Color(0xFF28282C)

// Typography & Contrast
val TextHighEmphasis = Color(0xFFFFFFFF)
val TextMediumEmphasis = Color(0xFFEBEBF5)
val TextSecondary = Color(0xFFA1A1A6)
val TextTertiary = Color(0xFF6E6E73)

// Semantic Accents
val SuccessGreen = Color(0xFF30D158)
val DangerRed = Color(0xFFFF453A)
val WarningAmber = Color(0xFFFFD60A)
