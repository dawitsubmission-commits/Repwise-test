package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.TestTags

@Composable
fun StatTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    change: String? = null,
    isPositive: Boolean = true,
    icon: @Composable (() -> Unit)? = null
) {
    RepwiseCard(
        modifier = modifier.testTag(TestTags.STAT_TILE),
        containerColor = CharcoalSurfaceElevated,
        contentPadding = RepwiseSpacing.md
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )

            if (icon != null) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(RepwiseLimeMuted),
                    contentAlignment = Alignment.Center
                ) {
                    icon()
                }
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

        Text(
            text = value,
            style = MaterialTheme.typography.headlineLarge.copy(
                fontWeight = FontWeight.Bold
            ),
            color = TextHighEmphasis
        )

        if (change != null) {
            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
            val changeColor = if (isPositive) SuccessGreen else DangerRed
            Text(
                text = change,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Medium
                ),
                color = changeColor
            )
        }
    }
}
