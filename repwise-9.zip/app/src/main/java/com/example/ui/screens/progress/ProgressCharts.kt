package com.example.ui.screens.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.domain.charts.MonthBucket
import com.example.domain.charts.StrengthPoint
import com.example.domain.charts.WeekBucket
import com.example.ui.components.EmptyState
import com.example.ui.components.FilterChipRow
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatTile
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.util.WeightHelper
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

interface ChartsTabCallbacks {
    fun onSelectExercise(exerciseId: String)
    fun onSelectRange(range: String)
}

@Composable
fun BarChart(
    values: List<Float>,
    labels: List<String>,
    modifier: Modifier = Modifier,
    highlightLast: Boolean = true,
    contentDescription: String = "",
    valueFormatter: (Float) -> String = { it.toInt().toString() }
) {
    var selectedIndex by remember(values) { mutableStateOf<Int?>(null) }
    val maxVal = remember(values) { maxOf(1f, values.maxOrNull() ?: 1f) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics { this.contentDescription = contentDescription }
    ) {
        // Value label above the chart when a bar is selected
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp),
            contentAlignment = Alignment.Center
        ) {
            val sel = selectedIndex
            if (sel != null && sel in values.indices) {
                Text(
                    text = "${labels.getOrElse(sel) { "" }}: ${valueFormatter(values[sel])}",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime
                )
            } else {
                Text(
                    text = "Tap a bar to inspect",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary
                )
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        // Canvas bars
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .pointerInput(values) {
                    detectTapGestures { offset ->
                        if (values.isNotEmpty()) {
                            val slotWidth = size.width.toFloat() / values.size.toFloat()
                            val idx = (offset.x / slotWidth).toInt().coerceIn(0, values.size - 1)
                            selectedIndex = idx
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val count = values.size
                if (count == 0) return@Canvas

                val canvasWidth = size.width
                val canvasHeight = size.height

                // Faint horizontal gridlines (3 lines: 100%, 50%, 0%)
                val gridLines = listOf(0.0f, 0.5f, 1.0f)
                gridLines.forEach { ratio ->
                    val y = canvasHeight * (1f - ratio)
                    drawLine(
                        color = CharcoalBorderSubtle,
                        start = Offset(0f, y),
                        end = Offset(canvasWidth, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                val slotWidth = canvasWidth / count
                val barWidth = slotWidth * 0.55f

                values.forEachIndexed { i, value ->
                    val barHeight = (value / maxVal) * (canvasHeight - 8.dp.toPx())
                    val left = (i * slotWidth) + ((slotWidth - barWidth) / 2f)
                    val top = canvasHeight - barHeight

                    val isLast = highlightLast && (i == count - 1)
                    val isSelected = selectedIndex == i

                    val barColor = when {
                        isSelected -> RepwiseLime
                        isLast -> RepwiseLime
                        else -> RepwiseLime.copy(alpha = 0.60f)
                    }

                    if (barHeight > 0f) {
                        drawRoundRect(
                            color = barColor,
                            topLeft = Offset(left, top),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }

                    // Bottom baseline line
                    drawLine(
                        color = CharcoalBorderSubtle,
                        start = Offset(0f, canvasHeight),
                        end = Offset(canvasWidth, canvasHeight),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        // X labels under the bars
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            labels.forEachIndexed { idx, label ->
                val isSelected = selectedIndex == idx
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    ),
                    color = if (isSelected) RepwiseLime else TextTertiary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun LineChart(
    points: List<Float>,
    xLabels: List<String>,
    modifier: Modifier = Modifier,
    contentDescription: String = "",
    valueFormatter: (Float) -> String = { it.toInt().toString() }
) {
    var selectedIndex by remember(points) {
        mutableStateOf<Int?>(if (points.isNotEmpty()) points.size - 1 else null)
    }

    val minVal = remember(points) { points.minOrNull() ?: 0f }
    val maxVal = remember(points) { maxOf(minVal + 1f, points.maxOrNull() ?: 1f) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics { this.contentDescription = contentDescription }
    ) {
        // Tooltip showing selected point value & date
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp),
            contentAlignment = Alignment.Center
        ) {
            val sel = selectedIndex
            if (sel != null && sel in points.indices) {
                val dateLabel = xLabels.getOrElse(sel) { "" }
                Text(
                    text = if (dateLabel.isNotBlank()) "$dateLabel • ${valueFormatter(points[sel])}" else valueFormatter(points[sel]),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime
                )
            } else {
                Text(
                    text = "Tap a data point to inspect",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary
                )
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        // Canvas Line and Dots with Y axis labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        ) {
            // Y-axis labels (max, min)
            Column(
                modifier = Modifier
                    .width(42.dp)
                    .height(150.dp)
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = valueFormatter(maxVal),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    maxLines = 1
                )
                Text(
                    text = valueFormatter((minVal + maxVal) / 2f),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    maxLines = 1
                )
                Text(
                    text = valueFormatter(minVal),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary,
                    maxLines = 1
                )
            }

            Spacer(modifier = Modifier.width(RepwiseSpacing.xs))

            // Chart area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(150.dp)
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            if (points.isNotEmpty()) {
                                val count = points.size
                                val stepX = if (count > 1) size.width.toFloat() / (count - 1).toFloat() else size.width.toFloat()
                                val idx = if (count > 1) {
                                    ((offset.x + (stepX / 2f)) / stepX).toInt().coerceIn(0, count - 1)
                                } else 0
                                selectedIndex = idx
                            }
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val count = points.size
                    val canvasWidth = size.width
                    val canvasHeight = size.height
                    val verticalPadding = 12.dp.toPx()
                    val plotHeight = canvasHeight - (2 * verticalPadding)

                    // Faint horizontal gridlines (3 lines)
                    val gridLines = listOf(0.0f, 0.5f, 1.0f)
                    gridLines.forEach { ratio ->
                        val y = verticalPadding + (plotHeight * (1f - ratio))
                        drawLine(
                            color = CharcoalBorderSubtle,
                            start = Offset(0f, y),
                            end = Offset(canvasWidth, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    if (count == 0) return@Canvas

                    if (count == 1) {
                        // Single point is drawn as one dot in the center with its value
                        val center = Offset(canvasWidth / 2f, canvasHeight / 2f)
                        drawCircle(
                            color = RepwiseLime,
                            radius = 6.dp.toPx(),
                            center = center
                        )
                        drawCircle(
                            color = CharcoalSurface,
                            radius = 3.dp.toPx(),
                            center = center
                        )
                        return@Canvas
                    }

                    // Compute pixel coordinates
                    val coords = points.mapIndexed { idx, value ->
                        val x = (idx.toFloat() / (count - 1).toFloat()) * canvasWidth
                        val normalizedY = if (maxVal > minVal) (value - minVal) / (maxVal - minVal) else 0.5f
                        val y = verticalPadding + (plotHeight * (1f - normalizedY))
                        Offset(x, y)
                    }

                    // Draw area gradient fill under line
                    val fillPath = Path().apply {
                        moveTo(coords.first().x, canvasHeight)
                        coords.forEach { lineTo(it.x, it.y) }
                        lineTo(coords.last().x, canvasHeight)
                        close()
                    }
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(RepwiseLime.copy(alpha = 0.20f), Color.Transparent),
                            startY = verticalPadding,
                            endY = canvasHeight
                        )
                    )

                    // Draw connecting line
                    val strokePath = Path().apply {
                        moveTo(coords.first().x, coords.first().y)
                        for (i in 1 until coords.size) {
                            lineTo(coords[i].x, coords[i].y)
                        }
                    }
                    drawPath(
                        path = strokePath,
                        color = RepwiseLime,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw dots
                    coords.forEachIndexed { i, pt ->
                        val isSel = selectedIndex == i
                        val radius = if (isSel) 5.5.dp.toPx() else 3.5.dp.toPx()

                        drawCircle(
                            color = RepwiseLime,
                            radius = radius,
                            center = pt
                        )
                        if (isSel) {
                            drawCircle(
                                color = CharcoalSurface,
                                radius = 2.5.dp.toPx(),
                                center = pt
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        // First and last date labels on the x-axis
        if (xLabels.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 48.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = xLabels.first(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary
                )
                if (xLabels.size > 1) {
                    Text(
                        text = xLabels.last(),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary
                    )
                }
            }
        }
    }
}

/**
 * Extension for LazyColumn displaying the Charts sub-tab content.
 */
fun LazyListScope.chartsTabContent(
    state: ProgressUiState,
    callbacks: ChartsTabCallbacks
) {
    if (!state.hasCompletedSessions) {
        item {
            EmptyState(
                title = "No charts yet",
                description = "Finish a workout to see your progress here.",
                icon = {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(PillShape)
                            .background(CharcoalSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "📊", style = MaterialTheme.typography.titleMedium)
                    }
                }
            )
        }
        return
    }

    // a. Workouts per week (or month)
    item {
        Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
            WorkoutsFrequencySection(state = state)
        }
    }

    // b. Training volume
    item {
        Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
            TrainingVolumeSection(state = state)
        }
    }

    // c. Consistency
    item {
        Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
            ConsistencySection(state = state)
        }
    }

    // d. Strength progress
    item {
        Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
            StrengthProgressSection(state = state, callbacks = callbacks)
        }
    }
}

@Composable
private fun WorkoutsFrequencySection(state: ProgressUiState) {
    var periodToggle by remember { mutableStateOf("Weekly") }

    RepwiseCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Workouts per week",
                    subtitle = if (periodToggle == "Weekly") "Last 8 weeks" else "Last 6 months"
                )

                PeriodToggleButton(
                    selected = periodToggle,
                    options = listOf("Weekly", "Monthly"),
                    onSelect = { periodToggle = it }
                )
            }

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            val (values, labels, total) = if (periodToggle == "Weekly") {
                val vals = state.weeklyBuckets.map { it.sessionCount.toFloat() }
                val labs = state.weeklyBuckets.map { formatWeekShortLabel(it.weekStartMillis) }
                Triple(vals, labs, state.weeklyBuckets.sumOf { it.sessionCount })
            } else {
                val vals = state.monthlyBuckets.map { it.sessionCount.toFloat() }
                val labs = state.monthlyBuckets.map { formatMonthShortLabel(it.monthStartMillis) }
                Triple(vals, labs, state.monthlyBuckets.sumOf { it.sessionCount })
            }

            BarChart(
                values = values,
                labels = labels,
                highlightLast = true,
                contentDescription = "Workouts frequency chart, total $total workouts logged in this period",
                valueFormatter = { "${it.toInt()} sessions" }
            )
        }
    }
}

@Composable
private fun TrainingVolumeSection(state: ProgressUiState) {
    var periodToggle by remember { mutableStateOf("Weekly") }

    RepwiseCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = "Training volume",
                    subtitle = if (periodToggle == "Weekly") "Last 8 weeks workload" else "Last 6 months workload"
                )

                PeriodToggleButton(
                    selected = periodToggle,
                    options = listOf("Weekly", "Monthly"),
                    onSelect = { periodToggle = it }
                )
            }

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            val (values, labels, totalKg) = if (periodToggle == "Weekly") {
                val vals = state.weeklyBuckets.map { WeightHelper.fromKg(it.volumeKg).toFloat() }
                val labs = state.weeklyBuckets.map { formatWeekShortLabel(it.weekStartMillis) }
                Triple(vals, labs, state.weeklyBuckets.sumOf { it.volumeKg })
            } else {
                val vals = state.monthlyBuckets.map { WeightHelper.fromKg(it.volumeKg).toFloat() }
                val labs = state.monthlyBuckets.map { formatMonthShortLabel(it.monthStartMillis) }
                Triple(vals, labs, state.monthlyBuckets.sumOf { it.volumeKg })
            }

            BarChart(
                values = values,
                labels = labels,
                highlightLast = true,
                contentDescription = "Training volume chart, total volume ${WeightHelper.format(totalKg)}",
                valueFormatter = { WeightHelper.format(WeightHelper.toKg(it.toDouble())) }
            )
        }
    }
}

@Composable
private fun ConsistencySection(state: ProgressUiState) {
    RepwiseCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            SectionHeader(
                title = "Consistency",
                subtitle = "Workout frequency and habits"
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
            ) {
                StatTile(
                    label = "weeks trained (last 8)",
                    value = "${state.consistency.weeksWithAtLeastOneWorkout} / 8",
                    change = "Active weeks",
                    isPositive = state.consistency.weeksWithAtLeastOneWorkout >= 4,
                    modifier = Modifier.weight(1f)
                )

                StatTile(
                    label = "avg sessions per week",
                    value = String.format(Locale.US, "%.1f", state.consistency.avgSessionsPerWeek),
                    change = "Weekly frequency",
                    isPositive = state.consistency.avgSessionsPerWeek >= 2.0,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun StrengthProgressSection(
    state: ProgressUiState,
    callbacks: ChartsTabCallbacks
) {
    val isBodyweight = remember(state.strengthPoints) {
        state.strengthPoints.isNotEmpty() && state.strengthPoints.all { it.bestE1rmKg == null }
    }

    val chartTitle = if (isBodyweight) "Best reps" else "Strength progress"
    val chartSubtitle = if (isBodyweight) "Highest reps logged per session" else "Estimated 1RM trend"

    RepwiseCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            SectionHeader(
                title = chartTitle,
                subtitle = chartSubtitle
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            // Exercise picker (Horizontal chip row)
            if (state.loggedExercises.isNotEmpty()) {
                val scrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState),
                    horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)
                ) {
                    state.loggedExercises.forEach { (exId, exName) ->
                        val isSelected = exId == state.selectedExerciseId
                        FilterChip(
                            selected = isSelected,
                            onClick = { callbacks.onSelectExercise(exId) },
                            shape = PillShape,
                            label = {
                                Text(
                                    text = exName,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalSurfaceElevated,
                                labelColor = TextSecondary,
                                selectedContainerColor = RepwiseLime,
                                selectedLabelColor = RepwiseOnLime
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = CharcoalBorderSubtle,
                                selectedBorderColor = RepwiseLime,
                                borderWidth = 1.dp,
                                selectedBorderWidth = 1.dp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                // Range toggle: 1M | 3M | 6M | All
                val rangeOptions = listOf("1M", "3M", "6M", "All")
                val rangeIdx = rangeOptions.indexOf(state.strengthRange).coerceAtLeast(0)
                FilterChipRow(
                    items = rangeOptions,
                    selectedIndex = rangeIdx,
                    onSelected = { callbacks.onSelectRange(rangeOptions[it]) }
                )

                Spacer(modifier = Modifier.height(RepwiseSpacing.md))

                if (state.strengthPoints.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = RepwiseSpacing.lg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No working sets recorded for this exercise in this timeframe.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    val points = if (isBodyweight) {
                        state.strengthPoints.map { it.bestReps.toFloat() }
                    } else {
                        state.strengthPoints.map {
                            val kg = it.bestE1rmKg ?: it.bestWeightKg
                            WeightHelper.fromKg(kg).toFloat()
                        }
                    }

                    val xLabels = state.strengthPoints.map { formatDayLabel(it.dateMillis) }

                    val desc = if (isBodyweight) {
                        "Best reps progression chart with ${points.size} entries"
                    } else {
                        "Estimated 1RM progression chart with ${points.size} entries"
                    }

                    LineChart(
                        points = points,
                        xLabels = xLabels,
                        contentDescription = desc,
                        valueFormatter = {
                            if (isBodyweight) {
                                "${it.toInt()} reps"
                            } else {
                                WeightHelper.format(WeightHelper.toKg(it.toDouble()))
                            }
                        }
                    )
                }
            } else {
                Text(
                    text = "No exercises logged yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun PeriodToggleButton(
    selected: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(PillShape)
            .background(CharcoalSurfaceElevated)
            .border(1.dp, CharcoalBorderSubtle, PillShape)
            .padding(2.dp)
    ) {
        options.forEach { opt ->
            val isSel = opt == selected
            Box(
                modifier = Modifier
                    .clip(PillShape)
                    .background(if (isSel) RepwiseLime else Color.Transparent)
                    .pointerInput(opt) {
                        detectTapGestures { onSelect(opt) }
                    }
                    .padding(horizontal = RepwiseSpacing.sm, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = opt,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                    ),
                    color = if (isSel) RepwiseOnLime else TextSecondary
                )
            }
        }
    }
}

private val WEEK_FORMATTER = DateTimeFormatter.ofPattern("d MMM", Locale.US)
private val MONTH_FORMATTER = DateTimeFormatter.ofPattern("MMM", Locale.US)
private val DAY_FORMATTER = DateTimeFormatter.ofPattern("MMM d", Locale.US)

private fun formatWeekShortLabel(epochMillis: Long): String {
    return Instant.ofEpochMilli(epochMillis)
        .atZone(ZoneId.systemDefault())
        .format(WEEK_FORMATTER)
}

private fun formatMonthShortLabel(epochMillis: Long): String {
    return Instant.ofEpochMilli(epochMillis)
        .atZone(ZoneId.systemDefault())
        .format(MONTH_FORMATTER)
}

private fun formatDayLabel(epochMillis: Long): String {
    return Instant.ofEpochMilli(epochMillis)
        .atZone(ZoneId.systemDefault())
        .format(DAY_FORMATTER)
}
