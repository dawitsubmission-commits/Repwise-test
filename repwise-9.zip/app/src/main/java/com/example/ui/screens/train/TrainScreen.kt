package com.example.ui.screens.train

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.repository.StartWorkoutResult
import com.example.ui.components.WorkoutInProgressConflictDialog
import com.example.ui.screens.active.ActiveWorkoutScreen
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.RepwiseLime
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun TrainScreen(
    onFinish: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val repository = remember { RepwiseRepositoryImpl(context) }
    val scope = rememberCoroutineScope()

    var activeSessionId by remember { mutableStateOf<Long?>(null) }
    var inProgressConflictSessionId by remember { mutableStateOf<Long?>(null) }
    var inProgressConflictName by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    fun startNewWorkout() {
        scope.launch {
            val activePlan = repository.getActiveWorkoutPlan().firstOrNull()
            val todayWeekday = LocalDate.now().dayOfWeek.value
            val todayDay = activePlan?.days?.find { it.day.weekday == todayWeekday }

            val result = if (todayDay != null && todayDay.exercises.isNotEmpty()) {
                repository.startWorkoutFromPlanDay(todayDay.day.id)
            } else {
                repository.startEmptyWorkout("Quick Workout")
            }

            when (result) {
                is StartWorkoutResult.Started -> {
                    activeSessionId = result.sessionId
                    inProgressConflictSessionId = null
                }
                is StartWorkoutResult.ExistingInProgress -> {
                    inProgressConflictSessionId = result.sessionId
                }
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        val inProgress = repository.getActiveInProgressSessionOnce()
        if (inProgress != null) {
            inProgressConflictSessionId = inProgress.session.id
            inProgressConflictName = inProgress.session.dayName
            isLoading = false
        } else {
            startNewWorkout()
        }
    }

    if (inProgressConflictSessionId != null && activeSessionId == null) {
        val conflictId = inProgressConflictSessionId!!
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(CharcoalBackground)
        ) {
            WorkoutInProgressConflictDialog(
                onDismissRequest = onFinish,
                onResume = {
                    activeSessionId = conflictId
                    inProgressConflictSessionId = null
                },
                onDiscardConfirmed = {
                    scope.launch {
                        isLoading = true
                        repository.discardSession(conflictId)
                        inProgressConflictSessionId = null
                        startNewWorkout()
                    }
                },
                sessionName = inProgressConflictName
            )
        }
    } else if (isLoading || activeSessionId == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(CharcoalBackground),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = RepwiseLime)
        }
    } else {
        ActiveWorkoutScreen(
            sessionId = activeSessionId!!,
            onFinishWorkout = onFinish,
            onBack = onFinish,
            modifier = modifier
        )
    }
}
