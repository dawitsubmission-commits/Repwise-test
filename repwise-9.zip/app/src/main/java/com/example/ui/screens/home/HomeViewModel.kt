package com.example.ui.screens.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.models.CatalogExercise
import com.example.domain.repository.RepwiseRepository
import com.example.domain.repository.StartWorkoutResult
import com.example.domain.stats.ComputedWorkoutStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

sealed interface TodayWorkoutStatus {
    data class Scheduled(
        val planDayId: Long,
        val routineName: String,
        val dayName: String,
        val exerciseCount: Int,
        val estimatedMinutes: Int,
        val exerciseNames: List<String>
    ) : TodayWorkoutStatus

    data object RestDay : TodayWorkoutStatus

    data object NoRoutineYet : TodayWorkoutStatus
}

data class HomeUiState(
    val todayStatus: TodayWorkoutStatus = TodayWorkoutStatus.NoRoutineYet,
    val inProgressSession: WorkoutSessionWithExercises? = null,
    val stats: ComputedWorkoutStats = ComputedWorkoutStats(),
    val isLoading: Boolean = false
)

class HomeViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _isLoading = MutableStateFlow(true)

    init {
        viewModelScope.launch {
            repository.ensureCatalogInitialized()
            _isLoading.value = false
        }
    }

    val uiState: StateFlow<HomeUiState> = combine(
        repository.getActiveWorkoutPlan(),
        repository.getCatalogExercises(),
        repository.getActiveInProgressSession(),
        repository.getComputedStatsFlow(),
        _isLoading
    ) { activePlan, catalogList, inProgressSession, computedStats, loading ->
        val todayWeekday = LocalDate.now().dayOfWeek.value // 1 = Mon .. 7 = Sun
        val catalogMap = catalogList.associateBy { it.id }

        val status: TodayWorkoutStatus = if (activePlan == null) {
            TodayWorkoutStatus.NoRoutineYet
        } else {
            val scheduledDay = activePlan.days.find { it.day.weekday == todayWeekday }
            if (scheduledDay != null && scheduledDay.exercises.isNotEmpty()) {
                val exNames = scheduledDay.exercises.map {
                    catalogMap[it.exerciseId]?.name?.replaceFirstChar { c -> c.uppercase() } ?: "Exercise"
                }
                TodayWorkoutStatus.Scheduled(
                    planDayId = scheduledDay.day.id,
                    routineName = activePlan.plan.name,
                    dayName = scheduledDay.day.name,
                    exerciseCount = scheduledDay.exercises.size,
                    estimatedMinutes = (scheduledDay.exercises.size * 10).coerceAtLeast(35),
                    exerciseNames = exNames
                )
            } else {
                TodayWorkoutStatus.RestDay
            }
        }

        HomeUiState(
            todayStatus = status,
            inProgressSession = inProgressSession,
            stats = computedStats,
            isLoading = loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    fun startScheduledWorkout(
        onStarted: (Long) -> Unit,
        onConflict: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val status = uiState.value.todayStatus
            val result = if (status is TodayWorkoutStatus.Scheduled) {
                repository.startWorkoutFromPlanDay(status.planDayId)
            } else {
                repository.startEmptyWorkout("Full Body Workout")
            }
            when (result) {
                is StartWorkoutResult.Started -> onStarted(result.sessionId)
                is StartWorkoutResult.ExistingInProgress -> onConflict(result.sessionId)
            }
        }
    }

    fun startEmptyWorkout(
        onStarted: (Long) -> Unit,
        onConflict: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            when (val result = repository.startEmptyWorkout("Quick Workout")) {
                is StartWorkoutResult.Started -> onStarted(result.sessionId)
                is StartWorkoutResult.ExistingInProgress -> onConflict(result.sessionId)
            }
        }
    }

    fun discardSession(sessionId: Long) {
        viewModelScope.launch {
            repository.discardSession(sessionId)
        }
    }
}
