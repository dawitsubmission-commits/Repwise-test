package com.example.ui.components

import android.content.Context
import android.graphics.RectF
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.caverock.androidsvg.SVG
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseShapes
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * Reusable ExerciseAnimation composable that renders SVGs from assets using AndroidSVG.
 * - Decodes only the 3 frames of the visible exercise.
 * - Loops sequence [0, 1, 2, 1] using frameDurationMs with default speedMultiplier = 0.5f.
 * - Pauses when lifecycle is not RESUMED.
 * - Shows frame 0 only if system animations are disabled.
 * - Light silhouette on dark surface with contain sizing and viewBox preserved.
 * - If animation is null or file is missing/invalid, renders a text-only card.
 */
@Composable
fun ExerciseAnimation(
    frames: List<String>?,
    sequence: List<Int> = listOf(0, 1, 2, 1),
    frameDurationMs: Long = 180L,
    speedMultiplier: Float = 0.5f,
    exerciseName: String = "",
    targetMuscle: String = "",
    equipment: String = "",
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Lifecycle state observer: pause when not RESUMED
    var isLifecycleResumed by remember {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            isLifecycleResumed = (event == Lifecycle.Event.ON_RESUME)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Check system animation settings: if animations are off, show frame 0 only
    val areSystemAnimationsDisabled = remember(context) {
        areAnimationsDisabled(context)
    }

    // Decoded SVG frames cache (only 3 frames)
    var decodedFrames by remember(frames) { mutableStateOf<List<SVG>?>(null) }
    var isErrorOrNull by remember(frames) { mutableStateOf(frames.isNullOrEmpty() || frames.size < 3) }
    var isLoading by remember(frames) { mutableStateOf(!frames.isNullOrEmpty() && frames.size >= 3) }

    // Sequence index pointer
    var sequencePointer by remember(frames) { mutableIntStateOf(0) }

    // Decode only the 3 frames of the visible exercise asynchronously
    LaunchedEffect(frames) {
        if (frames.isNullOrEmpty() || frames.size < 3) {
            isErrorOrNull = true
            isLoading = false
            return@LaunchedEffect
        }

        isLoading = true
        val svgs = withContext(Dispatchers.IO) {
            try {
                // Decode strictly the 3 frames
                val list = mutableListOf<SVG>()
                for (i in 0 until 3) {
                    val path = frames[i]
                    context.assets.open(path).use { stream ->
                        val svg = SVG.getFromInputStream(stream)
                        list.add(svg)
                    }
                }
                list
            } catch (e: Exception) {
                null
            }
        }

        if (svgs != null && svgs.size == 3) {
            decodedFrames = svgs
            isErrorOrNull = false
        } else {
            isErrorOrNull = true
        }
        isLoading = false
    }

    // Animation Loop: [0, 1, 2, 1] using frameDurationMs / speedMultiplier
    LaunchedEffect(decodedFrames, isLifecycleResumed, areSystemAnimationsDisabled, speedMultiplier, frameDurationMs, sequence) {
        if (decodedFrames == null || !isLifecycleResumed || areSystemAnimationsDisabled || sequence.isEmpty()) {
            return@LaunchedEffect
        }

        val stepDelayMs = if (speedMultiplier > 0f) {
            (frameDurationMs / speedMultiplier).toLong().coerceAtLeast(16L)
        } else {
            frameDurationMs
        }

        while (isActive) {
            delay(stepDelayMs)
            sequencePointer = (sequencePointer + 1) % sequence.size
        }
    }

    // UI Container: Dark charcoal surface
    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RepwiseShapes.large)
            .background(CharcoalSurface)
            .border(1.dp, CharcoalBorderSubtle, RepwiseShapes.large),
        contentAlignment = Alignment.Center
    ) {
        when {
            isLoading -> {
                CircularProgressIndicator(
                    color = RepwiseLime,
                    modifier = Modifier.size(36.dp)
                )
            }
            isErrorOrNull || decodedFrames == null -> {
                // Text-only fallback card when animation is null, missing, or invalid
                TextOnlyFallbackCard(
                    exerciseName = exerciseName,
                    targetMuscle = targetMuscle,
                    equipment = equipment
                )
            }
            else -> {
                val activeSvgIndex = if (areSystemAnimationsDisabled) {
                    sequence.firstOrNull() ?: 0
                } else {
                    sequence[sequencePointer % sequence.size]
                }.coerceIn(0, (decodedFrames?.size ?: 1) - 1)

                val svg = decodedFrames?.getOrNull(activeSvgIndex)

                if (svg != null) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(RepwiseSpacing.md)
                            .clipToBounds()
                    ) {
                        drawIntoCanvas { canvas ->
                            val dstRect = RectF(0f, 0f, size.width, size.height)
                            svg.renderToCanvas(canvas.nativeCanvas, dstRect)
                        }
                    }
                } else {
                    TextOnlyFallbackCard(
                        exerciseName = exerciseName,
                        targetMuscle = targetMuscle,
                        equipment = equipment
                    )
                }
            }
        }
    }
}

/**
 * Text-only fallback card shown when animation is null or SVG file is missing or invalid.
 */
@Composable
private fun TextOnlyFallbackCard(
    exerciseName: String,
    targetMuscle: String,
    equipment: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(RepwiseSpacing.lg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RepwiseShapes.medium)
                .background(CharcoalSurfaceElevated),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.FitnessCenter,
                contentDescription = null,
                tint = RepwiseLime,
                modifier = Modifier.size(28.dp)
            )
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

        Text(
            text = exerciseName.ifEmpty { "Exercise Preview" },
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = TextHighEmphasis,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

        Text(
            text = "Target: $targetMuscle • $equipment",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

        Text(
            text = "No animation sequence available for this exercise.",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Checks if system animation scales are turned off in Android settings.
 */
private fun areAnimationsDisabled(context: Context): Boolean {
    return try {
        val durationScale = Settings.Global.getFloat(
            context.contentResolver,
            Settings.Global.ANIMATOR_DURATION_SCALE,
            1.0f
        )
        val transitionScale = Settings.Global.getFloat(
            context.contentResolver,
            Settings.Global.TRANSITION_ANIMATION_SCALE,
            1.0f
        )
        durationScale == 0f || transitionScale == 0f
    } catch (e: Exception) {
        false
    }
}
