package com.example.ui.screens.active

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.models.CatalogExercise
import com.example.domain.warmup.DrillKind
import com.example.domain.warmup.WarmupDrill
import com.example.ui.components.ExerciseAnimation
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseShapes
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

enum class WarmupStatus {
    NOT_STARTED,
    RUNNING,
    DONE,
    SKIPPED
}

@Composable
fun WarmupCard(
    status: WarmupStatus,
    drills: List<WarmupDrill>,
    currentIndex: Int,
    secondsRemaining: Int,
    catalogMap: Map<String, CatalogExercise>,
    onStart: () -> Unit,
    onNext: () -> Unit,
    onBack: () -> Unit,
    onSkip: () -> Unit,
    onRedo: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (drills.isEmpty()) return

    RepwiseCard(
        modifier = modifier.testTag("warmup_card"),
        contentPadding = if (status == WarmupStatus.DONE || status == WarmupStatus.SKIPPED) {
            RepwiseSpacing.sm
        } else {
            RepwiseSpacing.md
        }
    ) {
        when (status) {
            WarmupStatus.NOT_STARTED -> {
                // Idle state: "Warm-up · about N min"
                val totalSeconds = drills.sumOf { it.seconds }
                val estMinutes = maxOf(1, (totalSeconds + 30) / 60)

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Warm-up · about $estMinutes min",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                        Text(
                            text = "${drills.size} drills",
                            style = MaterialTheme.typography.labelSmall,
                            color = RepwiseLime
                        )
                    }

                    // Short list of drill names
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        drills.forEach { drill ->
                            val ex = catalogMap[drill.exerciseId]
                            val name = ex?.name?.replaceFirstChar { it.uppercase() }
                                ?: "Drill ${drill.exerciseId}"
                            val kindText = if (drill.kind == DrillKind.DYNAMIC) "Dynamic" else "Stretch"

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(RepwiseLime)
                                )
                                Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextHighEmphasis,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                                Text(
                                    text = "${drill.seconds}s · $kindText",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                    // Buttons: Start warm-up & Skip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PrimaryButton(
                            text = "Start warm-up",
                            onClick = onStart,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("start_warmup_button")
                        )
                        SecondaryButton(
                            text = "Skip",
                            onClick = onSkip,
                            modifier = Modifier.testTag("skip_warmup_button")
                        )
                    }
                }
            }

            WarmupStatus.RUNNING -> {
                // Running state: current drill, animation or text card, drill N of M, countdown, Next, Back, Skip
                val currentDrill = drills.getOrNull(currentIndex) ?: return@RepwiseCard
                val catalogEx = catalogMap[currentDrill.exerciseId]
                val drillName = catalogEx?.name?.replaceFirstChar { it.uppercase() }
                    ?: "Drill ${currentIndex + 1}"

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
                ) {
                    // Header with drill number and name
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Drill ${currentIndex + 1} of ${drills.size}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = RepwiseLime
                            )
                            Text(
                                text = drillName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextHighEmphasis,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = if (currentDrill.kind == DrillKind.DYNAMIC) "Dynamic" else "Stretch",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    // Animation or instructions card
                    if (catalogEx != null && catalogEx.hasAnimation) {
                        val frames = listOfNotNull(
                            catalogEx.frame00Path,
                            catalogEx.frame01Path,
                            catalogEx.frame02Path
                        )
                        ExerciseAnimation(
                            frames = frames,
                            sequence = catalogEx.sequence,
                            frameDurationMs = catalogEx.frameDurationMs ?: 180L,
                            speedMultiplier = 0.5f,
                            exerciseName = catalogEx.name,
                            targetMuscle = catalogEx.target,
                            equipment = catalogEx.equipment,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RepwiseShapes.medium)
                                .background(CharcoalSurfaceElevated)
                                .border(1.dp, CharcoalBorderSubtle, RepwiseShapes.medium)
                                .padding(RepwiseSpacing.md),
                            verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)
                        ) {
                            Text(
                                text = "Instructions",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime
                            )
                            if (!catalogEx?.instructions.isNullOrEmpty()) {
                                catalogEx!!.instructions.forEachIndexed { i, step ->
                                    Text(
                                        text = "${i + 1}. $step",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextHighEmphasis
                                    )
                                }
                            } else {
                                Text(
                                    text = "Perform this drill smoothly and with control for the full duration.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    // Big countdown
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "${secondsRemaining}s",
                            style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Black),
                            color = RepwiseLime,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Remaining",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    // Action buttons: Back, Next, Skip warm-up
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (currentIndex > 0) {
                            SecondaryButton(
                                text = "Back",
                                onClick = onBack,
                                modifier = Modifier.testTag("back_drill_button")
                            )
                        }

                        PrimaryButton(
                            text = if (currentIndex == drills.size - 1) "Finish" else "Next",
                            onClick = onNext,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("next_drill_button")
                        )

                        TextButton(
                            onClick = onSkip,
                            modifier = Modifier.testTag("skip_warmup_button")
                        ) {
                            Text(
                                text = "Skip",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            WarmupStatus.DONE, WarmupStatus.SKIPPED -> {
                // Done or Skipped: collapse to one small line "Warm-up done" (or "Warm-up skipped") with a "Redo" text button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = RepwiseSpacing.xs),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        Icon(
                            imageVector = if (status == WarmupStatus.DONE) Icons.Default.Check else Icons.Default.Close,
                            contentDescription = null,
                            tint = if (status == WarmupStatus.DONE) RepwiseLime else TextTertiary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (status == WarmupStatus.DONE) "Warm-up done" else "Warm-up skipped",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = if (status == WarmupStatus.DONE) TextHighEmphasis else TextSecondary
                        )
                    }

                    TextButton(
                        onClick = onRedo,
                        modifier = Modifier.testTag("warmup_redo_button")
                    ) {
                        Text(
                            text = "Redo",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = RepwiseLime
                        )
                    }
                }
            }
        }
    }
}
