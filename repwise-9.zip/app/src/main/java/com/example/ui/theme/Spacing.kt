package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

data class RepwiseSpacingTokens(
    val none: Dp = 0.dp,
    val xxs: Dp = 2.dp,
    val xs: Dp = 4.dp,    // Spacing token: 4 dp
    val sm: Dp = 8.dp,    // Spacing token: 8 dp
    val md: Dp = 16.dp,   // Spacing token: 16 dp
    val lg: Dp = 24.dp,   // Spacing token: 24 dp
    val xl: Dp = 32.dp,
    val xxl: Dp = 48.dp
)

val LocalRepwiseSpacing = staticCompositionLocalOf { RepwiseSpacingTokens() }

val RepwiseSpacing: RepwiseSpacingTokens
    @Composable
    @ReadOnlyComposable
    get() = LocalRepwiseSpacing.current
