package com.example.ui.screens.library

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.models.CatalogExercise
import com.example.ui.components.EmptyState
import com.example.ui.components.ExerciseStaticThumbnail
import com.example.ui.components.FilterChipRow
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.TestTags

@Composable
fun LibraryScreen(
    onExerciseClick: (String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: LibraryViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val focusManager = LocalFocusManager.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .testTag(TestTags.SCREEN_LIBRARY),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
    ) {
        // Section Header
        item {
            Column(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                SectionHeader(
                    title = "Exercise Catalog",
                    subtitle = "Search & inspect movement animations"
                )
            }
        }

        // Search Bar
        item {
            Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.onSearchQueryChange(it) },
                    placeholder = {
                        Text(
                            text = "Search exercises by name...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = RepwiseLime
                        )
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = TextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                    shape = PillShape,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CharcoalSurface,
                        unfocusedContainerColor = CharcoalSurface,
                        focusedBorderColor = RepwiseLime,
                        unfocusedBorderColor = CharcoalBorderSubtle,
                        focusedTextColor = TextHighEmphasis,
                        unfocusedTextColor = TextHighEmphasis,
                        cursorColor = RepwiseLime
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exercise_search_input")
                )
            }
        }

        // Muscle Filter Chips Row
        item {
            Column {
                Text(
                    text = "TARGET MUSCLE",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xxs)
                )
                val muscleIndex = uiState.muscleFilterOptions.indexOfFirst {
                    it.equals(uiState.selectedMuscle, ignoreCase = true)
                }.coerceAtLeast(0)

                FilterChipRow(
                    items = uiState.muscleFilterOptions.map { it.replaceFirstChar { c -> c.uppercase() } },
                    selectedIndex = muscleIndex,
                    onSelected = { index ->
                        viewModel.onMuscleSelect(uiState.muscleFilterOptions[index])
                    }
                )
            }
        }

        // Equipment Filter Chips Row
        item {
            Column {
                Text(
                    text = "EQUIPMENT",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xxs)
                )
                val equipIndex = uiState.equipmentFilterOptions.indexOfFirst {
                    it.equals(uiState.selectedEquipment, ignoreCase = true)
                }.coerceAtLeast(0)

                FilterChipRow(
                    items = uiState.equipmentFilterOptions.map { it.replaceFirstChar { c -> c.uppercase() } },
                    selectedIndex = equipIndex,
                    onSelected = { index ->
                        viewModel.onEquipmentSelect(uiState.equipmentFilterOptions[index])
                    }
                )
            }
        }

        // Results Summary
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = RepwiseSpacing.md),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${uiState.exercises.size} movements found",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = TextSecondary
                )

                if (uiState.searchQuery.isNotEmpty() || uiState.selectedMuscle != "All" || uiState.selectedEquipment != "All") {
                    Text(
                        text = "Reset",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = RepwiseLime,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(RepwiseLimeMuted)
                            .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xxs)
                    )
                }
            }
        }

        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(RepwiseSpacing.xxl),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = RepwiseLime)
                }
            }
        } else if (uiState.exercises.isEmpty()) {
            item {
                EmptyState(
                    title = "No Exercises Found",
                    description = "No movements matched your current search or filter combination.",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = RepwiseLime,
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    actionText = "Clear All Filters",
                    onActionClick = { viewModel.clearFilters() }
                )
            }
        } else {
            // List rows show static frame-00 only, never animation
            items(uiState.exercises, key = { it.id }) { exercise ->
                Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                    ExerciseListRow(
                        exercise = exercise,
                        onClick = { onExerciseClick(exercise.id) }
                    )
                }
            }
        }
    }
}

/**
 * Exercise list row displaying static frame-00 only (never animation).
 */
@Composable
private fun ExerciseListRow(
    exercise: CatalogExercise,
    onClick: () -> Unit
) {
    RepwiseCard(onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Static frame-00 only
                ExerciseStaticThumbnail(
                    frame00Path = exercise.frame00Path,
                    size = 56.dp
                )

                Spacer(modifier = Modifier.width(RepwiseSpacing.md))

                Column {
                    Text(
                        text = exercise.name.replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextHighEmphasis
                    )

                    Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)
                    ) {
                        Text(
                            text = exercise.target.replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = RepwiseLime
                        )
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = exercise.equipment.replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "View detail",
                tint = TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
