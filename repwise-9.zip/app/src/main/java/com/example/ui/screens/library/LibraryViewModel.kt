package com.example.ui.screens.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.models.CatalogExercise
import com.example.domain.normalization.Normalizer
import com.example.domain.repository.RepwiseRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryUiState(
    val searchQuery: String = "",
    val selectedMuscle: String = "All",
    val selectedEquipment: String = "All",
    val muscleFilterOptions: List<String> = Normalizer.getAllFilterMuscles(),
    val equipmentFilterOptions: List<String> = Normalizer.getAllFilterEquipments(),
    val exercises: List<CatalogExercise> = emptyList(),
    val isLoading: Boolean = true
)

@OptIn(FlowPreview::class)
class LibraryViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _searchQuery = MutableStateFlow("")
    private val _selectedMuscle = MutableStateFlow("All")
    private val _selectedEquipment = MutableStateFlow("All")
    private val _isLoading = MutableStateFlow(true)

    private val backMuscles = setOf("lats", "upper back", "lower back", "rhomboids", "spine", "back")
    private val standardEquipments = setOf(
        "body weight",
        "dumbbell",
        "barbell",
        "cable",
        "resistance band",
        "leverage machine",
        "smith machine",
        "kettlebell"
    )

    init {
        viewModelScope.launch {
            repository.ensureCatalogInitialized()
            _isLoading.value = false
        }
    }

    private val debouncedQuery = _searchQuery.debounce { if (it.isEmpty()) 0L else 250L }

    private val filteredExercises = combine(
        repository.getCatalogExercises(),
        debouncedQuery,
        _selectedMuscle,
        _selectedEquipment
    ) { allExercises, query, muscle, equip ->
        allExercises.filter { exercise ->
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                exercise.name.contains(query, ignoreCase = true)
            }

            val matchesMuscle = if (muscle.equals("All", ignoreCase = true)) {
                true
            } else if (muscle.equals("back", ignoreCase = true)) {
                exercise.target in backMuscles || exercise.secondaryMuscles.any { it in backMuscles }
            } else {
                exercise.target.equals(muscle, ignoreCase = true) ||
                    exercise.secondaryMuscles.any { it.equals(muscle, ignoreCase = true) }
            }

            val matchesEquipment = if (equip.equals("All", ignoreCase = true)) {
                true
            } else if (equip.equals("other", ignoreCase = true)) {
                exercise.equipment !in standardEquipments
            } else {
                exercise.equipment.equals(equip, ignoreCase = true)
            }

            matchesQuery && matchesMuscle && matchesEquipment
        }
    }

    val uiState: StateFlow<LibraryUiState> = combine(
        _searchQuery,
        _selectedMuscle,
        _selectedEquipment,
        _isLoading,
        filteredExercises
    ) { query, muscle, equip, loading, exercises ->
        LibraryUiState(
            searchQuery = query,
            selectedMuscle = muscle,
            selectedEquipment = equip,
            exercises = exercises,
            isLoading = loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryUiState()
    )

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onMuscleSelect(muscle: String) {
        _selectedMuscle.value = muscle
    }

    fun onEquipmentSelect(equipment: String) {
        _selectedEquipment.value = equipment
    }

    fun clearFilters() {
        _searchQuery.value = ""
        _selectedMuscle.value = "All"
        _selectedEquipment.value = "All"
    }
}
