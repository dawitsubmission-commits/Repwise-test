package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.RepwiseShapes
import com.example.ui.theme.RepwiseSpacing
import com.example.util.TestTags

@Composable
fun RepwiseCard(
    modifier: Modifier = Modifier,
    shape: Shape = RepwiseShapes.medium,
    containerColor: Color = CharcoalSurface,
    borderColor: Color = CharcoalBorderSubtle,
    contentPadding: Dp = RepwiseSpacing.md,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val cardModifier = if (onClick != null) {
        modifier
            .fillMaxWidth()
            .testTag(TestTags.REPEWISE_CARD)
            .clip(shape)
            .clickable(onClick = onClick)
    } else {
        modifier
            .fillMaxWidth()
            .testTag(TestTags.REPEWISE_CARD)
    }

    Surface(
        shape = shape,
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = cardModifier
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}
