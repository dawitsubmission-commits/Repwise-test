package com.example.ui.components

import android.util.LruCache
import com.caverock.androidsvg.SVG

/**
 * Thread-safe LRU cache holding up to 60 parsed SVG objects.
 * Used for fast rendering of static exercise thumbnails.
 */
object SvgCache {
    private val cache = LruCache<String, SVG>(60)

    fun get(path: String): SVG? = synchronized(cache) {
        cache.get(path)
    }

    fun put(path: String, svg: SVG) {
        synchronized(cache) {
            cache.put(path, svg)
        }
    }

    fun clear() {
        synchronized(cache) {
            cache.evictAll()
        }
    }
}
