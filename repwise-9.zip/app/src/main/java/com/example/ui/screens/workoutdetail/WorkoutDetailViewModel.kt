package com.example.ui.screens.workoutdetail

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.history.WorkoutHistoryHelper
import com.example.domain.repository.RepwiseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class SetDetailItem(
    val id: Long,
    val setIndex: Int,
    val reps: Int,
    val weightKg: Double,
    val isWarmup: Boolean,
    val isCompleted: Boolean,
    val isPr: Boolean
)

data class SessionExerciseDetailItem(
    val sessionExerciseId: Long,
    val exerciseId: String,
    val exerciseName: String,
    val targetMuscle: String,
    val equipment: String,
    val note: String?,
    val replacedFromExerciseName: String?,
    val sets: List<SetDetailItem>
)

data class WorkoutDetailUiState(
    val session: WorkoutSessionEntity? = null,
    val exercises: List<SessionExerciseDetailItem> = emptyList(),
    val totalVolumeKg: Double = 0.0,
    val durationText: String = "",
    val dateText: String = "",
    val prCount: Int = 0,
    val isLoading: Boolean = true
)

class WorkoutDetailViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _uiState = MutableStateFlow(WorkoutDetailUiState())
    val uiState: StateFlow<WorkoutDetailUiState> = _uiState.asStateFlow()

    fun loadSession(sessionId: Long) {
        viewModelScope.launch {
            combine(
                repository.getSessionById(sessionId),
                repository.getAllPersonalRecords(),
                repository.getCatalogExercises()
            ) { sessionWithExercises, prs, catalog ->
                if (sessionWithExercises == null) {
                    WorkoutDetailUiState(isLoading = false)
                } else {
                    val catalogMap = catalog.associateBy { it.id }
                    val prSetLogIds = WorkoutHistoryHelper.getPrSetLogIdsForSession(sessionWithExercises, prs)
                    val totalVolume = WorkoutHistoryHelper.calculateTotalVolume(sessionWithExercises)
                    val durationText = WorkoutHistoryHelper.formatDuration(
                        sessionWithExercises.session.startedAt,
                        sessionWithExercises.session.endedAt
                    )
                    val dateText = WorkoutHistoryHelper.formatDate(
                        sessionWithExercises.session.endedAt ?: sessionWithExercises.session.startedAt
                    )

                    val exerciseItems = sessionWithExercises.exercises
                        .sortedBy { it.exercise.position }
                        .map { exWithSets ->
                            val catEx = catalogMap[exWithSets.exercise.exerciseId]
                            val exerciseName = catEx?.name?.replaceFirstChar { it.uppercase() }
                                ?: "Exercise ${exWithSets.exercise.exerciseId}"

                            val replacedFromName = exWithSets.exercise.replacedExerciseId?.let { replId ->
                                catalogMap[replId]?.name?.replaceFirstChar { it.uppercase() } ?: replId
                            }

                            val setDetails = exWithSets.sets
                                .sortedBy { it.setIndex }
                                .map { setLog ->
                                    SetDetailItem(
                                        id = setLog.id,
                                        setIndex = setLog.setIndex,
                                        reps = setLog.reps,
                                        weightKg = setLog.weightKg,
                                        isWarmup = setLog.isWarmup,
                                        isCompleted = setLog.completedAt != null,
                                        isPr = setLog.id in prSetLogIds
                                    )
                                }

                            SessionExerciseDetailItem(
                                sessionExerciseId = exWithSets.exercise.id,
                                exerciseId = exWithSets.exercise.exerciseId,
                                exerciseName = exerciseName,
                                targetMuscle = catEx?.target ?: "",
                                equipment = catEx?.equipment ?: "",
                                note = exWithSets.exercise.note,
                                replacedFromExerciseName = replacedFromName,
                                sets = setDetails
                            )
                        }

                    WorkoutDetailUiState(
                        session = sessionWithExercises.session,
                        exercises = exerciseItems,
                        totalVolumeKg = totalVolume,
                        durationText = durationText,
                        dateText = dateText,
                        prCount = prSetLogIds.size,
                        isLoading = false
                    )
                }
            }.collect { state ->
                _uiState.value = state
            }
        }
    }
}
