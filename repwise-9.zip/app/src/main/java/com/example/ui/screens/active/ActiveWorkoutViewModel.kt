package com.example.ui.screens.active

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.SessionExerciseWithSets
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.PersonalRecordDetector
import com.example.domain.PreviousPerformance
import com.example.domain.alternatives.AlternativesFinder
import com.example.domain.models.CatalogExercise
import com.example.domain.repository.RepwiseRepository
import com.example.domain.warmup.WarmupDrill
import com.example.domain.warmup.WarmupPlanner
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

data class WorkoutSummaryData(
    val dayName: String,
    val durationSeconds: Long,
    val totalExercises: Int,
    val totalSetsCompleted: Int,
    val totalVolumeKg: Double,
    val newRecords: List<PersonalRecordEntity>
)

data class ActiveWorkoutUiState(
    val sessionId: Long = 0L,
    val sessionWithExercises: WorkoutSessionWithExercises? = null,
    val catalogMap: Map<String, CatalogExercise> = emptyMap(),
    val allCatalogExercises: List<CatalogExercise> = emptyList(),
    val previousPerformanceMap: Map<String, PreviousPerformance> = emptyMap(),
    val historicalCompletedSetsMap: Map<String, List<SetLogEntity>> = emptyMap(),
    val elapsedSeconds: Long = 0L,
    val restTimerEndTime: Long? = null,
    val restSecondsRemaining: Int = 0,
    val expandedExerciseId: String? = null,
    val substituteTarget: SessionExerciseWithSets? = null,
    val substituteAlternatives: List<CatalogExercise> = emptyList(),
    val isAddExercisePickerOpen: Boolean = false,
    val showFinishConfirm: Boolean = false,
    val showDiscardConfirm: Boolean = false,
    val workoutSummary: WorkoutSummaryData? = null,
    val warmupDrills: List<WarmupDrill> = emptyList(),
    val warmupStatus: WarmupStatus = WarmupStatus.NOT_STARTED,
    val warmupIndex: Int = 0,
    val warmupEndTime: Long? = null,
    val warmupSecondsRemaining: Int = 0,
    val isLoading: Boolean = true
)

class ActiveWorkoutViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _uiState = MutableStateFlow(ActiveWorkoutUiState())
    val uiState: StateFlow<ActiveWorkoutUiState> = _uiState.asStateFlow()

    private var durationTimerJob: Job? = null
    private var restTimerJob: Job? = null
    private var warmupTimerJob: Job? = null
    private var hasVibratedForCurrentTimer = false
    private var isFinishing = false

    fun initSession(sessionId: Long) {
        if (_uiState.value.sessionId == sessionId && _uiState.value.sessionWithExercises != null) {
            return
        }

        _uiState.value = _uiState.value.copy(sessionId = sessionId, isLoading = true)

        viewModelScope.launch {
            // Load catalog ONCE
            val catalog = repository.getCatalogExercises().firstOrNull() ?: emptyList()
            val catMap = catalog.associateBy { it.id }

            // Load historical completed sessions & sets ONCE
            val allCompleted = repository.getCompletedSessions().firstOrNull() ?: emptyList()
            val priorSessions = allCompleted.filter { it.session.id != sessionId }
            val histMap = mutableMapOf<String, List<SetLogEntity>>()
            for (cs in priorSessions) {
                for (se in cs.exercises) {
                    val exId = se.exercise.exerciseId
                    val existing = histMap[exId] ?: emptyList()
                    histMap[exId] = existing + se.sets
                }
            }

            // Load previous performances ONCE
            val initialSession = repository.getSessionByIdOnce(sessionId)
            val prevMap = mutableMapOf<String, PreviousPerformance>()
            if (initialSession != null) {
                for (ex in initialSession.exercises) {
                    val exId = ex.exercise.exerciseId
                    val prev = repository.getPreviousPerformance(exId)
                    if (prev != null) prevMap[exId] = prev
                }
            }

            val catalogIds = catMap.keys
            val sessionTargets = initialSession?.exercises?.mapNotNull { catMap[it.exercise.exerciseId]?.target } ?: emptyList()
            val initialWarmupDrills = WarmupPlanner.plan(sessionTargets, catalogIds)

            _uiState.value = _uiState.value.copy(
                catalogMap = catMap,
                allCatalogExercises = catalog,
                previousPerformanceMap = prevMap,
                historicalCompletedSetsMap = histMap,
                warmupDrills = initialWarmupDrills,
                warmupSecondsRemaining = initialWarmupDrills.firstOrNull()?.seconds ?: 0
            )

            // Observe ONLY the session itself live from Room
            launch {
                repository.getSessionById(sessionId).collect { sessionWithExercises ->
                    if (sessionWithExercises != null) {
                        // Default expanded exercise to first if not set
                        val currentExpanded = _uiState.value.expandedExerciseId
                            ?: sessionWithExercises.exercises.firstOrNull()?.exercise?.exerciseId

                        // If any new exercise was added or substituted during workout, fetch its previous performance once
                        val currentPrevMap = _uiState.value.previousPerformanceMap.toMutableMap()
                        var prevChanged = false
                        for (ex in sessionWithExercises.exercises) {
                            val exId = ex.exercise.exerciseId
                            if (!currentPrevMap.containsKey(exId)) {
                                val prev = repository.getPreviousPerformance(exId)
                                if (prev != null) {
                                    currentPrevMap[exId] = prev
                                    prevChanged = true
                                }
                            }
                        }

                        val currentWarmupDrills = if (_uiState.value.warmupDrills.isEmpty() && _uiState.value.warmupStatus == WarmupStatus.NOT_STARTED) {
                            val targets = sessionWithExercises.exercises.mapNotNull { catMap[it.exercise.exerciseId]?.target }
                            WarmupPlanner.plan(targets, catMap.keys)
                        } else {
                            _uiState.value.warmupDrills
                        }

                        _uiState.value = _uiState.value.copy(
                            sessionWithExercises = sessionWithExercises,
                            previousPerformanceMap = if (prevChanged) currentPrevMap else _uiState.value.previousPerformanceMap,
                            expandedExerciseId = currentExpanded,
                            warmupDrills = currentWarmupDrills,
                            warmupSecondsRemaining = if (_uiState.value.warmupStatus == WarmupStatus.NOT_STARTED) {
                                currentWarmupDrills.firstOrNull()?.seconds ?: 0
                            } else {
                                _uiState.value.warmupSecondsRemaining
                            },
                            isLoading = false
                        )
                    }
                }
            }

            // Start duration ticker based on startedAt
            startDurationTimer()
            startRestTimerObserver()
            startWarmupTimerObserver()
        }
    }

    private fun startDurationTimer() {
        durationTimerJob?.cancel()
        durationTimerJob = viewModelScope.launch {
            while (true) {
                val startedAt = _uiState.value.sessionWithExercises?.session?.startedAt
                if (startedAt != null) {
                    val now = System.currentTimeMillis()
                    val elapsed = maxOf(0L, (now - startedAt) / 1000L)
                    _uiState.value = _uiState.value.copy(elapsedSeconds = elapsed)
                }
                delay(1000)
            }
        }
    }

    private fun startRestTimerObserver() {
        restTimerJob?.cancel()
        restTimerJob = viewModelScope.launch {
            while (true) {
                val endTime = _uiState.value.restTimerEndTime
                if (endTime != null) {
                    val now = System.currentTimeMillis()
                    val diff = endTime - now
                    if (diff <= 0) {
                        // Timer expired!
                        if (!hasVibratedForCurrentTimer) {
                            vibrateDevice()
                            hasVibratedForCurrentTimer = true
                        }
                        _uiState.value = _uiState.value.copy(
                            restTimerEndTime = null,
                            restSecondsRemaining = 0
                        )
                    } else {
                        val remainingSec = ((diff + 999) / 1000).toInt()
                        _uiState.value = _uiState.value.copy(restSecondsRemaining = remainingSec)
                    }
                }
                delay(250)
            }
        }
    }

    private fun startWarmupTimerObserver() {
        warmupTimerJob?.cancel()
        warmupTimerJob = viewModelScope.launch {
            while (true) {
                val state = _uiState.value
                if (state.warmupStatus == WarmupStatus.RUNNING && state.warmupEndTime != null) {
                    val now = System.currentTimeMillis()
                    val diff = state.warmupEndTime - now
                    if (diff <= 0) {
                        // Drill ended: vibrate device and advance to next drill
                        vibrateDevice()
                        val nextIdx = state.warmupIndex + 1
                        if (nextIdx < state.warmupDrills.size) {
                            val nextDrill = state.warmupDrills[nextIdx]
                            val newEndTime = System.currentTimeMillis() + (nextDrill.seconds * 1000L)
                            _uiState.value = _uiState.value.copy(
                                warmupIndex = nextIdx,
                                warmupEndTime = newEndTime,
                                warmupSecondsRemaining = nextDrill.seconds
                            )
                        } else {
                            // Completed all drills
                            _uiState.value = _uiState.value.copy(
                                warmupStatus = WarmupStatus.DONE,
                                warmupEndTime = null,
                                warmupSecondsRemaining = 0
                            )
                        }
                    } else {
                        val remainingSec = ((diff + 999) / 1000).toInt()
                        _uiState.value = _uiState.value.copy(warmupSecondsRemaining = remainingSec)
                    }
                }
                delay(250)
            }
        }
    }

    fun startWarmup() {
        val drills = _uiState.value.warmupDrills
        if (drills.isEmpty()) return
        val firstDrill = drills[0]
        val now = System.currentTimeMillis()
        _uiState.value = _uiState.value.copy(
            warmupStatus = WarmupStatus.RUNNING,
            warmupIndex = 0,
            warmupEndTime = now + (firstDrill.seconds * 1000L),
            warmupSecondsRemaining = firstDrill.seconds
        )
    }

    fun nextDrill() {
        val state = _uiState.value
        if (state.warmupStatus != WarmupStatus.RUNNING) return
        val nextIdx = state.warmupIndex + 1
        if (nextIdx < state.warmupDrills.size) {
            val nextDrill = state.warmupDrills[nextIdx]
            val newEndTime = System.currentTimeMillis() + (nextDrill.seconds * 1000L)
            _uiState.value = _uiState.value.copy(
                warmupIndex = nextIdx,
                warmupEndTime = newEndTime,
                warmupSecondsRemaining = nextDrill.seconds
            )
        } else {
            _uiState.value = _uiState.value.copy(
                warmupStatus = WarmupStatus.DONE,
                warmupEndTime = null,
                warmupSecondsRemaining = 0
            )
        }
    }

    fun previousDrill() {
        val state = _uiState.value
        if (state.warmupStatus != WarmupStatus.RUNNING) return
        if (state.warmupIndex > 0) {
            val prevIdx = state.warmupIndex - 1
            val prevDrill = state.warmupDrills[prevIdx]
            val newEndTime = System.currentTimeMillis() + (prevDrill.seconds * 1000L)
            _uiState.value = _uiState.value.copy(
                warmupIndex = prevIdx,
                warmupEndTime = newEndTime,
                warmupSecondsRemaining = prevDrill.seconds
            )
        }
    }

    fun skipWarmup() {
        _uiState.value = _uiState.value.copy(
            warmupStatus = WarmupStatus.SKIPPED,
            warmupEndTime = null,
            warmupSecondsRemaining = 0
        )
    }

    fun redoWarmup() {
        _uiState.value = _uiState.value.copy(
            warmupStatus = WarmupStatus.NOT_STARTED,
            warmupIndex = 0,
            warmupEndTime = null,
            warmupSecondsRemaining = _uiState.value.warmupDrills.firstOrNull()?.seconds ?: 0
        )
    }

    fun setExpandedExercise(exerciseId: String) {
        _uiState.value = _uiState.value.copy(
            expandedExerciseId = if (_uiState.value.expandedExerciseId == exerciseId) null else exerciseId
        )
    }

    fun toggleSetDone(setLog: SetLogEntity, restSeconds: Int) {
        viewModelScope.launch {
            if (setLog.completedAt == null) {
                // If warm-up is running, mark it done as the user begins logged sets
                if (_uiState.value.warmupStatus == WarmupStatus.RUNNING) {
                    _uiState.value = _uiState.value.copy(
                        warmupStatus = WarmupStatus.DONE,
                        warmupEndTime = null,
                        warmupSecondsRemaining = 0
                    )
                }
                // Mark done immediately in Room
                val now = System.currentTimeMillis()
                val updated = setLog.copy(completedAt = now)
                repository.updateSetLog(updated)

                // Start rest timer with exercise's restSeconds (stores end timestamp)
                startRestTimer(restSeconds)
            } else {
                // Unmark done immediately in Room
                val updated = setLog.copy(completedAt = null)
                repository.updateSetLog(updated)
            }
        }
    }

    fun startRestTimer(seconds: Int) {
        if (seconds <= 0) return
        hasVibratedForCurrentTimer = false
        val endTimestamp = System.currentTimeMillis() + (seconds * 1000L)
        _uiState.value = _uiState.value.copy(
            restTimerEndTime = endTimestamp,
            restSecondsRemaining = seconds
        )
    }

    fun addRestTime(secondsToAdd: Int) {
        val currentEnd = _uiState.value.restTimerEndTime ?: System.currentTimeMillis()
        val newEnd = currentEnd + (secondsToAdd * 1000L)
        val remaining = maxOf(0, ((newEnd - System.currentTimeMillis() + 999) / 1000).toInt())
        _uiState.value = _uiState.value.copy(
            restTimerEndTime = newEnd,
            restSecondsRemaining = remaining
        )
    }

    fun subtractRestTime(secondsToSubtract: Int) {
        val currentEnd = _uiState.value.restTimerEndTime ?: return
        val now = System.currentTimeMillis()
        val newEnd = maxOf(now, currentEnd - (secondsToSubtract * 1000L))
        val remaining = maxOf(0, ((newEnd - now + 999) / 1000).toInt())
        _uiState.value = _uiState.value.copy(
            restTimerEndTime = if (remaining > 0) newEnd else null,
            restSecondsRemaining = remaining
        )
    }

    fun skipRestTimer() {
        _uiState.value = _uiState.value.copy(
            restTimerEndTime = null,
            restSecondsRemaining = 0
        )
    }

    fun updateSetWeight(setLog: SetLogEntity, newWeightKg: Double) {
        viewModelScope.launch {
            repository.updateSetLog(setLog.copy(weightKg = newWeightKg))
        }
    }

    fun updateSetReps(setLog: SetLogEntity, newReps: Int) {
        viewModelScope.launch {
            repository.updateSetLog(setLog.copy(reps = newReps))
        }
    }

    fun toggleSetWarmup(setLog: SetLogEntity) {
        viewModelScope.launch {
            repository.updateSetLog(setLog.copy(isWarmup = !setLog.isWarmup))
        }
    }

    fun addSet(sessionExerciseId: Long, defaultWeight: Double, defaultReps: Int) {
        viewModelScope.launch {
            repository.addSetToExercise(
                sessionExerciseId = sessionExerciseId,
                weightKg = defaultWeight,
                reps = defaultReps,
                isWarmup = false
            )
        }
    }

    fun deleteSet(setLogId: Long) {
        viewModelScope.launch {
            repository.deleteSetLog(setLogId)
        }
    }

    fun updateExerciseNote(sessionExerciseId: Long, note: String) {
        viewModelScope.launch {
            repository.updateExerciseNote(sessionExerciseId, note)
        }
    }

    fun updateSessionNote(note: String) {
        viewModelScope.launch {
            val sessionId = _uiState.value.sessionId
            if (sessionId > 0) {
                repository.updateSessionNote(sessionId, note)
            }
        }
    }

    fun removeExercise(sessionExerciseId: Long) {
        viewModelScope.launch {
            repository.removeExerciseFromSession(sessionExerciseId)
        }
    }

    fun openSubstituteSheet(sessionExercise: SessionExerciseWithSets) {
        val currentExId = sessionExercise.exercise.exerciseId
        val catalogItem = _uiState.value.catalogMap[currentExId]
        val alternatives = if (catalogItem != null) {
            AlternativesFinder.findAlternatives(catalogItem, _uiState.value.allCatalogExercises)
        } else {
            emptyList()
        }

        _uiState.value = _uiState.value.copy(
            substituteTarget = sessionExercise,
            substituteAlternatives = alternatives
        )
    }

    fun closeSubstituteSheet() {
        _uiState.value = _uiState.value.copy(
            substituteTarget = null,
            substituteAlternatives = emptyList()
        )
    }

    fun applySubstitute(newExerciseId: String) {
        val target = _uiState.value.substituteTarget ?: return
        viewModelScope.launch {
            repository.substituteExercise(target.exercise.id, newExerciseId)
            closeSubstituteSheet()
            _uiState.value = _uiState.value.copy(expandedExerciseId = newExerciseId)
        }
    }

    fun openAddExercisePicker() {
        _uiState.value = _uiState.value.copy(isAddExercisePickerOpen = true)
    }

    fun closeAddExercisePicker() {
        _uiState.value = _uiState.value.copy(isAddExercisePickerOpen = false)
    }

    fun addExerciseFromPicker(exerciseId: String) {
        val sessionId = _uiState.value.sessionId
        if (sessionId <= 0) return
        viewModelScope.launch {
            repository.addExerciseToSession(
                sessionId = sessionId,
                exerciseId = exerciseId,
                setsCount = 3,
                repMin = 10,
                restSeconds = 90
            )
            closeAddExercisePicker()
            _uiState.value = _uiState.value.copy(expandedExerciseId = exerciseId)
        }
    }

    fun promptFinish() {
        _uiState.value = _uiState.value.copy(showFinishConfirm = true)
    }

    fun dismissFinishPrompt() {
        _uiState.value = _uiState.value.copy(showFinishConfirm = false)
    }

    fun confirmFinish() {
        val sessionId = _uiState.value.sessionId
        if (sessionId <= 0 || isFinishing) return
        isFinishing = true

        viewModelScope.launch {
            try {
                val sessionWithEx = _uiState.value.sessionWithExercises
                val newRecords = repository.finishSession(sessionId)

                val totalExercises = sessionWithEx?.exercises?.size ?: 0
                val allSets = sessionWithEx?.exercises?.flatMap { it.sets } ?: emptyList()
                val completedSets = allSets.filter { it.completedAt != null }
                val totalVolumeKg = completedSets.filter { !it.isWarmup }.sumOf { it.weightKg * it.reps }

                val summary = WorkoutSummaryData(
                    dayName = sessionWithEx?.session?.dayName ?: "Workout",
                    durationSeconds = _uiState.value.elapsedSeconds,
                    totalExercises = totalExercises,
                    totalSetsCompleted = completedSets.size,
                    totalVolumeKg = totalVolumeKg,
                    newRecords = newRecords
                )

                _uiState.value = _uiState.value.copy(
                    showFinishConfirm = false,
                    workoutSummary = summary
                )
            } finally {
                // If finish didn't produce summary (e.g. error), reset isFinishing
                if (_uiState.value.workoutSummary == null) {
                    isFinishing = false
                }
            }
        }
    }

    fun promptDiscard() {
        _uiState.value = _uiState.value.copy(showDiscardConfirm = true)
    }

    fun dismissDiscardPrompt() {
        _uiState.value = _uiState.value.copy(showDiscardConfirm = false)
    }

    fun confirmDiscard(onDiscarded: () -> Unit) {
        val sessionId = _uiState.value.sessionId
        viewModelScope.launch {
            repository.discardSession(sessionId)
            _uiState.value = _uiState.value.copy(showDiscardConfirm = false)
            onDiscarded()
        }
    }

    fun isSetPR(candidateSet: SetLogEntity, exerciseId: String): Boolean {
        val priors = _uiState.value.historicalCompletedSetsMap[exerciseId] ?: emptyList()
        return PersonalRecordDetector.isSetPR(candidateSet, priors)
    }

    private fun vibrateDevice() {
        try {
            val context = getApplication<Application>()
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(300)
            }
        } catch (_: Exception) {
            // Ignore if vibration unavailable or in headless unit test
        }
    }

    override fun onCleared() {
        super.onCleared()
        durationTimerJob?.cancel()
        restTimerJob?.cancel()
        warmupTimerJob?.cancel()
    }
}
