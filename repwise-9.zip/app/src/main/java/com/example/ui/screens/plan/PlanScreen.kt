package com.example.ui.screens.plan

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.ui.components.EmptyState
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.TestTags
import java.time.LocalDate

@Composable
fun PlanScreen(
    onNavigateToEditor: (Long) -> Unit,
    onNavigateToTemplates: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlanViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var newRoutineName by remember { mutableStateOf("") }
    var planToDelete by remember { mutableStateOf<WorkoutPlanWithDays?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .testTag(TestTags.SCREEN_PLAN),
        contentPadding = PaddingValues(RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.lg)
    ) {
        // App Header
        item {
            Column {
                SectionHeader(
                    title = "Workout Planner",
                    subtitle = "Manage active splits & routine schedules"
                )
            }
        }

        // Action Buttons Row: "New Routine" and "Browse Templates"
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
            ) {
                PrimaryButton(
                    text = "New Routine",
                    onClick = {
                        newRoutineName = "My Routine ${uiState.plans.size + 1}"
                        showCreateDialog = true
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = RepwiseOnLime,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    modifier = Modifier.weight(1f)
                )

                SecondaryButton(
                    text = "Browse Templates",
                    onClick = onNavigateToTemplates,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.ViewCarousel,
                            contentDescription = null,
                            tint = TextHighEmphasis,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Weekly Schedule View: 7 weekdays, showing day name or Rest
        item {
            WeeklyScheduleCard(
                activePlan = uiState.activePlan
            )
        }

        // My Routines Section
        item {
            SectionHeader(
                title = "My Routines",
                subtitle = "${uiState.plans.size} routines created"
            )
        }

        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(RepwiseSpacing.xxl),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = RepwiseLime)
                }
            }
        } else if (uiState.plans.isEmpty()) {
            item {
                EmptyState(
                    title = "No Routines Yet",
                    description = "Choose a proven training program from templates or build your custom split from scratch.",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.FitnessCenter,
                            contentDescription = null,
                            tint = RepwiseLime,
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    actionText = "Browse Workout Templates",
                    onActionClick = onNavigateToTemplates
                )
            }
        } else {
            items(uiState.plans, key = { it.plan.id }) { planWithDays ->
                RoutineCard(
                    planWithDays = planWithDays,
                    onEdit = { onNavigateToEditor(planWithDays.plan.id) },
                    onSetActive = { viewModel.setActivePlan(planWithDays.plan.id) },
                    onDuplicate = {
                        viewModel.duplicatePlan(planWithDays.plan.id) { newId ->
                            onNavigateToEditor(newId)
                        }
                    },
                    onDelete = { planToDelete = planWithDays }
                )
            }
        }
    }

    // Create Routine Dialog
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create New Routine") },
            text = {
                OutlinedTextField(
                    value = newRoutineName,
                    onValueChange = { newRoutineName = it },
                    label = { Text("Routine Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RepwiseLime,
                        focusedTextColor = TextHighEmphasis,
                        unfocusedTextColor = TextHighEmphasis
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCreateDialog = false
                        viewModel.createNewPlan(newRoutineName) { newId ->
                            onNavigateToEditor(newId)
                        }
                    }
                ) {
                    Text("Create & Edit", color = RepwiseLime, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis
        )
    }

    // Delete Routine Confirm Dialog
    val toDelete = planToDelete
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { planToDelete = null },
            title = { Text("Delete Routine?") },
            text = { Text("Are you sure you want to delete '${toDelete.plan.name}'? This will remove all scheduled days and exercises.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deletePlan(toDelete.plan.id)
                        planToDelete = null
                    }
                ) {
                    Text("Delete", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { planToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis,
            textContentColor = TextSecondary
        )
    }
}

/**
 * Weekly schedule view showing 7 weekdays, each showing day name or Rest.
 */
@Composable
private fun WeeklyScheduleCard(
    activePlan: WorkoutPlanWithDays?
) {
    val weekdayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    val todayWeekday = LocalDate.now().dayOfWeek.value // 1 = Monday .. 7 = Sunday

    RepwiseCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = null,
                    tint = RepwiseLime,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                Text(
                    text = "Weekly Schedule",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )
            }

            if (activePlan != null) {
                Text(
                    text = activePlan.plan.name,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime
                )
            } else {
                Text(
                    text = "No active routine",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

        // 7 Weekdays Grid/Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            weekdayLabels.forEachIndexed { index, dayLabel ->
                val weekdayNumber = index + 1
                val isToday = weekdayNumber == todayWeekday
                val assignedDay = activePlan?.days?.find { it.day.weekday == weekdayNumber }

                val cardBg = when {
                    isToday && assignedDay != null -> RepwiseLimeMuted
                    isToday -> CharcoalSurfaceElevated
                    assignedDay != null -> CharcoalSurfaceElevated
                    else -> CharcoalBackground
                }
                val borderCol = when {
                    isToday -> RepwiseLime
                    else -> CharcoalBorderSubtle
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(cardBg)
                        .border(1.dp, borderCol, RoundedCornerShape(8.dp))
                        .padding(vertical = RepwiseSpacing.xs, horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = dayLabel,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isToday) FontWeight.Black else FontWeight.Bold
                        ),
                        color = if (isToday) RepwiseLime else TextSecondary
                    )

                    Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))

                    Text(
                        text = assignedDay?.day?.name ?: "Rest",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (assignedDay != null) FontWeight.SemiBold else FontWeight.Normal
                        ),
                        color = if (assignedDay != null) TextHighEmphasis else TextSecondary.copy(alpha = 0.6f),
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

/**
 * Routine card showing status, stats, and actions (edit, duplicate, delete, set active).
 */
@Composable
private fun RoutineCard(
    planWithDays: WorkoutPlanWithDays,
    onEdit: () -> Unit,
    onSetActive: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val totalExercises = planWithDays.days.sumOf { it.exercises.size }
    val isActive = planWithDays.plan.isActive

    RepwiseCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = planWithDays.plan.name,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = TextHighEmphasis
                    )

                    if (isActive) {
                        Spacer(modifier = Modifier.width(RepwiseSpacing.sm))
                        Box(
                            modifier = Modifier
                                .clip(PillShape)
                                .background(RepwiseLime)
                                .padding(horizontal = RepwiseSpacing.sm, vertical = 2.dp)
                        ) {
                            Text(
                                text = "ACTIVE",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
                                color = RepwiseOnLime
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))

                Text(
                    text = "${planWithDays.days.size} days • $totalExercises exercises total",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

        // Day preview chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)
        ) {
            planWithDays.days.take(4).forEach { dayWithEx ->
                val weekdayText = when (dayWithEx.day.weekday) {
                    1 -> "Mon: "
                    2 -> "Tue: "
                    3 -> "Wed: "
                    4 -> "Thu: "
                    5 -> "Fri: "
                    6 -> "Sat: "
                    7 -> "Sun: "
                    else -> ""
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalSurfaceElevated)
                        .padding(horizontal = RepwiseSpacing.xs, vertical = 2.dp)
                ) {
                    Text(
                        text = "$weekdayText${dayWithEx.day.name}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
            if (planWithDays.days.size > 4) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalSurfaceElevated)
                        .padding(horizontal = RepwiseSpacing.xs, vertical = 2.dp)
                ) {
                    Text(
                        text = "+${planWithDays.days.size - 4}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

        // Actions Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)) {
                // Edit button
                Text(
                    text = "Edit Routine",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(RepwiseLimeMuted)
                        .clickable(onClick = onEdit)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                )

                // Duplicate button
                Text(
                    text = "Duplicate",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CharcoalSurfaceElevated)
                        .clickable(onClick = onDuplicate)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                )

                // Set as Active button if inactive
                if (!isActive) {
                    Text(
                        text = "Set Active",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextHighEmphasis,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CharcoalSurfaceElevated)
                            .clickable(onClick = onSetActive)
                            .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                    )
                }
            }

            // Delete button
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete routine",
                    tint = DangerRed.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
