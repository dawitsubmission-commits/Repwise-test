package com.example.ui.screens.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.history.ExerciseRecordItem
import com.example.domain.history.SessionHistoryItem
import com.example.domain.history.WorkoutHistoryHelper
import com.example.ui.components.EmptyState
import com.example.ui.components.FilterChipRow
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.TestTags
import com.example.util.WeightHelper

@Composable
fun ProgressScreen(
    modifier: Modifier = Modifier,
    onWorkoutClick: (Long) -> Unit = {},
    onExerciseClick: (String) -> Unit = {},
    viewModel: ProgressViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    val tabs = ProgressSubTab.entries
    val selectedIndex = tabs.indexOf(uiState.selectedTab).coerceAtLeast(0)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .testTag(TestTags.SCREEN_PROGRESS),
        contentPadding = PaddingValues(vertical = RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
    ) {
        // Section Header
        item {
            Column(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                SectionHeader(
                    title = "Progress & Records",
                    subtitle = "Workout history, PR tracking, and analytics"
                )
            }
        }

        // Sub-tabs row: History, Records, Charts
        item {
            FilterChipRow(
                items = tabs.map { it.label },
                selectedIndex = selectedIndex,
                onSelected = { index -> viewModel.selectTab(tabs[index]) }
            )
        }

        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(RepwiseSpacing.xxl),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = RepwiseLime)
                }
            }
        } else {
            when (uiState.selectedTab) {
                ProgressSubTab.HISTORY -> {
                    if (!uiState.hasCompletedSessions) {
                        item {
                            EmptyState(
                                title = "No workouts yet",
                                description = "Finish a workout session to view your complete training history, exercise logs, and volume load.",
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = null,
                                        tint = RepwiseLime,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            )
                        }
                    } else {
                        // Grouped by month headers, newest first
                        uiState.historyByMonth.forEach { (monthHeader, sessions) ->
                            item(key = "header_$monthHeader") {
                                Text(
                                    text = monthHeader.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextSecondary,
                                    modifier = Modifier.padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs)
                                )
                            }

                            items(sessions, key = { it.sessionId }) { sessionItem ->
                                Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                                    HistoryWorkoutCard(
                                        item = sessionItem,
                                        onClick = { onWorkoutClick(sessionItem.sessionId) }
                                    )
                                }
                            }
                        }
                    }
                }

                ProgressSubTab.RECORDS -> {
                    if (!uiState.hasRecords) {
                        item {
                            EmptyState(
                                title = "Finish a workout to start setting records.",
                                description = "Personal records are automatically verified from your logged working sets.",
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = RepwiseLime,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            )
                        }
                    } else {
                        items(uiState.records, key = { it.exerciseId }) { recordItem ->
                            Box(modifier = Modifier.padding(horizontal = RepwiseSpacing.md)) {
                                ExerciseRecordCard(
                                    record = recordItem,
                                    onClick = { onExerciseClick(recordItem.exerciseId) }
                                )
                            }
                        }
                    }
                }

                ProgressSubTab.CHARTS -> {
                    chartsTabContent(
                        state = uiState,
                        callbacks = object : ChartsTabCallbacks {
                            override fun onSelectExercise(exerciseId: String) {
                                viewModel.selectExercise(exerciseId)
                            }
                            override fun onSelectRange(range: String) {
                                viewModel.selectRange(range)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryWorkoutCard(
    item: SessionHistoryItem,
    onClick: () -> Unit
) {
    RepwiseCard(onClick = onClick) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.dayName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (item.prCount > 0) {
                        Box(
                            modifier = Modifier
                                .clip(PillShape)
                                .background(RepwiseLime)
                                .padding(horizontal = RepwiseSpacing.sm, vertical = 2.dp)
                        ) {
                            Text(
                                text = "★ ${item.prCount} PR${if (item.prCount > 1) "s" else ""}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                color = RepwiseOnLime
                            )
                        }
                        Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "View Workout Details",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

            Text(
                text = "${item.dateText} • ${item.durationText} • ${item.exerciseCount} exercise${if (item.exerciseCount != 1) "s" else ""}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(PillShape)
                    .background(CharcoalSurfaceElevated)
                    .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Total Volume",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Text(
                    text = WeightHelper.format(item.totalVolumeKg),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime
                )
            }
        }
    }
}

@Composable
private fun ExerciseRecordCard(
    record: ExerciseRecordItem,
    onClick: () -> Unit
) {
    RepwiseCard(onClick = onClick) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = record.exerciseName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "View Exercise Details",
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

            if (record.isBodyweight) {
                // Bodyweight exercise: show best reps and date achieved
                val repsText = record.bestReps?.let { "$it reps" } ?: "0 reps"
                val dateText = record.bestRepsAchievedAt?.let { WorkoutHistoryHelper.formatDate(it) } ?: ""

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalSurfaceElevated)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Best Reps (Bodyweight)",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        if (dateText.isNotBlank()) {
                            Text(
                                text = dateText,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary.copy(alpha = 0.7f)
                            )
                        }
                    }
                    Text(
                        text = repsText,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = RepwiseLime
                    )
                }
            } else {
                // Weighted exercise: show Heaviest Weight and Best Estimated 1RM
                Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)) {
                    record.heaviestWeightKg?.let { weightKg ->
                        val dateText = record.heaviestAchievedAt?.let { WorkoutHistoryHelper.formatDate(it) } ?: ""
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(CharcoalSurfaceElevated)
                                .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Heaviest Weight",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                                if (dateText.isNotBlank()) {
                                    Text(
                                        text = dateText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary.copy(alpha = 0.7f)
                                    )
                                }
                            }
                            Text(
                                text = WeightHelper.format(weightKg),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime
                            )
                        }
                    }

                    record.bestE1rmKg?.let { e1rmKg ->
                        val dateText = record.bestE1rmAchievedAt?.let { WorkoutHistoryHelper.formatDate(it) } ?: ""
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(CharcoalSurfaceElevated)
                                .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Best Estimated 1RM",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                                if (dateText.isNotBlank()) {
                                    Text(
                                        text = dateText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary.copy(alpha = 0.7f)
                                    )
                                }
                            }
                            Text(
                                text = WeightHelper.format(e1rmKg),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime
                            )
                        }
                    }
                }
            }
        }
    }
}
