package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import com.example.ui.components.WorkoutInProgressConflictDialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatTile
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary
import com.example.util.TestTags

@Composable
fun HomeScreen(
    onStartWorkout: (Long) -> Unit,
    onResumeWorkout: (Long) -> Unit = onStartWorkout,
    onNavigateToPlan: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var sessionToDiscard by remember { mutableStateOf<Long?>(null) }
    var pendingConflictStartType by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .testTag(TestTags.SCREEN_HOME),
        contentPadding = PaddingValues(RepwiseSpacing.md),
        verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.lg)
    ) {
        // App Header / Brand Greeting
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = RepwiseSpacing.sm),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "REPWISE",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        ),
                        color = RepwiseLime
                    )
                    Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                    Text(
                        text = "Good morning, Alex",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = TextHighEmphasis
                    )
                }

                // Streak Badge
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(CharcoalSurfaceElevated)
                        .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.xs),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Streak",
                            tint = RepwiseLime,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                        Text(
                            text = "${uiState.stats.streakWeeks}w streak",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                    }
                }
            }
        }

        // Autosave / Session Recovery: Resume Workout Card if IN_PROGRESS session exists
        if (uiState.inProgressSession != null) {
            val inProgress = uiState.inProgressSession!!
            val completedCount = inProgress.exercises.sumOf { it.sets.count { s -> s.completedAt != null } }
            val totalCount = inProgress.exercises.sumOf { it.sets.size }

            item {
                RepwiseCard(
                    modifier = Modifier.testTag("resume_workout_card")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(RepwiseLime)
                                )
                                Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                                Text(
                                    text = "WORKOUT IN PROGRESS",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    ),
                                    color = RepwiseLime
                                )
                            }
                            Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                            Text(
                                text = inProgress.session.dayName,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = TextHighEmphasis
                            )
                            Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                            Text(
                                text = "${inProgress.exercises.size} exercises • $completedCount/$totalCount sets logged",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(RepwiseSpacing.md))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        PrimaryButton(
                            text = "Resume",
                            onClick = { onResumeWorkout(inProgress.session.id) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = RepwiseOnLime
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("resume_workout_button")
                        )

                        SecondaryButton(
                            text = "Discard",
                            onClick = { sessionToDiscard = inProgress.session.id },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("discard_in_progress_button")
                        )
                    }
                }
            }
        }

        // Real "Today's workout" Card (Scheduled, Rest Day, or No Routine Yet)
        item {
            SectionHeader(
                title = "Today's Session",
                subtitle = "Scheduled from your active routine"
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            when (val status = uiState.todayStatus) {
                is TodayWorkoutStatus.Scheduled -> {
                    RepwiseCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = status.dayName,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = TextHighEmphasis
                                )
                                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                                Text(
                                    text = status.routineName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = RepwiseLime
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(RepwiseLimeMuted),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FitnessCenter,
                                    contentDescription = null,
                                    tint = RepwiseLime,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                                Text(
                                    text = "~${status.estimatedMinutes} mins",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.FitnessCenter,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                                Text(
                                    text = "${status.exerciseCount} exercises",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        if (status.exerciseNames.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
                            Text(
                                text = "Planned: " + status.exerciseNames.take(3).joinToString(", ") + if (status.exerciseNames.size > 3) " +${status.exerciseNames.size - 3} more" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1
                            )
                        }

                        Spacer(modifier = Modifier.height(RepwiseSpacing.lg))

                        // Primary Action: Start Workout Button
                        PrimaryButton(
                            text = "Start Workout",
                            onClick = {
                                if (uiState.inProgressSession != null) {
                                    pendingConflictStartType = "SCHEDULED"
                                } else {
                                    viewModel.startScheduledWorkout(onStartWorkout)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag(TestTags.START_WORKOUT_BUTTON),
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = RepwiseOnLime
                                )
                            }
                        )

                        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                        SecondaryButton(
                            text = "+ Start Empty Workout",
                            onClick = {
                                if (uiState.inProgressSession != null) {
                                    pendingConflictStartType = "EMPTY"
                                } else {
                                    viewModel.startEmptyWorkout(onStartWorkout)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("start_empty_workout_button")
                        )

                        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                        SecondaryButton(
                            text = "View Workout Routine",
                            onClick = onNavigateToPlan,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                is TodayWorkoutStatus.RestDay -> {
                    RepwiseCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Rest & Recovery",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = TextHighEmphasis
                                )
                                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                                Text(
                                    text = "No training session scheduled for today",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(CharcoalSurfaceElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bedtime,
                                    contentDescription = null,
                                    tint = RepwiseLime,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

                        Text(
                            text = "Focus on mobility, quality sleep, and nutrition to rebuild muscle tissue.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(RepwiseSpacing.md))

                        SecondaryButton(
                            text = "View Routine Schedule",
                            onClick = onNavigateToPlan,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                is TodayWorkoutStatus.NoRoutineYet -> {
                    RepwiseCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "No Active Routine",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = TextHighEmphasis
                                )
                                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))
                                Text(
                                    text = "Choose a template or build your own split",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(CharcoalSurfaceElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = RepwiseLime,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(RepwiseSpacing.lg))

                        PrimaryButton(
                            text = "Choose Routine / Create Plan",
                            onClick = onNavigateToPlan,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Stats Overview Section
        item {
            SectionHeader(
                title = "Weekly Volume",
                subtitle = "Consistency and workload"
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            if (uiState.stats.totalCompletedSessions == 0) {
                RepwiseCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(RepwiseSpacing.sm),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No workouts yet",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextHighEmphasis
                        )
                        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                        Text(
                            text = "Complete your first training session to start tracking volume, streaks, and personal records.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        StatTile(
                            label = "This Week",
                            value = "${uiState.stats.sessionsThisWeek} sessions",
                            change = if (uiState.stats.sessionsThisWeek > 0) "Current week" else "No sessions yet",
                            isPositive = uiState.stats.sessionsThisWeek > 0,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = "Total Volume",
                            value = com.example.util.WeightHelper.format(uiState.stats.totalVolumeKg),
                            change = "Workload lifted",
                            isPositive = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                    ) {
                        StatTile(
                            label = "Avg Duration",
                            value = "${uiState.stats.avgDurationMinutes} min",
                            change = "Per session",
                            isPositive = true,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = "PRs Hit",
                            value = "${uiState.stats.prsLast30Days} PRs",
                            change = "Last 30 days",
                            isPositive = uiState.stats.prsLast30Days > 0,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    // Discard in-progress workout confirm dialog
    val toDiscard = sessionToDiscard
    if (toDiscard != null) {
        AlertDialog(
            onDismissRequest = { sessionToDiscard = null },
            title = { Text("Discard Workout?") },
            text = { Text("Are you sure you want to discard this in-progress workout? All logged sets will be discarded.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.discardSession(toDiscard)
                        sessionToDiscard = null
                    }
                ) {
                    Text("Discard", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionToDiscard = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis,
            textContentColor = TextSecondary
        )
    }

    // Conflict dialog when starting a second workout while one is IN_PROGRESS
    val conflictType = pendingConflictStartType
    val inProgress = uiState.inProgressSession
    if (conflictType != null && inProgress != null) {
        WorkoutInProgressConflictDialog(
            onDismissRequest = { pendingConflictStartType = null },
            onResume = {
                val activeId = inProgress.session.id
                pendingConflictStartType = null
                onResumeWorkout(activeId)
            },
            onDiscardConfirmed = {
                val activeId = inProgress.session.id
                val startType = conflictType
                pendingConflictStartType = null
                viewModel.discardSession(activeId)
                if (startType == "SCHEDULED") {
                    viewModel.startScheduledWorkout(onStartWorkout)
                } else if (startType == "EMPTY") {
                    viewModel.startEmptyWorkout(onStartWorkout)
                }
            },
            sessionName = inProgress.session.dayName
        )
    }
}
