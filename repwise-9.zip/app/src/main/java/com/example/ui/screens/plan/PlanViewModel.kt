package com.example.ui.screens.plan

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.PlanDayEntity
import com.example.data.local.entities.PlanDayWithExercises
import com.example.data.local.entities.WorkoutPlanEntity
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.models.CatalogExercise
import com.example.domain.repository.RepwiseRepository
import com.example.domain.templates.TemplateRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PlanScreenUiState(
    val plans: List<WorkoutPlanWithDays> = emptyList(),
    val activePlan: WorkoutPlanWithDays? = null,
    val catalogMap: Map<String, CatalogExercise> = emptyMap(),
    val isLoading: Boolean = true
)

class PlanViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _isLoading = MutableStateFlow(true)

    init {
        viewModelScope.launch {
            repository.ensureCatalogInitialized()
            _isLoading.value = false
        }
    }

    val uiState: StateFlow<PlanScreenUiState> = combine(
        repository.getAllWorkoutPlans(),
        repository.getActiveWorkoutPlan(),
        repository.getCatalogExercises(),
        _isLoading
    ) { allPlans, activePlan, catalogList, loading ->
        val catalogMap = catalogList.associateBy { it.id }

        PlanScreenUiState(
            plans = allPlans,
            activePlan = activePlan,
            catalogMap = catalogMap,
            isLoading = loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PlanScreenUiState()
    )

    fun setActivePlan(planId: Long) {
        viewModelScope.launch {
            repository.setActiveWorkoutPlan(planId)
        }
    }

    fun duplicatePlan(planId: Long, onDuplicated: ((Long) -> Unit)? = null) {
        viewModelScope.launch {
            val newId = repository.duplicateWorkoutPlan(planId)
            onDuplicated?.invoke(newId)
        }
    }

    fun deletePlan(planId: Long) {
        viewModelScope.launch {
            repository.deleteWorkoutPlan(planId)
        }
    }

    fun createNewPlan(name: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val newPlan = WorkoutPlanWithDays(
                plan = WorkoutPlanEntity(
                    id = 0,
                    name = name.ifBlank { "Custom Routine" },
                    isActive = false,
                    createdAt = System.currentTimeMillis()
                ),
                days = listOf(
                    PlanDayWithExercises(
                        day = PlanDayEntity(id = 0, planId = 0, name = "Day 1", position = 0, weekday = 1),
                        exercises = emptyList()
                    )
                )
            )
            val id = repository.saveWorkoutPlan(newPlan)
            onCreated(id)
        }
    }

    fun useTemplate(templateKey: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val templateSpec = TemplateRepository.getTemplateByKey(templateKey) ?: return@launch
            val planToCreate = TemplateRepository.createPlanFromTemplate(
                spec = templateSpec,
                catalogLookup = uiState.value.catalogMap,
                isActive = uiState.value.plans.isEmpty()
            )
            val newId = repository.saveWorkoutPlan(planToCreate)
            onCreated(newId)
        }
    }
}
