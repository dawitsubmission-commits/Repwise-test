package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider

private val RepwiseDarkColorScheme = darkColorScheme(
    primary = RepwiseLime,
    onPrimary = RepwiseOnLime,
    primaryContainer = RepwiseLimeMuted,
    onPrimaryContainer = RepwiseLime,
    secondary = CharcoalSurfaceElevated,
    onSecondary = TextHighEmphasis,
    secondaryContainer = CharcoalSurfaceVariant,
    onSecondaryContainer = TextMediumEmphasis,
    tertiary = RepwiseLime,
    onTertiary = RepwiseOnLime,
    background = CharcoalBackground,
    onBackground = TextHighEmphasis,
    surface = CharcoalSurface,
    onSurface = TextHighEmphasis,
    surfaceVariant = CharcoalSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CharcoalBorder,
    outlineVariant = CharcoalBorderSubtle,
    error = DangerRed,
    onError = TextHighEmphasis
)

object RepwiseTheme {
    val spacing: RepwiseSpacingTokens
        @Composable
        get() = LocalRepwiseSpacing.current
}

@Composable
fun RepwiseTheme(
    content: @Composable () -> Unit
) {
    val spacingTokens = RepwiseSpacingTokens()

    CompositionLocalProvider(
        LocalRepwiseSpacing provides spacingTokens
    ) {
        MaterialTheme(
            colorScheme = RepwiseDarkColorScheme,
            typography = RepwiseTypography,
            shapes = RepwiseShapes,
            content = content
        )
    }
}
