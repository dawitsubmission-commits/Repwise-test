package com.example.ui.screens.plan

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.theme.RepwiseShapes
import com.example.ui.components.WorkoutInProgressConflictDialog
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.alternatives.AlternativesFinder
import com.example.domain.models.CatalogExercise
import com.example.domain.normalization.Normalizer
import com.example.ui.components.EmptyState
import com.example.ui.components.ExerciseStaticThumbnail
import com.example.ui.components.FilterChipRow
import com.example.ui.components.PrimaryButton
import com.example.ui.components.RepwiseCard
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CharcoalBackground
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalBorderSubtle
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.PillShape
import com.example.ui.theme.RepwiseLime
import com.example.ui.theme.RepwiseLimeMuted
import com.example.ui.theme.RepwiseOnLime
import com.example.ui.theme.RepwiseSpacing
import com.example.ui.theme.TextHighEmphasis
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutineEditorScreen(
    planId: Long,
    onBack: () -> Unit,
    onStartWorkout: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier,
    viewModel: RoutineEditorViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    BackHandler {
        onBack()
    }

    LaunchedEffect(planId) {
        viewModel.loadPlan(planId)
    }

    // Dialog & Sheet States
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showRenameDayDialog by remember { mutableStateOf(false) }
    var renameDayText by remember { mutableStateOf("") }
    var showAddExerciseSheet by remember { mutableStateOf(false) }
    var replacingExerciseIndex by remember { mutableStateOf<Int?>(null) }
    var editingExerciseParamsIndex by remember { mutableStateOf<Int?>(null) }
    var conflictInProgressSessionId by remember { mutableStateOf<Long?>(null) }
    var pendingStartDayIndex by remember { mutableStateOf<Int?>(null) }

    val currentDay = uiState.days.getOrNull(uiState.selectedDayIndex)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBackground)
            .padding(WindowInsets.statusBars.asPaddingValues())
            .testTag("screen_routine_editor")
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = RepwiseSpacing.md, vertical = RepwiseSpacing.sm),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(CharcoalSurfaceElevated)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextHighEmphasis
                    )
                }

                Spacer(modifier = Modifier.width(RepwiseSpacing.sm))

                Text(
                    text = "Edit Routine",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )
            }

            // Delete Routine Button
            IconButton(
                onClick = { showDeleteConfirmDialog = true },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(CharcoalSurfaceElevated)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete routine",
                    tint = DangerRed
                )
            }
        }

        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(RepwiseSpacing.xxl),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RepwiseLime)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(RepwiseSpacing.md),
                verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.md)
            ) {
                // Routine Name Field
                item {
                    RepwiseCard {
                        Text(
                            text = "ROUTINE NAME",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(RepwiseSpacing.xs))
                        OutlinedTextField(
                            value = uiState.planName,
                            onValueChange = { viewModel.onPlanNameChange(it) },
                            singleLine = true,
                            shape = RepwiseShapes.medium,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CharcoalSurfaceElevated,
                                unfocusedContainerColor = CharcoalSurfaceElevated,
                                focusedBorderColor = RepwiseLime,
                                unfocusedBorderColor = CharcoalBorderSubtle,
                                focusedTextColor = TextHighEmphasis,
                                unfocusedTextColor = TextHighEmphasis,
                                cursorColor = RepwiseLime
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Days Row / Selector
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "WORKOUT DAYS (${uiState.days.size})",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextSecondary
                        )

                        TextButton(onClick = { viewModel.addDay() }) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = RepwiseLime,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(RepwiseSpacing.xxs))
                            Text(
                                text = "Add Day",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = RepwiseLime
                            )
                        }
                    }

                    FilterChipRow(
                        items = uiState.days.map { it.name },
                        selectedIndex = uiState.selectedDayIndex,
                        onSelected = { viewModel.selectDay(it) }
                    )
                }

                // Active Day Settings (Rename, Weekday Assignment, Remove Day)
                if (currentDay != null) {
                    item {
                        RepwiseCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = currentDay.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = TextHighEmphasis
                                    )
                                    IconButton(
                                        onClick = {
                                            renameDayText = currentDay.name
                                            showRenameDayDialog = true
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Rename day",
                                            tint = RepwiseLime,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (onStartWorkout != null && currentDay.exercises.isNotEmpty()) {
                                        Text(
                                            text = "Start Workout",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = RepwiseOnLime,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(RepwiseLime)
                                                .clickable {
                                                    viewModel.startDayWorkout(
                                                        dayIndex = uiState.selectedDayIndex,
                                                        onStarted = { sid -> onStartWorkout(sid) },
                                                        onConflict = { inProgressId ->
                                                            conflictInProgressSessionId = inProgressId
                                                            pendingStartDayIndex = uiState.selectedDayIndex
                                                        }
                                                    )
                                                }
                                                .padding(horizontal = RepwiseSpacing.sm, vertical = 6.dp)
                                                .testTag("start_day_workout_button")
                                        )
                                        Spacer(modifier = Modifier.width(RepwiseSpacing.xs))
                                    }

                                    if (uiState.days.size > 1) {
                                        TextButton(onClick = { viewModel.removeDay(uiState.selectedDayIndex) }) {
                                            Text(
                                                text = "Remove Day",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = DangerRed
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                            // Weekday Assignment Selector
                            Text(
                                text = "SCHEDULE ON WEEKDAY",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

                            val weekdayOptions = listOf("Rest / Floating", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                            val selectedWeekdayIdx = currentDay.weekday ?: 0

                            FilterChipRow(
                                items = weekdayOptions,
                                selectedIndex = selectedWeekdayIdx,
                                onSelected = { idx ->
                                    val newWeekday = if (idx == 0) null else idx
                                    viewModel.assignWeekday(uiState.selectedDayIndex, newWeekday)
                                }
                            )
                        }
                    }

                    // Exercises in Active Day
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "EXERCISES (${currentDay.exercises.size})",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = TextSecondary
                            )

                            TextButton(onClick = { showAddExerciseSheet = true }) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = RepwiseLime,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(RepwiseSpacing.xxs))
                                Text(
                                    text = "Add Exercise",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = RepwiseLime
                                )
                            }
                        }
                    }

                    if (currentDay.exercises.isEmpty()) {
                        item {
                            EmptyState(
                                title = "No Exercises in this Day",
                                description = "Add exercises to build out your routine session.",
                                actionText = "Add Exercise",
                                onActionClick = { showAddExerciseSheet = true }
                            )
                        }
                    } else {
                        itemsIndexed(currentDay.exercises, key = { _, ex -> ex.id.toString() + "_" + ex.exerciseId }) { exIndex, ex ->
                            val catalogEx = uiState.catalogMap[ex.exerciseId]
                            EditableExerciseRow(
                                exercise = ex,
                                catalogExercise = catalogEx,
                                canMoveUp = exIndex > 0,
                                canMoveDown = exIndex < currentDay.exercises.size - 1,
                                onMoveUp = { viewModel.moveExerciseUp(uiState.selectedDayIndex, exIndex) },
                                onMoveDown = { viewModel.moveExerciseDown(uiState.selectedDayIndex, exIndex) },
                                onReplace = { replacingExerciseIndex = exIndex },
                                onEditParams = { editingExerciseParamsIndex = exIndex },
                                onDelete = { viewModel.removeExercise(uiState.selectedDayIndex, exIndex) }
                            )
                        }
                    }
                }

                // Save Routine Button
                item {
                    Spacer(modifier = Modifier.height(RepwiseSpacing.sm))
                    PrimaryButton(
                        text = "Save Routine Changes",
                        onClick = {
                            viewModel.saveRoutine(onSaved = onBack)
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }

    // 1. Delete Confirm Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete Routine?") },
            text = { Text("Are you sure you want to delete '${uiState.planName}'? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.deleteRoutine(onDeleted = onBack)
                    }
                ) {
                    Text("Delete", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis,
            textContentColor = TextSecondary
        )
    }

    // 2. Rename Day Dialog
    if (showRenameDayDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDayDialog = false },
            title = { Text("Rename Day") },
            text = {
                OutlinedTextField(
                    value = renameDayText,
                    onValueChange = { renameDayText = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RepwiseLime,
                        focusedTextColor = TextHighEmphasis,
                        unfocusedTextColor = TextHighEmphasis
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.renameDay(uiState.selectedDayIndex, renameDayText)
                        showRenameDayDialog = false
                    }
                ) {
                    Text("Save", color = RepwiseLime, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDayDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis
        )
    }

    // 3. Edit Sets/Reps/Rest Dialog
    val editingIndex = editingExerciseParamsIndex
    if (editingIndex != null && currentDay != null && editingIndex in currentDay.exercises.indices) {
        val targetEx = currentDay.exercises[editingIndex]
        val catEx = uiState.catalogMap[targetEx.exerciseId]
        var setsText by remember { mutableStateOf(targetEx.sets.toString()) }
        var repMinText by remember { mutableStateOf(targetEx.repMin.toString()) }
        var repMaxText by remember { mutableStateOf(targetEx.repMax.toString()) }
        var restText by remember { mutableStateOf(targetEx.restSeconds.toString()) }
        var noteText by remember { mutableStateOf(targetEx.note ?: "") }

        AlertDialog(
            onDismissRequest = { editingExerciseParamsIndex = null },
            title = { Text(catEx?.name?.replaceFirstChar { it.uppercase() } ?: "Exercise Parameters") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                        OutlinedTextField(
                            value = setsText,
                            onValueChange = { setsText = it },
                            label = { Text("Sets") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = restText,
                            onValueChange = { restText = it },
                            label = { Text("Rest (s)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)) {
                        OutlinedTextField(
                            value = repMinText,
                            onValueChange = { repMinText = it },
                            label = { Text("Rep Min") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = repMaxText,
                            onValueChange = { repMaxText = it },
                            label = { Text("Rep Max") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("Coaching Note (optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val s = setsText.toIntOrNull() ?: targetEx.sets
                        val rMin = repMinText.toIntOrNull() ?: targetEx.repMin
                        val rMax = repMaxText.toIntOrNull() ?: targetEx.repMax
                        val rRest = restText.toIntOrNull() ?: targetEx.restSeconds
                        viewModel.updateExerciseParams(
                            dayIndex = uiState.selectedDayIndex,
                            exIndex = editingIndex,
                            sets = s,
                            repMin = rMin,
                            repMax = rMax,
                            restSeconds = rRest,
                            note = noteText.ifBlank { null }
                        )
                        editingExerciseParamsIndex = null
                    }
                ) {
                    Text("Apply", color = RepwiseLime, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingExerciseParamsIndex = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurface,
            titleContentColor = TextHighEmphasis
        )
    }

    // 4. Replace Exercise BottomSheet (Alternatives Finder)
    val repIdx = replacingExerciseIndex
    if (repIdx != null && currentDay != null && repIdx in currentDay.exercises.indices) {
        val targetEx = currentDay.exercises[repIdx]
        val currentCatalogEx = uiState.catalogMap[targetEx.exerciseId]

        ModalBottomSheet(
            onDismissRequest = { replacingExerciseIndex = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CharcoalSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(RepwiseSpacing.md)
            ) {
                SectionHeader(
                    title = "Replace Exercise",
                    subtitle = "Alternatives with same movement pattern & target"
                )

                Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                if (currentCatalogEx == null) {
                    Text("Exercise details not available.", color = TextSecondary)
                } else {
                    val alternatives = remember(currentCatalogEx, uiState.allCatalogExercises) {
                        AlternativesFinder.findAlternatives(currentCatalogEx, uiState.allCatalogExercises)
                    }

                    if (alternatives.isEmpty()) {
                        Box(modifier = Modifier.padding(vertical = RepwiseSpacing.lg)) {
                            EmptyState(
                                title = "No Direct Alternatives Found",
                                description = "No matching exercise found with target '${currentCatalogEx.target}' and movement '${currentCatalogEx.movementPattern ?: "none"}'.",
                                actionText = "Keep Current",
                                onActionClick = { replacingExerciseIndex = null }
                            )
                        }
                    } else {
                        Text(
                            text = "${alternatives.size} alternatives ranked by shared muscles:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = RepwiseLime
                        )

                        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp),
                            verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.sm)
                        ) {
                            items(alternatives, key = { it.id }) { alt ->
                                RepwiseCard(
                                    onClick = {
                                        viewModel.replaceExercise(uiState.selectedDayIndex, repIdx, alt.id)
                                        replacingExerciseIndex = null
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        ExerciseStaticThumbnail(frame00Path = alt.frame00Path, size = 48.dp)
                                        Spacer(modifier = Modifier.width(RepwiseSpacing.md))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = alt.name.replaceFirstChar { it.uppercase() },
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = TextHighEmphasis
                                            )
                                            Text(
                                                text = "${alt.equipment} • ${alt.target}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextSecondary
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.SwapHoriz,
                                            contentDescription = "Select replacement",
                                            tint = RepwiseLime
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 5. Add Exercise Picker Sheet (reuses library search & filters)
    if (showAddExerciseSheet) {
        ExercisePickerBottomSheet(
            catalogExercises = uiState.allCatalogExercises,
            onDismiss = { showAddExerciseSheet = false },
            onExerciseSelected = { selectedId ->
                viewModel.addExerciseToDay(uiState.selectedDayIndex, selectedId)
                showAddExerciseSheet = false
            }
        )
    }

    val conflictSessionId = conflictInProgressSessionId
    if (conflictSessionId != null) {
        WorkoutInProgressConflictDialog(
            onDismissRequest = {
                conflictInProgressSessionId = null
                pendingStartDayIndex = null
            },
            onResume = {
                val activeId = conflictSessionId
                conflictInProgressSessionId = null
                pendingStartDayIndex = null
                if (onStartWorkout != null) {
                    onStartWorkout(activeId)
                }
            },
            onDiscardConfirmed = {
                val activeId = conflictSessionId
                val dayIdx = pendingStartDayIndex ?: uiState.selectedDayIndex
                conflictInProgressSessionId = null
                pendingStartDayIndex = null
                if (onStartWorkout != null) {
                    viewModel.discardInProgressAndStartDay(activeId, dayIdx, onStartWorkout)
                }
            }
        )
    }
}

/**
 * Exercise row within a plan day editor.
 */
@Composable
private fun EditableExerciseRow(
    exercise: EditableExercise,
    catalogExercise: CatalogExercise?,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onReplace: () -> Unit,
    onEditParams: () -> Unit,
    onDelete: () -> Unit
) {
    RepwiseCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ExerciseStaticThumbnail(frame00Path = catalogExercise?.frame00Path, size = 52.dp)

            Spacer(modifier = Modifier.width(RepwiseSpacing.md))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = catalogExercise?.name?.replaceFirstChar { it.uppercase() } ?: "Exercise ${exercise.exerciseId}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis
                )

                Spacer(modifier = Modifier.height(RepwiseSpacing.xxs))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)
                ) {
                    Text(
                        text = "${exercise.sets} sets × ${exercise.repMin}-${exercise.repMax} reps",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = RepwiseLime
                    )
                    Text(text = "•", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(
                        text = "${exercise.restSeconds}s rest",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                if (!exercise.note.isNullOrBlank()) {
                    Text(
                        text = "Note: ${exercise.note}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary.copy(alpha = 0.8f)
                    )
                }
            }

            // Up/Down reorder buttons
            Column {
                IconButton(
                    onClick = onMoveUp,
                    enabled = canMoveUp,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "Move up",
                        tint = if (canMoveUp) TextHighEmphasis else TextSecondary.copy(alpha = 0.3f),
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onMoveDown,
                    enabled = canMoveDown,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Move down",
                        tint = if (canMoveDown) TextHighEmphasis else TextSecondary.copy(alpha = 0.3f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

        // Actions: Edit parameters, Replace, Remove
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)) {
                Text(
                    text = "Edit Sets/Reps",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = RepwiseLime,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(RepwiseLimeMuted)
                        .clickable(onClick = onEditParams)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                )

                Text(
                    text = "Replace",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextHighEmphasis,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CharcoalSurfaceElevated)
                        .clickable(onClick = onReplace)
                        .padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xs)
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete exercise",
                    tint = DangerRed.copy(alpha = 0.8f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * Bottom sheet picker allowing user to select an exercise from the library with search and filters.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExercisePickerBottomSheet(
    catalogExercises: List<CatalogExercise>,
    onDismiss: () -> Unit,
    onExerciseSelected: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedMuscle by remember { mutableStateOf("All") }
    var selectedEquipment by remember { mutableStateOf("All") }

    val muscleOptions = Normalizer.getAllFilterMuscles()
    val equipOptions = Normalizer.getAllFilterEquipments()

    val filtered = remember(catalogExercises, searchQuery, selectedMuscle, selectedEquipment) {
        catalogExercises.filter { ex ->
            val matchQuery = searchQuery.isBlank() || ex.name.contains(searchQuery, ignoreCase = true)
            val matchMuscle = selectedMuscle == "All" ||
                ex.target.equals(selectedMuscle, ignoreCase = true) ||
                ex.secondaryMuscles.any { it.equals(selectedMuscle, ignoreCase = true) }
            val matchEquip = selectedEquipment == "All" || ex.equipment.equals(selectedEquipment, ignoreCase = true)
            matchQuery && matchMuscle && matchEquip
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = CharcoalSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(RepwiseSpacing.md)
        ) {
            SectionHeader(
                title = "Select Exercise",
                subtitle = "Choose from 44 exercises to add to this day"
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.sm))

            // Search input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by name...", color = TextSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RepwiseLime) },
                singleLine = true,
                shape = PillShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CharcoalSurfaceElevated,
                    unfocusedContainerColor = CharcoalSurfaceElevated,
                    focusedBorderColor = RepwiseLime,
                    focusedTextColor = TextHighEmphasis,
                    unfocusedTextColor = TextHighEmphasis
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

            // Muscle filter
            FilterChipRow(
                items = muscleOptions.map { it.replaceFirstChar { c -> c.uppercase() } },
                selectedIndex = muscleOptions.indexOf(selectedMuscle).coerceAtLeast(0),
                onSelected = { selectedMuscle = muscleOptions[it] }
            )

            Spacer(modifier = Modifier.height(RepwiseSpacing.xs))

            // Results count
            Text(
                text = "${filtered.size} exercises found",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = RepwiseSpacing.sm, vertical = RepwiseSpacing.xxs)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp),
                verticalArrangement = Arrangement.spacedBy(RepwiseSpacing.xs)
            ) {
                items(filtered, key = { it.id }) { ex ->
                    RepwiseCard(onClick = { onExerciseSelected(ex.id) }) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ExerciseStaticThumbnail(frame00Path = ex.frame00Path, size = 48.dp)
                            Spacer(modifier = Modifier.width(RepwiseSpacing.md))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ex.name.replaceFirstChar { it.uppercase() },
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = TextHighEmphasis
                                )
                                Text(
                                    text = "${ex.target} • ${ex.equipment}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add",
                                tint = RepwiseLime
                            )
                        }
                    }
                }
            }
        }
    }
}
