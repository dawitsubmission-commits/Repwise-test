package com.example.ui.screens.detail

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.data.repository.RepwiseRepositoryImpl
import com.example.domain.models.CatalogExercise
import com.example.domain.repository.RepwiseRepository
import com.example.domain.templates.TemplateRepository
import com.example.domain.history.ExerciseHistorySession
import com.example.domain.history.WorkoutHistoryHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class ExerciseDetailUiState(
    val exercise: CatalogExercise? = null,
    val isLoading: Boolean = true,
    val speedMultiplier: Float = 0.5f,
    val allPlans: List<WorkoutPlanWithDays> = emptyList(),
    val addedNotificationMessage: String? = null,
    val exerciseHistory: List<ExerciseHistorySession> = emptyList()
)

class ExerciseDetailViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository: RepwiseRepository = RepwiseRepositoryImpl(application)

    private val _uiState = MutableStateFlow(ExerciseDetailUiState())
    val uiState: StateFlow<ExerciseDetailUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllWorkoutPlans().collect { plans ->
                _uiState.value = _uiState.value.copy(allPlans = plans)
            }
        }
    }

    fun loadExercise(exerciseId: String) {
        viewModelScope.launch {
            combine(
                repository.getCatalogExerciseById(exerciseId),
                repository.getCompletedSessions()
            ) { ex, completedSessions ->
                val history = WorkoutHistoryHelper.getExerciseHistory(exerciseId, completedSessions)
                _uiState.value.copy(
                    exercise = ex,
                    exerciseHistory = history,
                    isLoading = false
                )
            }.collect { updated ->
                _uiState.value = updated
            }
        }
    }

    fun setSpeedMultiplier(speed: Float) {
        _uiState.value = _uiState.value.copy(speedMultiplier = speed)
    }

    fun addExerciseToRoutineDay(dayId: Long, routineName: String, dayName: String) {
        val ex = _uiState.value.exercise ?: return
        viewModelScope.launch {
            val (sets, reps, rest) = TemplateRepository.classifyDefaults(ex)
            repository.addExerciseToPlanDay(
                dayId = dayId,
                exerciseId = ex.id,
                sets = sets,
                repMin = reps.first,
                repMax = reps.second,
                restSeconds = rest
            )
            _uiState.value = _uiState.value.copy(
                addedNotificationMessage = "Added to $routineName ($dayName)!"
            )
        }
    }

    fun dismissNotification() {
        _uiState.value = _uiState.value.copy(addedNotificationMessage = null)
    }
}
