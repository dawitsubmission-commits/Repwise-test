package com.example.util

import kotlin.math.roundToInt

/**
 * Pure Kotlin helper for height conversions and formatting.
 * Database ALWAYS stores height in centimeters (cm).
 */
object HeightHelper {
    private const val CM_PER_INCH = 2.54

    fun toCm(feet: Int, inches: Int): Double {
        val totalInches = (feet * 12) + inches
        return totalInches * CM_PER_INCH
    }

    fun fromCmToFeetAndInches(cm: Double): Pair<Int, Int> {
        val totalInches = (cm / CM_PER_INCH).roundToInt()
        val feet = totalInches / 12
        val inches = totalInches % 12
        return Pair(feet, inches)
    }

    fun formatHeight(cm: Double, isImperial: Boolean): String {
        return if (isImperial) {
            val (feet, inches) = fromCmToFeetAndInches(cm)
            "${feet}' ${inches}\""
        } else {
            "${cm.roundToInt()} cm"
        }
    }
}
