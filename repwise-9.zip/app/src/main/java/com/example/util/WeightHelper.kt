package com.example.util

import java.util.Locale

enum class WeightUnit(val label: String, val suffix: String) {
    KG("Kilograms", "kg"),
    LBS("Pounds", "lbs")
}

/**
 * Single conversion helper for all weight formatting and conversions in REPWISE.
 * Stored values in Room are ALWAYS in kilograms (kg).
 * Supports conversion to imperial (lbs) and flexible display.
 */
object WeightHelper {
    var activeUnit: WeightUnit = WeightUnit.KG

    private const val KG_TO_LBS_MULTIPLIER = 2.20462262185

    /**
     * Formats a stored weight in kg according to the active (or specified) unit.
     */
    fun format(
        weightKg: Double,
        unit: WeightUnit = activeUnit,
        includeUnit: Boolean = true
    ): String {
        val converted = when (unit) {
            WeightUnit.KG -> weightKg
            WeightUnit.LBS -> weightKg * KG_TO_LBS_MULTIPLIER
        }

        val formattedValue = if (converted % 1.0 == 0.0) {
            String.format(Locale.US, "%.0f", converted)
        } else {
            String.format(Locale.US, "%.1f", converted)
        }

        return if (includeUnit) "$formattedValue ${unit.suffix}" else formattedValue
    }

    /**
     * Converts a user input value in the given unit to kilograms for database storage.
     */
    fun toKg(value: Double, unit: WeightUnit = activeUnit): Double {
        return when (unit) {
            WeightUnit.KG -> value
            WeightUnit.LBS -> value / KG_TO_LBS_MULTIPLIER
        }
    }

    /**
     * Converts kilograms to the target unit value.
     */
    fun fromKg(weightKg: Double, targetUnit: WeightUnit = activeUnit): Double {
        return when (targetUnit) {
            WeightUnit.KG -> weightKg
            WeightUnit.LBS -> weightKg * KG_TO_LBS_MULTIPLIER
        }
    }
}
