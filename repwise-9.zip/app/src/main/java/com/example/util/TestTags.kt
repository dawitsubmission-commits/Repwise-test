package com.example.util

object TestTags {
    // Navigation
    const val BOTTOM_NAV_BAR = "bottom_nav_bar"
    const val NAV_HOME = "nav_home"
    const val NAV_PLAN = "nav_plan"
    const val NAV_LIBRARY = "nav_library"
    const val NAV_PROGRESS = "nav_progress"
    const val NAV_PROFILE = "nav_profile"

    // Buttons
    const val PRIMARY_BUTTON = "primary_button"
    const val SECONDARY_BUTTON = "secondary_button"
    const val START_WORKOUT_BUTTON = "start_workout_button"
    const val FINISH_WORKOUT_BUTTON = "finish_workout_button"
    const val CANCEL_WORKOUT_BUTTON = "cancel_workout_button"

    // Components
    const val REPEWISE_CARD = "repwise_card"
    const val SECTION_HEADER = "section_header"
    const val STAT_TILE = "stat_tile"
    const val FILTER_CHIP_ROW = "filter_chip_row"
    const val EMPTY_STATE = "empty_state"

    // Screens
    const val SCREEN_HOME = "screen_home"
    const val SCREEN_PLAN = "screen_plan"
    const val SCREEN_LIBRARY = "screen_library"
    const val SCREEN_PROGRESS = "screen_progress"
    const val SCREEN_PROFILE = "screen_profile"
    const val SCREEN_TRAIN = "screen_train"
}
