package com.example.util

import java.util.Locale

object Formatters {
    fun formatSecondsToTime(totalSeconds: Long): String {
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    fun formatWeight(weightKg: Double): String {
        return if (weightKg % 1.0 == 0.0) {
            "${weightKg.toInt()} kg"
        } else {
            String.format(Locale.US, "%.1f kg", weightKg)
        }
    }
}
