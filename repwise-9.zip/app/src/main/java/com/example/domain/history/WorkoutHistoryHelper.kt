package com.example.domain.history

import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.PersonalRecordType
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.domain.Epley
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class SessionHistoryItem(
    val sessionId: Long,
    val dayName: String,
    val dateText: String,
    val durationText: String,
    val exerciseCount: Int,
    val totalVolumeKg: Double,
    val prCount: Int,
    val timestamp: Long
)

data class ExerciseHistorySession(
    val sessionId: Long,
    val sessionDayName: String,
    val dateText: String,
    val timestamp: Long,
    val sets: List<SetLogEntity>,
    val bestSet: SetLogEntity?
)

data class ExerciseRecordItem(
    val exerciseId: String,
    val exerciseName: String,
    val heaviestWeightKg: Double?,
    val heaviestAchievedAt: Long?,
    val bestE1rmKg: Double?,
    val bestE1rmAchievedAt: Long?,
    val bestReps: Int?,
    val bestRepsAchievedAt: Long?,
    val mostRecentAchievedAt: Long,
    val isBodyweight: Boolean
)

object WorkoutHistoryHelper {

    private val MONTH_YEAR_FORMATTER = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)
    private val SHORT_DATE_FORMATTER = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.US)

    /**
     * Filters list to COMPLETED sessions only.
     * Excludes DISCARDED and IN_PROGRESS sessions.
     * Sorts newest first.
     */
    fun filterCompletedSessions(sessions: List<WorkoutSessionWithExercises>): List<WorkoutSessionWithExercises> {
        return sessions
            .filter { it.session.status == WorkoutSessionStatus.COMPLETED }
            .sortedByDescending { it.session.endedAt ?: it.session.startedAt }
    }

    /**
     * Calculates total volume in kg for a workout session:
     * - Only COMPLETED sets (completedAt != null)
     * - Excludes warm-ups (isWarmup == false)
     * - Excludes bodyweight sets (weightKg <= 0.0)
     */
    fun calculateTotalVolume(session: WorkoutSessionWithExercises): Double {
        var volume = 0.0
        for (exercise in session.exercises) {
            for (set in exercise.sets) {
                if (set.completedAt != null && !set.isWarmup && set.reps > 0 && set.weightKg > 0.0) {
                    volume += (set.weightKg * set.reps)
                }
            }
        }
        return volume
    }

    /**
     * Finds the best set among sets for an exercise in a session:
     * - Only completed, non-warmup sets with reps > 0 are considered.
     * - For weighted sets (weightKg > 0.0):
     *     Best set is the one with the highest estimated 1RM (Epley formula: weightKg * (1 + reps / 30.0)).
     *     Ties broken by higher weight, then higher reps.
     * - For bodyweight exercises (all valid sets have weightKg <= 0.0):
     *     Best set is the one with the highest reps.
     */
    fun calculateBestSet(sets: List<SetLogEntity>): SetLogEntity? {
        val validSets = sets.filter { it.completedAt != null && !it.isWarmup && it.reps > 0 }
        if (validSets.isEmpty()) return null

        val weightedSets = validSets.filter { it.weightKg > 0.0 }
        return if (weightedSets.isNotEmpty()) {
            weightedSets.maxWithOrNull(
                compareBy<SetLogEntity> { set ->
                    Epley.calculate1RM(set.weightKg, set.reps)
                        ?: (set.weightKg * (1.0 + set.reps / 30.0))
                }.thenBy { it.weightKg }
                    .thenBy { it.reps }
            )
        } else {
            validSets.maxByOrNull { it.reps }
        }
    }

    /**
     * Counts the PRs set in this workout session by checking which PRs
     * correspond to setLogIds in this session.
     */
    fun countPrsInSession(
        session: WorkoutSessionWithExercises,
        prs: List<PersonalRecordEntity>
    ): Int {
        val sessionSetIds = session.exercises.flatMap { it.sets }.map { it.id }.toSet()
        if (sessionSetIds.isEmpty()) return 0
        return prs.count { it.setLogId in sessionSetIds }
    }

    /**
     * Returns the set of setLogIds in this session that represent a PR.
     */
    fun getPrSetLogIdsForSession(
        session: WorkoutSessionWithExercises,
        prs: List<PersonalRecordEntity>
    ): Set<Long> {
        val sessionSetIds = session.exercises.flatMap { it.sets }.map { it.id }.toSet()
        if (sessionSetIds.isEmpty()) return emptySet()
        return prs.filter { it.setLogId in sessionSetIds }.map { it.setLogId }.toSet()
    }

    /**
     * Formats duration between startedAt and endedAt.
     */
    fun formatDuration(startedAt: Long, endedAt: Long?): String {
        val end = endedAt ?: startedAt
        val durationMs = maxOf(0L, end - startedAt)
        val minutes = (durationMs / 60000L).toInt()
        return if (minutes < 60) {
            "$minutes min"
        } else {
            val hours = minutes / 60
            val rem = minutes % 60
            "${hours}h ${rem}m"
        }
    }

    /**
     * Formats epoch millis into month header (e.g. "October 2026").
     */
    fun formatMonthHeader(epochMillis: Long, zoneId: ZoneId = ZoneId.systemDefault()): String {
        return Instant.ofEpochMilli(epochMillis)
            .atZone(zoneId)
            .format(MONTH_YEAR_FORMATTER)
    }

    /**
     * Formats epoch millis into date string.
     */
    fun formatDate(epochMillis: Long, zoneId: ZoneId = ZoneId.systemDefault()): String {
        return Instant.ofEpochMilli(epochMillis)
            .atZone(zoneId)
            .format(SHORT_DATE_FORMATTER)
    }

    /**
     * Groups completed sessions by month header (e.g. "October 2026"), newest month first,
     * and newest session first within each month.
     * DISCARDED and IN_PROGRESS sessions are strictly excluded.
     */
    fun groupSessionsByMonth(
        sessions: List<WorkoutSessionWithExercises>,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): Map<String, List<WorkoutSessionWithExercises>> {
        val completedOnly = filterCompletedSessions(sessions)
        val grouped = LinkedHashMap<String, MutableList<WorkoutSessionWithExercises>>()
        for (session in completedOnly) {
            val timestamp = session.session.endedAt ?: session.session.startedAt
            val monthKey = formatMonthHeader(timestamp, zoneId)
            grouped.getOrPut(monthKey) { mutableListOf() }.add(session)
        }
        return grouped
    }

    /**
     * Builds History rows for completed sessions with total volume, PR count, formatted date and duration.
     */
    fun buildHistoryItems(
        sessions: List<WorkoutSessionWithExercises>,
        prs: List<PersonalRecordEntity>,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): Map<String, List<SessionHistoryItem>> {
        val completedGrouped = groupSessionsByMonth(sessions, zoneId)
        val result = LinkedHashMap<String, List<SessionHistoryItem>>()

        for ((month, monthSessions) in completedGrouped) {
            result[month] = monthSessions.map { sessionWithExercises ->
                val timestamp = sessionWithExercises.session.endedAt ?: sessionWithExercises.session.startedAt
                val volume = calculateTotalVolume(sessionWithExercises)
                val prCount = countPrsInSession(sessionWithExercises, prs)
                val duration = formatDuration(sessionWithExercises.session.startedAt, sessionWithExercises.session.endedAt)
                val dateText = formatDate(timestamp, zoneId)

                SessionHistoryItem(
                    sessionId = sessionWithExercises.session.id,
                    dayName = sessionWithExercises.session.dayName,
                    dateText = dateText,
                    durationText = duration,
                    exerciseCount = sessionWithExercises.exercises.size,
                    totalVolumeKg = volume,
                    prCount = prCount,
                    timestamp = timestamp
                )
            }
        }
        return result
    }

    /**
     * Extracts exercise history for ExerciseDetailScreen:
     * - Only COMPLETED sessions that include this exercise
     * - Newest first
     * - For each session: date, all logged sets, and the best set
     */
    fun getExerciseHistory(
        exerciseId: String,
        sessions: List<WorkoutSessionWithExercises>,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): List<ExerciseHistorySession> {
        val completedSessions = filterCompletedSessions(sessions)
        val history = mutableListOf<ExerciseHistorySession>()

        for (session in completedSessions) {
            val matchingExercises = session.exercises.filter { it.exercise.exerciseId == exerciseId }
            if (matchingExercises.isNotEmpty()) {
                val timestamp = session.session.endedAt ?: session.session.startedAt
                val allSets = matchingExercises.flatMap { it.sets }.sortedBy { it.setIndex }
                val bestSet = calculateBestSet(allSets)

                history.add(
                    ExerciseHistorySession(
                        sessionId = session.session.id,
                        sessionDayName = session.session.dayName,
                        dateText = formatDate(timestamp, zoneId),
                        timestamp = timestamp,
                        sets = allSets,
                        bestSet = bestSet
                    )
                )
            }
        }
        return history
    }

    /**
     * Builds personal records list for Records tab:
     * - Takes the best record per type per exercise from personal_record table.
     * - Exercises sorted most recent achievedAt first.
     * - Identifies bodyweight vs weighted exercises.
     */
    fun extractBestRecordsPerExercise(
        records: List<PersonalRecordEntity>,
        exerciseNames: Map<String, String> = emptyMap(),
        isBodyweightOverride: ((String) -> Boolean)? = null
    ): List<ExerciseRecordItem> {
        val groupedByExercise = records.groupBy { it.exerciseId }
        val summaries = mutableListOf<ExerciseRecordItem>()

        for ((exerciseId, exerciseRecords) in groupedByExercise) {
            val heaviest = exerciseRecords
                .filter { it.type == PersonalRecordType.HEAVIEST_WEIGHT }
                .maxByOrNull { it.value }

            val bestE1rm = exerciseRecords
                .filter { it.type == PersonalRecordType.BEST_E1RM }
                .maxByOrNull { it.value }

            val bestReps = exerciseRecords
                .filter { it.type == PersonalRecordType.BEST_REPS_AT_WEIGHT }
                .maxByOrNull { it.value }

            val mostRecent = exerciseRecords.maxOfOrNull { it.achievedAt } ?: 0L

            val isBw = isBodyweightOverride?.invoke(exerciseId)
                ?: (heaviest == null && bestE1rm == null && bestReps != null)

            val name = exerciseNames[exerciseId]
                ?: "Exercise $exerciseId"

            summaries.add(
                ExerciseRecordItem(
                    exerciseId = exerciseId,
                    exerciseName = name,
                    heaviestWeightKg = heaviest?.value,
                    heaviestAchievedAt = heaviest?.achievedAt,
                    bestE1rmKg = bestE1rm?.value,
                    bestE1rmAchievedAt = bestE1rm?.achievedAt,
                    bestReps = bestReps?.value?.toInt(),
                    bestRepsAchievedAt = bestReps?.achievedAt,
                    mostRecentAchievedAt = mostRecent,
                    isBodyweight = isBw
                )
            )
        }

        return summaries.sortedByDescending { it.mostRecentAchievedAt }
    }
}
