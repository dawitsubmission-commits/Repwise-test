package com.example.domain.templates

import com.example.data.local.entities.PlanDayEntity
import com.example.data.local.entities.PlanDayWithExercises
import com.example.data.local.entities.PlanExerciseEntity
import com.example.data.local.entities.WorkoutPlanEntity
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.domain.models.CatalogExercise

data class TemplateDaySpec(
    val name: String,
    val exerciseIds: List<String>,
    val defaultWeekday: Int? = null // 1..7 for Mon..Sun
)

data class WorkoutTemplateSpec(
    val key: String,
    val name: String,
    val level: String, // Beginner, Intermediate, Advanced
    val daysCount: Int,
    val description: String,
    val days: List<TemplateDaySpec>
) {
    val isNotRecommendedForBeginners: Boolean
        get() = days.size >= 6 || level.equals("Advanced", ignoreCase = true)
}

object TemplateRepository {

    val templates: List<WorkoutTemplateSpec> = listOf(
        WorkoutTemplateSpec(
            key = "beginner_full_body",
            name = "Beginner Full Body",
            level = "Beginner",
            daysCount = 3,
            description = "Balanced 3-day foundation focusing on compound lifts and core strength.",
            days = listOf(
                TemplateDaySpec("Day A", listOf("1760", "0289", "0293", "0426", "0276"), defaultWeekday = 1), // Monday
                TemplateDaySpec("Day B", listOf("1459", "0662", "2330", "0334", "3013", "0274"), defaultWeekday = 3), // Wednesday
                TemplateDaySpec("Day C", listOf("0336", "0405", "0861", "0294", "0430", "0464"), defaultWeekday = 5)  // Friday
            )
        ),
        WorkoutTemplateSpec(
            key = "upper_lower",
            name = "Upper / Lower",
            level = "Intermediate",
            daysCount = 4,
            description = "Classic 4-day split for muscle hypertrophy and progressive overload.",
            days = listOf(
                TemplateDaySpec("Upper A", listOf("0289", "0293", "0426", "0294", "0430"), defaultWeekday = 1), // Monday
                TemplateDaySpec("Lower A", listOf("1760", "1459", "0599", "0594", "0276"), defaultWeekday = 2), // Tuesday
                TemplateDaySpec("Upper B", listOf("0662", "2330", "0405", "0383", "0285"), defaultWeekday = 4), // Thursday
                TemplateDaySpec("Lower B", listOf("0336", "3013", "0585", "1387", "0872"), defaultWeekday = 5)  // Friday
            )
        ),
        WorkoutTemplateSpec(
            key = "push_pull_legs",
            name = "Push / Pull / Legs",
            level = "Advanced",
            daysCount = 3,
            description = "High-efficiency push, pull, and leg specialization split.",
            days = listOf(
                TemplateDaySpec("Push", listOf("0289", "0426", "0334", "0430", "0662"), defaultWeekday = 1),
                TemplateDaySpec("Pull", listOf("2330", "0293", "0861", "0383", "0294"), defaultWeekday = 3),
                TemplateDaySpec("Legs", listOf("1760", "1459", "0336", "0599", "0594"), defaultWeekday = 5)
            )
        ),
        WorkoutTemplateSpec(
            key = "home_bodyweight",
            name = "Home Bodyweight",
            level = "Beginner",
            daysCount = 3,
            description = "Zero-equipment Calisthenics split suitable for home training.",
            days = listOf(
                TemplateDaySpec("Day A", listOf("0659", "3013", "2368", "0276", "0464"), defaultWeekday = 1),
                TemplateDaySpec("Day B", listOf("0662", "1387", "0274", "0630"), defaultWeekday = 3),
                TemplateDaySpec("Day C", listOf("0499", "3013", "0872", "1160"), defaultWeekday = 5)
            )
        )
    )

    fun getAllTemplates(): List<WorkoutTemplateSpec> = templates

    fun getTemplateByKey(key: String): WorkoutTemplateSpec? = templates.find { it.key == key }

    /**
     * Determines default sets, reps, and rest:
     * - core: 2x10-15 rest 45s
     * - compound: 3x8-12 rest 90s
     * - accessory: 2x10-15 rest 60s
     */
    fun classifyDefaults(exercise: CatalogExercise?): Triple<Int, Pair<Int, Int>, Int> {
        if (exercise == null) {
            return Triple(3, Pair(8, 12), 90)
        }
        val target = exercise.target.lowercase()
        val equip = exercise.equipment.lowercase()
        val pattern = exercise.movementPattern?.lowercase() ?: ""

        return when {
            target == "core" -> {
                // core: 2x10-15 rest 45s
                Triple(2, Pair(10, 15), 45)
            }
            pattern.contains("squat") || pattern.contains("hinge") ||
                pattern.contains("push_h") || pattern.contains("push_v") ||
                pattern.contains("pull_h") || pattern.contains("pull_v") ||
                equip.contains("barbell") || equip.contains("body weight") -> {
                // compound: 3x8-12 rest 90s
                Triple(3, Pair(8, 12), 90)
            }
            else -> {
                // accessory: 2x10-15 rest 60s
                Triple(2, Pair(10, 15), 60)
            }
        }
    }

    /**
     * Instantiates a template as a fresh, independent WorkoutPlanWithDays in-memory model.
     * "Use this template" copies it into the user's own routines (never links).
     */
    fun createPlanFromTemplate(
        spec: WorkoutTemplateSpec,
        catalogLookup: Map<String, CatalogExercise> = emptyMap(),
        isActive: Boolean = false
    ): WorkoutPlanWithDays {
        val planEntity = WorkoutPlanEntity(
            id = 0,
            name = spec.name,
            templateKey = spec.key,
            isActive = isActive,
            createdAt = System.currentTimeMillis()
        )

        val daysWithExercises = spec.days.mapIndexed { dayIndex, daySpec ->
            val dayEntity = PlanDayEntity(
                id = 0,
                planId = 0,
                name = daySpec.name,
                weekday = daySpec.defaultWeekday,
                position = dayIndex
            )

            val exerciseEntities = daySpec.exerciseIds.mapIndexed { exIndex, exId ->
                val catalogEx = catalogLookup[exId]
                val (sets, reps, rest) = classifyDefaults(catalogEx)
                PlanExerciseEntity(
                    id = 0,
                    planDayId = 0,
                    exerciseId = exId,
                    position = exIndex,
                    sets = sets,
                    repMin = reps.first,
                    repMax = reps.second,
                    restSeconds = rest,
                    note = null
                )
            }

            PlanDayWithExercises(
                day = dayEntity,
                exercises = exerciseEntities
            )
        }

        return WorkoutPlanWithDays(
            plan = planEntity,
            days = daysWithExercises
        )
    }

    /**
     * Deep-duplicates a routine into a fully independent copy.
     */
    fun duplicatePlan(
        original: WorkoutPlanWithDays,
        newName: String? = null
    ): WorkoutPlanWithDays {
        val clonedPlan = original.plan.copy(
            id = 0,
            name = newName ?: "${original.plan.name} (Copy)",
            isActive = false,
            createdAt = System.currentTimeMillis()
        )

        val clonedDays = original.days.mapIndexed { dayIdx, dayWithEx ->
            val clonedDay = dayWithEx.day.copy(
                id = 0,
                planId = 0,
                position = dayIdx
            )
            val clonedExercises = dayWithEx.exercises.mapIndexed { exIdx, ex ->
                ex.copy(
                    id = 0,
                    planDayId = 0,
                    position = exIdx
                )
            }
            PlanDayWithExercises(
                day = clonedDay,
                exercises = clonedExercises
            )
        }

        return WorkoutPlanWithDays(
            plan = clonedPlan,
            days = clonedDays
        )
    }
}
