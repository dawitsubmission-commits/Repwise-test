package com.example.domain.warmup

enum class DrillKind(val code: Char) {
    DYNAMIC('D'),
    STRETCH('S')
}

data class PoolEntry(
    val exerciseId: String,
    val kind: DrillKind
)

object WarmupPool {
    const val DEFAULT_DRILL_SECONDS = 30

    val general: List<PoolEntry> = listOf(
        PoolEntry("3636", DrillKind.DYNAMIC),
        PoolEntry("3224", DrillKind.DYNAMIC),
        PoolEntry("3223", DrillKind.DYNAMIC),
        PoolEntry("1471", DrillKind.DYNAMIC),
        PoolEntry("3698", DrillKind.DYNAMIC)
    )

    val chest: List<PoolEntry> = listOf(
        PoolEntry("1167", DrillKind.DYNAMIC),
        PoolEntry("1271", DrillKind.STRETCH),
        PoolEntry("1405", DrillKind.STRETCH)
    )

    val back: List<PoolEntry> = listOf(
        PoolEntry("2329", DrillKind.DYNAMIC),
        PoolEntry("1363", DrillKind.STRETCH),
        PoolEntry("1346", DrillKind.STRETCH),
        PoolEntry("0794", DrillKind.STRETCH),
        PoolEntry("1358", DrillKind.STRETCH),
        PoolEntry("0690", DrillKind.STRETCH),
        PoolEntry("1365", DrillKind.STRETCH)
    )

    val shoulders: List<PoolEntry> = listOf(
        PoolEntry("1167", DrillKind.DYNAMIC),
        PoolEntry("1428", DrillKind.DYNAMIC),
        PoolEntry("0669", DrillKind.STRETCH),
        PoolEntry("1271", DrillKind.STRETCH)
    )

    val arms: List<PoolEntry> = listOf(
        PoolEntry("1428", DrillKind.DYNAMIC),
        PoolEntry("0817", DrillKind.STRETCH),
        PoolEntry("0643", DrillKind.STRETCH),
        PoolEntry("0721", DrillKind.STRETCH)
    )

    val legs: List<PoolEntry> = listOf(
        PoolEntry("1685", DrillKind.DYNAMIC),
        PoolEntry("1686", DrillKind.DYNAMIC),
        PoolEntry("1688", DrillKind.DYNAMIC),
        PoolEntry("1687", DrillKind.DYNAMIC),
        PoolEntry("1604", DrillKind.DYNAMIC),
        PoolEntry("3561", DrillKind.DYNAMIC),
        PoolEntry("1368", DrillKind.DYNAMIC),
        PoolEntry("1418", DrillKind.STRETCH),
        PoolEntry("1424", DrillKind.STRETCH),
        PoolEntry("2567", DrillKind.STRETCH),
        PoolEntry("1511", DrillKind.STRETCH),
        PoolEntry("1576", DrillKind.STRETCH),
        PoolEntry("1585", DrillKind.STRETCH),
        PoolEntry("1512", DrillKind.STRETCH),
        PoolEntry("0613", DrillKind.STRETCH),
        PoolEntry("2571", DrillKind.STRETCH),
        PoolEntry("1377", DrillKind.STRETCH),
        PoolEntry("1398", DrillKind.STRETCH)
    )

    val core: List<PoolEntry> = listOf(
        PoolEntry("2329", DrillKind.DYNAMIC),
        PoolEntry("3213", DrillKind.DYNAMIC),
        PoolEntry("1468", DrillKind.DYNAMIC),
        PoolEntry("3639", DrillKind.DYNAMIC),
        PoolEntry("1471", DrillKind.DYNAMIC)
    )

    fun drillsForArea(area: String): List<PoolEntry> = when (area.lowercase()) {
        "chest" -> chest
        "back" -> back
        "shoulders" -> shoulders
        "arms" -> arms
        "legs" -> legs
        "core" -> core
        "general" -> general
        else -> emptyList()
    }
}
