package com.example.domain

import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.PersonalRecordType
import com.example.data.local.entities.SetLogEntity
import kotlin.math.abs

data class NewRecord(
    val type: String,
    val value: Double,
    val setLog: SetLogEntity,
    val description: String
)

/**
 * Detects Personal Records (PRs) from workout sets.
 * Rules:
 * - Computed ONLY from COMPLETED sets (completedAt != null)
 * - Warm-ups are completely ignored (isWarmup == false)
 * - Ties are NOT PRs (must be strictly greater than historical best)
 * - The first-ever completed set of an exercise is a baseline, not a PR. A PR needs prior history for that exercise.
 * - BEST_REPS_AT_WEIGHT only counts if prior sets exist at that exact weight.
 * - Weight 0 means bodyweight: track best reps only (no heaviest weight, no e1RM).
 * - Keep only the best record per type per exercise per session.
 * - 3 PR Types:
 *   1. HEAVIEST_WEIGHT: strictly highest weightKg achieved for this exercise (weight > 0)
 *   2. BEST_E1RM: strictly highest Epley estimated 1RM for reps in 1..12 (weight > 0)
 *   3. BEST_REPS_AT_WEIGHT: strictly highest reps achieved at this specific weight (if prior sets exist at exact weight)
 */
object PersonalRecordDetector {

    private const val WEIGHT_EPSILON = 0.001

    /**
     * Checks if a single set is a PR given prior history.
     * Used in the Active Workout UI to show the "PR" badge as sets are completed.
     */
    fun isSetPR(
        candidateSet: SetLogEntity,
        priorCompletedSets: List<SetLogEntity>
    ): Boolean {
        if (!isValidWorkingSet(candidateSet)) return false

        val validPriors = priorCompletedSets.filter { isValidWorkingSet(it) }
        // The first-ever completed set of an exercise is a baseline, not a PR. A PR needs prior history for that exercise.
        if (validPriors.isEmpty()) return false

        // Weight 0 means bodyweight: track best reps only (no heaviest weight, no e1RM)
        if (abs(candidateSet.weightKg) < WEIGHT_EPSILON) {
            val priorAtWeight = validPriors.filter { abs(it.weightKg) < WEIGHT_EPSILON }
            val maxPriorReps = priorAtWeight.maxOfOrNull { it.reps } ?: return false
            return candidateSet.reps > maxPriorReps
        }

        // 1. Heaviest Weight: candidate weight must strictly beat all priors (> 0kg)
        val priorWeighted = validPriors.filter { it.weightKg > 0.0 }
        val maxPriorWeight = priorWeighted.maxOfOrNull { it.weightKg }
        val isHeaviest = if (maxPriorWeight != null) candidateSet.weightKg > maxPriorWeight else false

        // 2. Best E1RM: candidate reps in 1..12 and e1rm strictly beats all priors in 1..12
        val candidateE1rm = Epley.calculate1RM(candidateSet.weightKg, candidateSet.reps)
        val isBestE1rm = if (candidateE1rm != null) {
            val maxPriorE1rm = validPriors
                .mapNotNull { Epley.calculate1RM(it.weightKg, it.reps) }
                .maxOrNull()
            if (maxPriorE1rm != null) candidateE1rm > maxPriorE1rm else false
        } else false

        // 3. Best Reps at this Weight: ONLY counts if prior sets exist at that exact weight
        val priorSetsAtWeight = validPriors.filter { abs(it.weightKg - candidateSet.weightKg) < WEIGHT_EPSILON }
        val maxPriorRepsAtWeight = priorSetsAtWeight.maxOfOrNull { it.reps }
        val isBestRepsAtWeight = if (maxPriorRepsAtWeight != null) candidateSet.reps > maxPriorRepsAtWeight else false

        return isHeaviest || isBestE1rm || isBestRepsAtWeight
    }

    /**
     * Detects all distinct new PRs achieved in a completed workout session,
     * comparing against prior completed historical sets.
     * Evaluates sets chronologically, rejects ties, enforces bodyweight rules,
     * and keeps only the best record per type per exercise per session.
     */
    fun detectNewPRsForExercise(
        exerciseId: String,
        sessionSets: List<SetLogEntity>,
        priorHistoricalSets: List<SetLogEntity>,
        achievedAt: Long = System.currentTimeMillis()
    ): List<PersonalRecordEntity> {
        val completedValidSessionSets = sessionSets
            .filter { isValidWorkingSet(it) }
            .sortedBy { it.completedAt ?: 0L }

        if (completedValidSessionSets.isEmpty()) return emptyList()

        val runningHistory = priorHistoricalSets
            .filter { isValidWorkingSet(it) }
            .toMutableList()

        val detectedRecords = mutableListOf<PersonalRecordEntity>()

        for (candidate in completedValidSessionSets) {
            val isBodyweight = abs(candidate.weightKg) < WEIGHT_EPSILON

            if (isBodyweight) {
                // Weight 0 means bodyweight: track best reps only (no heaviest weight, no e1RM)
                val priorAtWeight = runningHistory.filter { abs(it.weightKg) < WEIGHT_EPSILON }
                val maxRepsAtWeight = priorAtWeight.maxOfOrNull { it.reps }
                // BEST_REPS_AT_WEIGHT only counts if prior sets exist at that exact weight
                if (maxRepsAtWeight != null && candidate.reps > maxRepsAtWeight) {
                    detectedRecords.add(
                        PersonalRecordEntity(
                            id = 0,
                            exerciseId = exerciseId,
                            type = PersonalRecordType.BEST_REPS_AT_WEIGHT,
                            value = candidate.reps.toDouble(),
                            setLogId = candidate.id,
                            achievedAt = candidate.completedAt ?: achievedAt
                        )
                    )
                }
            } else {
                // Weighted exercise (> 0kg)
                // 1. Check Heaviest Weight: needs prior history for that exercise
                val priorWeighted = runningHistory.filter { it.weightKg > 0.0 }
                val currentMaxWeight = priorWeighted.maxOfOrNull { it.weightKg }
                if (currentMaxWeight != null && candidate.weightKg > currentMaxWeight) {
                    detectedRecords.add(
                        PersonalRecordEntity(
                            id = 0,
                            exerciseId = exerciseId,
                            type = PersonalRecordType.HEAVIEST_WEIGHT,
                            value = candidate.weightKg,
                            setLogId = candidate.id,
                            achievedAt = candidate.completedAt ?: achievedAt
                        )
                    )
                }

                // 2. Check Best E1RM: needs prior history for that exercise
                val candidateE1rm = Epley.calculate1RM(candidate.weightKg, candidate.reps)
                if (candidateE1rm != null) {
                    val currentMaxE1rm = runningHistory
                        .mapNotNull { Epley.calculate1RM(it.weightKg, it.reps) }
                        .maxOrNull()

                    if (currentMaxE1rm != null && candidateE1rm > currentMaxE1rm) {
                        detectedRecords.add(
                            PersonalRecordEntity(
                                id = 0,
                                exerciseId = exerciseId,
                                type = PersonalRecordType.BEST_E1RM,
                                value = candidateE1rm,
                                setLogId = candidate.id,
                                achievedAt = candidate.completedAt ?: achievedAt
                            )
                        )
                    }
                }

                // 3. Check Best Reps At Weight: ONLY counts if prior sets exist at that exact weight
                val priorAtWeight = runningHistory.filter { abs(it.weightKg - candidate.weightKg) < WEIGHT_EPSILON }
                val currentMaxRepsAtWeight = priorAtWeight.maxOfOrNull { it.reps }
                if (currentMaxRepsAtWeight != null && candidate.reps > currentMaxRepsAtWeight) {
                    detectedRecords.add(
                        PersonalRecordEntity(
                            id = 0,
                            exerciseId = exerciseId,
                            type = PersonalRecordType.BEST_REPS_AT_WEIGHT,
                            value = candidate.reps.toDouble(),
                            setLogId = candidate.id,
                            achievedAt = candidate.completedAt ?: achievedAt
                        )
                    )
                }
            }

            // Add candidate to running history so subsequent sets in this session must beat it
            runningHistory.add(candidate)
        }

        // Keep only the best record per type per exercise per session
        return detectedRecords
            .groupBy { it.type }
            .values
            .mapNotNull { recordsForType ->
                recordsForType.maxByOrNull { it.value }
            }
    }

    private fun isValidWorkingSet(set: SetLogEntity): Boolean {
        return !set.isWarmup && set.completedAt != null && set.reps > 0 && set.weightKg >= 0.0
    }
}
