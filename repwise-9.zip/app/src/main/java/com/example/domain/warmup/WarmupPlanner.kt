package com.example.domain.warmup

data class WarmupDrill(
    val exerciseId: String,
    val kind: DrillKind,
    val seconds: Int = WarmupPool.DEFAULT_DRILL_SECONDS,
    val area: String
)

object WarmupPlanner {

    fun areaOfTarget(target: String): String? {
        val clean = target.trim().lowercase()
        return when (clean) {
            "chest", "serratus anterior", "pectorals" -> "chest"
            "lats", "latissimus dorsi", "upper back", "trapezius", "spine", "rhomboids", "traps", "back" -> "back"
            "shoulders", "delts", "deltoids" -> "shoulders"
            "biceps", "triceps", "forearms" -> "arms"
            "quadriceps", "hamstrings", "glutes", "calves", "adductors", "abductors", "quads" -> "legs"
            "core", "abs" -> "core"
            else -> null
        }
    }

    fun plan(
        sessionTargets: List<String>,
        catalogIds: Set<String>,
        maxDrills: Int = 6
    ): List<WarmupDrill> {
        if (maxDrills <= 0) return emptyList()

        // (a) Count session exercises per area and determine top 2 areas (tie-breaker: order of appearance in workout)
        val areaFirstAppearance = mutableMapOf<String, Int>()
        val areaCounts = mutableMapOf<String, Int>()

        sessionTargets.forEachIndexed { index, rawTarget ->
            val area = areaOfTarget(rawTarget)
            if (area != null) {
                areaCounts[area] = (areaCounts[area] ?: 0) + 1
                if (!areaFirstAppearance.containsKey(area)) {
                    areaFirstAppearance[area] = index
                }
            }
        }

        val topAreas = areaCounts.keys
            .sortedWith(
                compareByDescending<String> { areaCounts[it] ?: 0 }
                    .thenBy { areaFirstAppearance[it] ?: Int.MAX_VALUE }
            )
            .take(2)

        val result = mutableListOf<WarmupDrill>()
        val usedIds = mutableSetOf<String>()

        // (b) 1 drill from "general" first
        val generalDrill = WarmupPool.general.firstOrNull { it.exerciseId in catalogIds }
        if (generalDrill != null && result.size < maxDrills) {
            result.add(
                WarmupDrill(
                    exerciseId = generalDrill.exerciseId,
                    kind = generalDrill.kind,
                    seconds = WarmupPool.DEFAULT_DRILL_SECONDS,
                    area = "general"
                )
            )
            usedIds.add(generalDrill.exerciseId)
        }

        // (c) Up to 3 drills per chosen area, dynamic drills before stretches
        for (area in topAreas) {
            if (result.size >= maxDrills) break

            val areaPool = WarmupPool.drillsForArea(area)
            val dynamicDrills = areaPool.filter { it.kind == DrillKind.DYNAMIC }
            val stretchDrills = areaPool.filter { it.kind == DrillKind.STRETCH }
            val orderedDrills = dynamicDrills + stretchDrills

            var takenForArea = 0
            for (entry in orderedDrills) {
                if (takenForArea >= 3 || result.size >= maxDrills) break

                // (e) drop any drill whose ID is not in catalogIds
                if (entry.exerciseId !in catalogIds) continue

                // (d) no duplicate exercise IDs
                if (entry.exerciseId in usedIds) continue

                result.add(
                    WarmupDrill(
                        exerciseId = entry.exerciseId,
                        kind = entry.kind,
                        seconds = WarmupPool.DEFAULT_DRILL_SECONDS,
                        area = area
                    )
                )
                usedIds.add(entry.exerciseId)
                takenForArea++
            }
        }

        return result
    }
}
