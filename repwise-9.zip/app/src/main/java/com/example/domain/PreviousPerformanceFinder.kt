package com.example.domain

import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.util.WeightHelper

data class PreviousPerformance(
    val lastSessionId: Long,
    val completedAt: Long,
    val summaryText: String,
    val sets: List<SetLogEntity>,
    val defaultWeightKg: Double,
    val defaultReps: Int
)

/**
 * Finds the previous performance for an exercise from completed workout sessions.
 * Rules:
 * - Strictly ignores sessions with status DISCARDED or IN_PROGRESS.
 * - Only inspects COMPLETED sessions.
 * - Selects the most recent completed session containing the exercise.
 * - Extracts reps and weight for prefilling and "Previous" line display.
 */
object PreviousPerformanceFinder {

    fun findPreviousPerformance(
        exerciseId: String,
        sessions: List<WorkoutSessionWithExercises>
    ): PreviousPerformance? {
        val completedSessions = sessions
            .filter { it.session.status == WorkoutSessionStatus.COMPLETED }
            .sortedByDescending { it.session.endedAt ?: it.session.startedAt }

        for (sessionWithExercises in completedSessions) {
            val matchingExercise = sessionWithExercises.exercises.firstOrNull {
                it.exercise.exerciseId == exerciseId
            } ?: continue

            // Look for completed non-warmup sets first, then completed sets, then any logged sets
            val sets = matchingExercise.sets
            val completedWorkingSets = sets.filter { !it.isWarmup && it.completedAt != null }
            val relevantSets = if (completedWorkingSets.isNotEmpty()) {
                completedWorkingSets
            } else {
                sets.filter { it.completedAt != null }.ifEmpty { sets }
            }

            if (relevantSets.isNotEmpty()) {
                val bestOrLast = relevantSets.maxByOrNull { it.weightKg } ?: relevantSets.last()
                val summary = "${WeightHelper.format(bestOrLast.weightKg)} × ${bestOrLast.reps} reps"

                return PreviousPerformance(
                    lastSessionId = sessionWithExercises.session.id,
                    completedAt = sessionWithExercises.session.endedAt ?: sessionWithExercises.session.startedAt,
                    summaryText = summary,
                    sets = relevantSets,
                    defaultWeightKg = bestOrLast.weightKg,
                    defaultReps = bestOrLast.reps
                )
            }
        }

        return null
    }
}
