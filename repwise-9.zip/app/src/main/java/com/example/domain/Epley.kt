package com.example.domain

/**
 * Calculates estimated 1-Rep Max (e1RM) using the standard Epley formula:
 * e1RM = weight * (1 + reps / 30)
 *
 * Rules:
 * - Only valid for reps in 1..12.
 * - Weight must be positive (> 0.0).
 * - Outside 1..12 or for non-positive weight, returns null.
 */
object Epley {

    fun calculate1RM(weightKg: Double, reps: Int): Double? {
        if (reps !in 1..12 || weightKg <= 0.0) {
            return null
        }
        return weightKg * (1.0 + (reps.toDouble() / 30.0))
    }
}
