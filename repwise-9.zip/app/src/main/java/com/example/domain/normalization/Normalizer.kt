package com.example.domain.normalization

/**
 * Normalizes muscle names and equipment values to canonical representations.
 * Explicit requirements:
 *  - pectorals -> chest
 *  - delts -> shoulders
 *  - quads -> quadriceps
 *  - traps -> trapezius
 *  - abs -> core
 *  - "band" and "resistance band" are the same
 */
object Normalizer {

    private val muscleMap: Map<String, String> = mapOf(
        // Explicit required mappings
        "pectorals" to "chest",
        "delts" to "shoulders",
        "quads" to "quadriceps",
        "traps" to "trapezius",
        "abs" to "core",

        // Canonical and synonym mappings
        "chest" to "chest",
        "upper chest" to "chest",
        "deltoids" to "shoulders",
        "shoulders" to "shoulders",
        "rear deltoids" to "rear deltoids",
        "rotator cuff" to "shoulders",
        "quadriceps" to "quadriceps",
        "trapezius" to "trapezius",
        "levator scapulae" to "trapezius",
        "core" to "core",
        "abdominals" to "core",
        "lower abs" to "core",
        "obliques" to "obliques",
        "biceps" to "biceps",
        "brachialis" to "biceps",
        "triceps" to "triceps",
        "forearms" to "forearms",
        "wrists" to "forearms",
        "wrist flexors" to "forearms",
        "wrist extensors" to "forearms",
        "hands" to "forearms",
        "grip muscles" to "forearms",
        "calves" to "calves",
        "soleus" to "soleus",
        "glutes" to "glutes",
        "hamstrings" to "hamstrings",
        "hip flexors" to "hip flexors",
        "adductors" to "adductors",
        "abductors" to "abductors",
        "groin" to "adductors",
        "inner thighs" to "adductors",
        "serratus anterior" to "serratus anterior",
        "lats" to "lats",
        "latissimus dorsi" to "lats",
        "upper back" to "upper back",
        "lower back" to "lower back",
        "spine" to "spine",
        "rhomboids" to "rhomboids",
        "back" to "back",
        "neck" to "neck",
        "sternocleidomastoid" to "neck",
        "shins" to "shins",
        "cardiovascular system" to "cardiovascular system",
        "ankle stabilizers" to "ankle stabilizers",
        "ankles" to "ankles",
        "feet" to "feet"
    )

    private val equipmentMap: Map<String, String> = mapOf(
        "band" to "resistance band",
        "resistance band" to "resistance band",
        "barbell" to "barbell",
        "ez barbell" to "barbell",
        "olympic barbell" to "barbell",
        "trap bar" to "barbell",
        "body weight" to "body weight",
        "cable" to "cable",
        "dumbbell" to "dumbbell",
        "leverage machine" to "leverage machine",
        "sled machine" to "leverage machine",
        "smith machine" to "smith machine",
        "kettlebell" to "kettlebell",
        "weighted" to "weighted",
        "stability ball" to "stability ball",
        "assisted" to "assisted",
        "medicine ball" to "medicine ball",
        "rope" to "rope",
        "roller" to "roller",
        "wheel roller" to "roller",
        "bosu ball" to "bosu ball",
        "upper body ergometer" to "cardio machine",
        "skierg machine" to "cardio machine",
        "stationary bike" to "cardio machine",
        "elliptical machine" to "cardio machine",
        "stepmill machine" to "cardio machine",
        "cardio machine" to "cardio machine",
        "hammer" to "other",
        "tire" to "other",
        "other" to "other"
    )

    /**
     * Normalizes a muscle string.
     * Throws [IllegalArgumentException] on any unmapped value so unit tests fail immediately.
     */
    fun normalizeMuscle(raw: String): String {
        val key = raw.trim().lowercase()
        return muscleMap[key] ?: throw IllegalArgumentException("Unmapped muscle value: '$raw'")
    }

    /**
     * Normalizes an equipment string.
     * Throws [IllegalArgumentException] on any unmapped value so unit tests fail immediately.
     */
    fun normalizeEquipment(raw: String): String {
        val key = raw.trim().lowercase()
        return equipmentMap[key] ?: throw IllegalArgumentException("Unmapped equipment value: '$raw'")
    }

    fun isMuscleMapped(raw: String): Boolean = muscleMap.containsKey(raw.trim().lowercase())
    fun isEquipmentMapped(raw: String): Boolean = equipmentMap.containsKey(raw.trim().lowercase())

    /**
     * Return list of primary normalized muscle groups for UI filter chips.
     */
    fun getAllFilterMuscles(): List<String> {
        return listOf(
            "All",
            "chest",
            "shoulders",
            "back",
            "quadriceps",
            "trapezius",
            "core",
            "biceps",
            "triceps",
            "glutes",
            "hamstrings",
            "calves"
        )
    }

    /**
     * Return list of primary normalized equipments for UI filter chips.
     */
    fun getAllFilterEquipments(): List<String> {
        return listOf(
            "All",
            "body weight",
            "dumbbell",
            "barbell",
            "cable",
            "resistance band",
            "leverage machine",
            "smith machine",
            "kettlebell",
            "other"
        )
    }
}
