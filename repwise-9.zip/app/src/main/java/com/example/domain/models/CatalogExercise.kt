package com.example.domain.models

data class CatalogExercise(
    val id: String,
    val name: String,
    val bodyPart: String,
    val equipment: String,
    val target: String,
    val secondaryMuscles: List<String> = emptyList(),
    val instructions: List<String> = emptyList(),
    val movementPattern: String? = null,
    val frame00Path: String? = null,
    val frame01Path: String? = null,
    val frame02Path: String? = null,
    val frameDurationMs: Long? = null,
    val sequence: List<Int> = listOf(0, 1, 2, 1)
) {
    val hasAnimation: Boolean
        get() = frame00Path != null && frame01Path != null && frame02Path != null
}
