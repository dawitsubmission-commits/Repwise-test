package com.example.domain.models

enum class MuscleGroup(val displayName: String) {
    ALL("All"),
    CHEST("Chest"),
    BACK("Back"),
    LEGS("Legs"),
    SHOULDERS("Shoulders"),
    ARMS("Arms"),
    CORE("Core")
}

data class Exercise(
    val id: String,
    val name: String,
    val primaryMuscle: MuscleGroup,
    val secondaryMuscles: List<MuscleGroup> = emptyList(),
    val equipment: String,
    val prRecord: String = "-"
)

data class ExerciseSet(
    val setNumber: Int,
    val weightKg: Double,
    val reps: Int,
    val isCompleted: Boolean = false
)

data class WorkoutExercise(
    val exercise: Exercise,
    val sets: List<ExerciseSet> = emptyList()
)

data class WorkoutTemplate(
    val id: String,
    val title: String,
    val subtitle: String,
    val targetMuscle: String,
    val estimatedMinutes: Int,
    val exerciseCount: Int,
    val exercises: List<Exercise> = emptyList()
)

data class WorkoutStat(
    val title: String,
    val value: String,
    val change: String? = null,
    val isPositive: Boolean = true
)

data class PlanDay(
    val dayName: String,
    val title: String,
    val description: String,
    val isRestDay: Boolean = false,
    val isToday: Boolean = false
)

data class UserProfile(
    val name: String,
    val handle: String,
    val currentStreakDays: Int,
    val totalWorkouts: Int,
    val totalVolumeKg: Long
)
