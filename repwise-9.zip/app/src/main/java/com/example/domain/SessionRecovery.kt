package com.example.domain

import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises

/**
 * Handles detection and recovery of interrupted or in-progress workout sessions
 * across app launches and restarts.
 */
object SessionRecovery {

    /**
     * Inspects a list of sessions and returns the active IN_PROGRESS session if present.
     * Ignores COMPLETED and DISCARDED sessions.
     */
    fun findInProgressSession(sessions: List<WorkoutSessionEntity>): WorkoutSessionEntity? {
        return sessions
            .filter { it.status == WorkoutSessionStatus.IN_PROGRESS }
            .maxByOrNull { it.startedAt }
    }

    /**
     * Inspects a list of sessions with exercises and returns the active IN_PROGRESS session if present.
     */
    fun findInProgressSessionWithExercises(
        sessions: List<WorkoutSessionWithExercises>
    ): WorkoutSessionWithExercises? {
        return sessions
            .filter { it.session.status == WorkoutSessionStatus.IN_PROGRESS }
            .maxByOrNull { it.session.startedAt }
    }
}
