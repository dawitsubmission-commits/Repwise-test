package com.example.domain.planner

enum class MovementSlot {
    KNEE,
    HINGE,
    H_PUSH,
    H_PULL,
    V_PUSH,
    V_PULL,
    REAR_DELT,
    SHOULDER_ACC,
    BICEPS,
    TRICEPS,
    LEG_CURL,
    CALF,
    CORE,
    CONDITIONING
}

enum class MinLevel {
    B, // Beginner
    I  // Intermediate
}

data class PoolExercise(
    val id: String,
    val name: String,
    val slot: MovementSlot,
    val equipmentTag: String,
    val minLevel: MinLevel
) {
    val isCompound: Boolean
        get() = when (slot) {
            MovementSlot.KNEE,
            MovementSlot.HINGE,
            MovementSlot.H_PUSH,
            MovementSlot.H_PULL,
            MovementSlot.V_PUSH,
            MovementSlot.V_PULL -> true
            else -> false
        }
}

/**
 * Hardcoded exercise pool matching Phase 7 specifications.
 * All 42 exercises verified to exist in the catalog.
 */
object ExercisePool {

    val allExercises: List<PoolExercise> = listOf(
        // KNEE (7)
        PoolExercise("2368", "Split Squats", MovementSlot.KNEE, "none", MinLevel.B),
        PoolExercise("1760", "Dumbbell Goblet Squat", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0336", "Dumbbell Lunge", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0431", "Dumbbell Step-up", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0381", "Dumbbell Rear Lunge", MovementSlot.KNEE, "dumbbell", MinLevel.B),
        PoolExercise("0585", "Lever Leg Extension", MovementSlot.KNEE, "machine", MinLevel.B),
        PoolExercise("0043", "Barbell Full Squat", MovementSlot.KNEE, "barbell", MinLevel.I),

        // HINGE (5)
        PoolExercise("3013", "Low Glute Bridge on Floor", MovementSlot.HINGE, "none", MinLevel.B),
        PoolExercise("1459", "Dumbbell Romanian Deadlift", MovementSlot.HINGE, "dumbbell", MinLevel.B),
        PoolExercise("0300", "Dumbbell Deadlift", MovementSlot.HINGE, "dumbbell", MinLevel.B),
        PoolExercise("1409", "Barbell Glute Bridge", MovementSlot.HINGE, "barbell", MinLevel.I),
        PoolExercise("0032", "Barbell Deadlift", MovementSlot.HINGE, "barbell", MinLevel.I),

        // H_PUSH (6)
        PoolExercise("0659", "Push-up (Wall)", MovementSlot.H_PUSH, "none", MinLevel.B),
        PoolExercise("0662", "Push-up", MovementSlot.H_PUSH, "none", MinLevel.B),
        PoolExercise("0289", "Dumbbell Bench Press", MovementSlot.H_PUSH, "dumbbell", MinLevel.B),
        PoolExercise("0577", "Lever Chest Press", MovementSlot.H_PUSH, "machine", MinLevel.B),
        PoolExercise("2144", "Cable Seated Chest Press", MovementSlot.H_PUSH, "cable", MinLevel.B),
        PoolExercise("0025", "Barbell Bench Press", MovementSlot.H_PUSH, "barbell", MinLevel.I),

        // H_PULL (4)
        PoolExercise("0293", "Dumbbell Bent Over Row", MovementSlot.H_PULL, "dumbbell", MinLevel.B),
        PoolExercise("0861", "Cable Seated Row", MovementSlot.H_PULL, "cable", MinLevel.B),
        PoolExercise("0993", "Band Reverse Fly", MovementSlot.H_PULL, "band", MinLevel.B),
        PoolExercise("0499", "Inverted Row", MovementSlot.H_PULL, "bar", MinLevel.I),

        // V_PUSH (2)
        PoolExercise("0405", "Dumbbell Seated Shoulder Press", MovementSlot.V_PUSH, "dumbbell", MinLevel.B),
        PoolExercise("0426", "Dumbbell Standing Overhead Press", MovementSlot.V_PUSH, "dumbbell", MinLevel.B),

        // V_PULL (2)
        PoolExercise("2330", "Cable Lat Pulldown Full Range of Motion", MovementSlot.V_PULL, "cable", MinLevel.B),
        PoolExercise("0652", "Pull-up", MovementSlot.V_PULL, "bar", MinLevel.I),

        // REAR_DELT (1)
        PoolExercise("0383", "Dumbbell Reverse Fly", MovementSlot.REAR_DELT, "dumbbell", MinLevel.B),

        // SHOULDER_ACC (1)
        PoolExercise("0334", "Dumbbell Lateral Raise", MovementSlot.SHOULDER_ACC, "dumbbell", MinLevel.B),

        // BICEPS (2)
        PoolExercise("0294", "Dumbbell Biceps Curl", MovementSlot.BICEPS, "dumbbell", MinLevel.B),
        PoolExercise("0285", "Dumbbell Alternate Biceps Curl", MovementSlot.BICEPS, "dumbbell", MinLevel.B),

        // TRICEPS (2)
        PoolExercise("0430", "Dumbbell Standing Triceps Extension", MovementSlot.TRICEPS, "dumbbell", MinLevel.B),
        PoolExercise("0814", "Triceps Dip", MovementSlot.TRICEPS, "bench", MinLevel.I),

        // LEG_CURL (1)
        PoolExercise("0599", "Lever Seated Leg Curl", MovementSlot.LEG_CURL, "machine", MinLevel.B),

        // CALF (2)
        PoolExercise("0594", "Lever Seated Calf Raise", MovementSlot.CALF, "machine", MinLevel.B),
        PoolExercise("1387", "One Leg Floor Calf Raise", MovementSlot.CALF, "none", MinLevel.B),

        // CORE (5)
        PoolExercise("0276", "Dead Bug", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0464", "Front Plank with Twist", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0274", "Crunch Floor", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0872", "Reverse Crunch", MovementSlot.CORE, "none", MinLevel.B),
        PoolExercise("0472", "Hanging Leg Raise", MovementSlot.CORE, "bar", MinLevel.I),

        // CONDITIONING (2)
        PoolExercise("0630", "Mountain Climber", MovementSlot.CONDITIONING, "none", MinLevel.B),
        PoolExercise("1160", "Burpee", MovementSlot.CONDITIONING, "none", MinLevel.I)
    )

    private val poolById: Map<String, PoolExercise> = allExercises.associateBy { it.id }

    fun findById(id: String): PoolExercise? = poolById[id]
}
