package com.example.domain.bmi

import java.util.Locale
import kotlin.math.round

/**
 * Pure Kotlin BMI Calculator following Phase 7 clinical and communication guidelines.
 * - Metric: kg / (m^2)
 * - Imperial: 703 x lb / (in^2)
 * - Minimum supported age: 13
 * - Under 20: No adult categories, reference chart advisory
 * - Age 20+: Standard screening categories with non-diagnostic screening note
 * - Never suggests weight loss or gain
 */
object BmiCalculator {
    const val MIN_SUPPORTED_AGE = 13
    const val ADULT_AGE_THRESHOLD = 20

    const val CATEGORY_BELOW_TYPICAL = "Below the typical range"
    const val CATEGORY_TYPICAL = "Typical range"
    const val CATEGORY_ABOVE_TYPICAL = "Above the typical range"
    const val CATEGORY_WELL_ABOVE_TYPICAL = "Well above the typical range"

    const val ADULT_NOTE =
        "BMI is a screening number. It does not measure muscle, fitness, or health, and it does not diagnose anything."

    const val UNDER_20_NOTE =
        "For people under 20, BMI needs to be compared with age and sex reference charts. Talk to a doctor or health professional for an interpretation."

    const val UNDER_MIN_AGE_MESSAGE =
        "REPWISE is designed for individuals aged 13 and older. At this age, general fitness guidelines and adult assessments are not suitable. Talk with a doctor or health professional for youth guidance."

    /**
     * Metric calculation: weight in kg, height in cm.
     */
    fun calculateMetric(heightCm: Double, weightKg: Double, age: Int): BmiResult {
        if (age < MIN_SUPPORTED_AGE) {
            return BmiResult(
                bmi = 0.0,
                formattedBmi = "-",
                category = null,
                interpretationText = UNDER_MIN_AGE_MESSAGE,
                note = "",
                isEligible = false
            )
        }
        if (heightCm <= 0.0 || weightKg <= 0.0) {
            return BmiResult(0.0, "-", null, "Invalid measurements", "", false)
        }

        val heightM = heightCm / 100.0
        val rawBmi = weightKg / (heightM * heightM)

        return buildResult(rawBmi, age)
    }

    /**
     * Imperial calculation: weight in lbs, height in inches.
     * Formula: 703 * lb / (in^2)
     */
    fun calculateImperial(heightInches: Double, weightLbs: Double, age: Int): BmiResult {
        if (age < MIN_SUPPORTED_AGE) {
            return BmiResult(
                bmi = 0.0,
                formattedBmi = "-",
                category = null,
                interpretationText = UNDER_MIN_AGE_MESSAGE,
                note = "",
                isEligible = false
            )
        }
        if (heightInches <= 0.0 || weightLbs <= 0.0) {
            return BmiResult(0.0, "-", null, "Invalid measurements", "", false)
        }

        val rawBmi = 703.0 * weightLbs / (heightInches * heightInches)

        return buildResult(rawBmi, age)
    }

    /**
     * Direct evaluation for a given BMI value and age (used for boundary testing and display).
     */
    fun evaluateBmi(bmi: Double, age: Int): BmiResult {
        if (age < MIN_SUPPORTED_AGE) {
            return BmiResult(
                bmi = bmi,
                formattedBmi = String.format(Locale.US, "%.1f", bmi),
                category = null,
                interpretationText = UNDER_MIN_AGE_MESSAGE,
                note = "",
                isEligible = false
            )
        }
        return buildResult(bmi, age)
    }

    private fun buildResult(unroundedBmi: Double, age: Int): BmiResult {
        val roundedBmi = round(unroundedBmi * 10.0) / 10.0
        val formatted = String.format(Locale.US, "%.1f", roundedBmi)
        if (age < ADULT_AGE_THRESHOLD) {
            return BmiResult(
                bmi = roundedBmi,
                formattedBmi = formatted,
                category = null,
                interpretationText = UNDER_20_NOTE,
                note = UNDER_20_NOTE,
                isEligible = true
            )
        }

        val category = when {
            unroundedBmi < 18.5 -> CATEGORY_BELOW_TYPICAL
            unroundedBmi < 25.0 -> CATEGORY_TYPICAL
            unroundedBmi < 30.0 -> CATEGORY_ABOVE_TYPICAL
            else -> CATEGORY_WELL_ABOVE_TYPICAL
        }

        return BmiResult(
            bmi = roundedBmi,
            formattedBmi = formatted,
            category = category,
            interpretationText = category,
            note = ADULT_NOTE,
            isEligible = true
        )
    }
}

data class BmiResult(
    val bmi: Double,
    val formattedBmi: String,
    val category: String?,
    val interpretationText: String,
    val note: String,
    val isEligible: Boolean
)
