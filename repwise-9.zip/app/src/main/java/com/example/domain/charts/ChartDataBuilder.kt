package com.example.domain.charts

import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.domain.Epley
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

data class WeekBucket(
    val weekStartMillis: Long,
    val sessionCount: Int,
    val volumeKg: Double
)

data class MonthBucket(
    val monthStartMillis: Long,
    val sessionCount: Int,
    val volumeKg: Double
)

data class StrengthPoint(
    val dateMillis: Long,
    val bestE1rmKg: Double?,
    val bestWeightKg: Double,
    val bestReps: Int
)

data class ConsistencySummary(
    val weeksWithAtLeastOneWorkout: Int,
    val avgSessionsPerWeek: Double
)

object ChartDataBuilder {

    /**
     * Builds weekly buckets for the last [weeks] weeks.
     * Weeks start on Monday, the last bucket is the current week,
     * and every week in the range is present (0 when empty).
     */
    fun weeklyBuckets(
        sessions: List<WorkoutSessionWithExercises>,
        weeks: Int = 8,
        nowMillis: Long = System.currentTimeMillis(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): List<WeekBucket> {
        if (weeks <= 0) return emptyList()

        val completedSessions = sessions.filter { it.session.status == WorkoutSessionStatus.COMPLETED }
        val now = Instant.ofEpochMilli(nowMillis).atZone(zoneId)
        val currentMonday = now.toLocalDate().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

        return (0 until weeks).map { i ->
            val monday = currentMonday.minusWeeks((weeks - 1 - i).toLong())
            val startMillis = monday.atStartOfDay(zoneId).toInstant().toEpochMilli()
            val endMillis = monday.plusWeeks(1).atStartOfDay(zoneId).toInstant().toEpochMilli()

            val weekSessions = completedSessions.filter {
                val ts = it.session.startedAt
                ts in startMillis until endMillis
            }

            var volumeKg = 0.0
            for (session in weekSessions) {
                for (exercise in session.exercises) {
                    for (set in exercise.sets) {
                        if (set.completedAt != null && !set.isWarmup && set.reps > 0 && set.weightKg > 0.0) {
                            volumeKg += (set.reps * set.weightKg)
                        }
                    }
                }
            }

            WeekBucket(
                weekStartMillis = startMillis,
                sessionCount = weekSessions.size,
                volumeKg = volumeKg
            )
        }
    }

    /**
     * Builds monthly buckets for the last [months] calendar months.
     * Starts on the 1st of each calendar month, the last bucket is the current month,
     * and every month in the range is present (0 when empty).
     */
    fun monthlyBuckets(
        sessions: List<WorkoutSessionWithExercises>,
        months: Int = 6,
        nowMillis: Long = System.currentTimeMillis(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): List<MonthBucket> {
        if (months <= 0) return emptyList()

        val completedSessions = sessions.filter { it.session.status == WorkoutSessionStatus.COMPLETED }
        val now = Instant.ofEpochMilli(nowMillis).atZone(zoneId)
        val currentFirstDayOfMonth = now.toLocalDate().withDayOfMonth(1)

        return (0 until months).map { i ->
            val firstOfMonth = currentFirstDayOfMonth.minusMonths((months - 1 - i).toLong())
            val startMillis = firstOfMonth.atStartOfDay(zoneId).toInstant().toEpochMilli()
            val endMillis = firstOfMonth.plusMonths(1).atStartOfDay(zoneId).toInstant().toEpochMilli()

            val monthSessions = completedSessions.filter {
                val ts = it.session.startedAt
                ts in startMillis until endMillis
            }

            var volumeKg = 0.0
            for (session in monthSessions) {
                for (exercise in session.exercises) {
                    for (set in exercise.sets) {
                        if (set.completedAt != null && !set.isWarmup && set.reps > 0 && set.weightKg > 0.0) {
                            volumeKg += (set.reps * set.weightKg)
                        }
                    }
                }
            }

            MonthBucket(
                monthStartMillis = startMillis,
                sessionCount = monthSessions.size,
                volumeKg = volumeKg
            )
        }
    }

    /**
     * Builds strength progression series for a specific exercise.
     * One point per COMPLETED session containing the exercise, sorted oldest to newest.
     * bestE1rmKg is calculated across valid sets with reps in 1..12 and weightKg > 0.
     * For bodyweight exercises (all weights 0), bestE1rmKg is null and bestReps is used.
     */
    fun strengthSeries(
        sessions: List<WorkoutSessionWithExercises>,
        exerciseId: String,
        rangeDays: Int? = null,
        nowMillis: Long = System.currentTimeMillis(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): List<StrengthPoint> {
        val cutoff = if (rangeDays != null) {
            nowMillis - (rangeDays.toLong() * 24L * 60 * 60 * 1000L)
        } else null

        val completedSessions = sessions
            .filter { it.session.status == WorkoutSessionStatus.COMPLETED }
            .filter {
                val ts = it.session.endedAt ?: it.session.startedAt
                cutoff == null || ts >= cutoff
            }
            .sortedBy { it.session.endedAt ?: it.session.startedAt }

        val points = mutableListOf<StrengthPoint>()

        for (session in completedSessions) {
            val matchingExercises = session.exercises.filter { it.exercise.exerciseId == exerciseId }
            if (matchingExercises.isEmpty()) continue

            val validSets = matchingExercises
                .flatMap { it.sets }
                .filter { it.completedAt != null && !it.isWarmup && it.reps > 0 }

            if (validSets.isEmpty()) continue

            val ts = session.session.endedAt ?: session.session.startedAt
            val isBodyweight = validSets.all { it.weightKg <= 0.0 }
            val bestWeight = validSets.maxOfOrNull { it.weightKg } ?: 0.0
            val bestReps = validSets.maxOfOrNull { it.reps } ?: 0

            val bestE1rm = if (isBodyweight) {
                null
            } else {
                validSets
                    .filter { it.weightKg > 0.0 && it.reps in 1..12 }
                    .mapNotNull { Epley.calculate1RM(it.weightKg, it.reps) }
                    .maxOrNull()
            }

            points.add(
                StrengthPoint(
                    dateMillis = ts,
                    bestE1rmKg = bestE1rm,
                    bestWeightKg = bestWeight,
                    bestReps = bestReps
                )
            )
        }

        return points
    }

    /**
     * Returns exercise IDs ever logged in completed sessions, ordered by most recent first.
     */
    fun loggedExerciseIds(sessions: List<WorkoutSessionWithExercises>): List<String> {
        val completed = sessions
            .filter { it.session.status == WorkoutSessionStatus.COMPLETED }
            .sortedByDescending { it.session.endedAt ?: it.session.startedAt }

        return completed
            .flatMap { it.exercises.map { ex -> ex.exercise.exerciseId } }
            .distinct()
    }

    /**
     * Calculates consistency summary metrics over weekly buckets.
     */
    fun consistencySummary(weeklyBuckets: List<WeekBucket>): ConsistencySummary {
        val weeksWithWorkouts = weeklyBuckets.count { it.sessionCount > 0 }
        val totalSessions = weeklyBuckets.sumOf { it.sessionCount }
        val avg = if (weeklyBuckets.isNotEmpty()) {
            totalSessions.toDouble() / weeklyBuckets.size.toDouble()
        } else {
            0.0
        }

        return ConsistencySummary(
            weeksWithAtLeastOneWorkout = weeksWithWorkouts,
            avgSessionsPerWeek = avg
        )
    }
}
