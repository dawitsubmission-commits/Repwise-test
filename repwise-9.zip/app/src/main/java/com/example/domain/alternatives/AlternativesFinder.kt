package com.example.domain.alternatives

import com.example.domain.models.CatalogExercise

object AlternativesFinder {

    /**
     * Finds alternatives for [currentExercise] meeting the criteria:
     * - Same normalized target muscle
     * - AND same movementPattern (non-null and equal)
     * - Excluding the same ID
     * - Ranked by shared secondary muscles (descending)
     */
    fun findAlternatives(
        currentExercise: CatalogExercise,
        allExercises: List<CatalogExercise>
    ): List<CatalogExercise> {
        val currentMovement = currentExercise.movementPattern
        if (currentMovement.isNullOrBlank()) {
            return emptyList()
        }

        val currentNormalizedTarget = currentExercise.target.trim().lowercase()
        val currentSecondaries = currentExercise.secondaryMuscles
            .map { it.trim().lowercase() }
            .toSet()

        return allExercises
            .filter { candidate ->
                // Must not be the same ID
                candidate.id != currentExercise.id &&
                    // Same normalized target muscle
                    candidate.target.trim().lowercase() == currentNormalizedTarget &&
                    // Same movement pattern
                    !candidate.movementPattern.isNullOrBlank() &&
                    candidate.movementPattern.equals(currentMovement, ignoreCase = true)
            }
            .sortedWith(
                compareByDescending<CatalogExercise> { candidate ->
                    // Ranked by count of shared secondary muscles
                    candidate.secondaryMuscles.count { sec ->
                        currentSecondaries.contains(sec.trim().lowercase())
                    }
                }.thenBy { it.name.lowercase() }
            )
    }
}
