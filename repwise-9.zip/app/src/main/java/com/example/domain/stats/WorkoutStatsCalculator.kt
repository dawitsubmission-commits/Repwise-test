package com.example.domain.stats

import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.WorkoutSessionWithExercises
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

data class ComputedWorkoutStats(
    val sessionsThisWeek: Int = 0,
    val totalVolumeKg: Double = 0.0,
    val avgDurationMinutes: Int = 0,
    val prsLast30Days: Int = 0,
    val streakWeeks: Int = 0,
    val totalCompletedSessions: Int = 0
)

object WorkoutStatsCalculator {

    fun computeStats(
        completedSessions: List<WorkoutSessionWithExercises>,
        personalRecords: List<PersonalRecordEntity>,
        nowMillis: Long = System.currentTimeMillis(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): ComputedWorkoutStats {
        if (completedSessions.isEmpty()) {
            return ComputedWorkoutStats(
                sessionsThisWeek = 0,
                totalVolumeKg = 0.0,
                avgDurationMinutes = 0,
                prsLast30Days = 0,
                streakWeeks = 0,
                totalCompletedSessions = 0
            )
        }

        val today = Instant.ofEpochMilli(nowMillis).atZone(zoneId).toLocalDate()
        val currentMonday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val startOfWeekMillis = currentMonday.atStartOfDay(zoneId).toInstant().toEpochMilli()

        // 1. Sessions this week
        val sessionsThisWeek = completedSessions.count { it.session.startedAt >= startOfWeekMillis }

        // 2. Total volume in kg (sum of reps x weightKg over completed non-warm-up sets)
        var totalVolumeKg = 0.0
        for (session in completedSessions) {
            for (exercise in session.exercises) {
                for (set in exercise.sets) {
                    if (set.completedAt != null && !set.isWarmup && set.reps > 0 && set.weightKg > 0.0) {
                        totalVolumeKg += (set.reps * set.weightKg)
                    }
                }
            }
        }

        // 3. Average duration (in minutes)
        var totalDurationMs = 0L
        for (session in completedSessions) {
            val ended = session.session.endedAt ?: session.session.startedAt
            val dur = maxOf(0L, ended - session.session.startedAt)
            totalDurationMs += dur
        }
        val avgDurationMinutes = if (completedSessions.isNotEmpty()) {
            ((totalDurationMs / completedSessions.size) / 60000.0).roundToInt()
        } else {
            0
        }

        // 4. Number of PRs in the last 30 days
        val thirtyDaysAgoMillis = nowMillis - (30L * 24 * 60 * 60 * 1000)
        val prsLast30Days = personalRecords.count { it.achievedAt >= thirtyDaysAgoMillis }

        // 5. Streak = consecutive weeks with at least one completed session
        val activeMondays = completedSessions.map {
            Instant.ofEpochMilli(it.session.startedAt).atZone(zoneId).toLocalDate()
                .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        }.toSet()

        val streakWeeks = if (activeMondays.contains(currentMonday)) {
            var count = 1
            var checkMonday = currentMonday.minusWeeks(1)
            while (activeMondays.contains(checkMonday)) {
                count++
                checkMonday = checkMonday.minusWeeks(1)
            }
            count
        } else if (activeMondays.contains(currentMonday.minusWeeks(1))) {
            var count = 1
            var checkMonday = currentMonday.minusWeeks(2)
            while (activeMondays.contains(checkMonday)) {
                count++
                checkMonday = checkMonday.minusWeeks(1)
            }
            count
        } else {
            0
        }

        return ComputedWorkoutStats(
            sessionsThisWeek = sessionsThisWeek,
            totalVolumeKg = totalVolumeKg,
            avgDurationMinutes = avgDurationMinutes,
            prsLast30Days = prsLast30Days,
            streakWeeks = streakWeeks,
            totalCompletedSessions = completedSessions.size
        )
    }
}
