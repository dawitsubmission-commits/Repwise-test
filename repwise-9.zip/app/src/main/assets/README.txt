REPWISE starter pack (subset of flow-exercise-dataset, 44 exercises)
Unzip so that these folders land inside app/src/main/assets/ :
  catalog/exercises.json   -> assets/catalog/exercises.json
  exercises/<id>/frame-0N.svg -> assets/exercises/<id>/frame-0N.svg
  licenses/*               -> assets/licenses/*
Same schema as the original dataset. Frame paths are rewritten to be relative to the assets folder
(e.g. "exercises/0662/frame-00.svg"). Two entries (0558, 1366) have animation = null on purpose,
to test the text-only fallback. IDs are strings: keep leading zeros.
Data: MIT. Artwork: CC0-1.0. See licenses/NOTICE.md (AI-generated art, limited provenance, not professionally reviewed).
