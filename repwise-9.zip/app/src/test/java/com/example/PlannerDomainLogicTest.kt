package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.entities.PlanDayEntity
import com.example.data.local.entities.PlanDayWithExercises
import com.example.data.local.entities.PlanExerciseEntity
import com.example.data.local.entities.WorkoutPlanEntity
import com.example.data.local.entities.WorkoutPlanWithDays
import com.example.domain.alternatives.AlternativesFinder
import com.example.domain.models.CatalogExercise
import com.example.domain.templates.TemplateRepository
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedReader
import java.io.InputStreamReader

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PlannerDomainLogicTest {

    private lateinit var catalogExercises: List<CatalogExercise>
    private lateinit var catalogIds: Set<String>

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val jsonContent = context.assets.open("catalog/exercises.json").use { stream ->
            BufferedReader(InputStreamReader(stream)).readText()
        }
        val jsonArray = JSONArray(jsonContent)
        val list = mutableListOf<CatalogExercise>()

        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            val id = item.getString("id")
            val name = item.getString("name")
            val bodyPart = item.optString("bodyPart", "")
            val equipment = item.getString("equipment")
            val target = item.getString("target")
            val movement = if (item.has("movementPattern") && !item.isNull("movementPattern")) item.getString("movementPattern") else null

            val secList = mutableListOf<String>()
            val secArr = item.optJSONArray("secondaryMuscles")
            if (secArr != null) {
                for (j in 0 until secArr.length()) {
                    secList.add(secArr.getString(j))
                }
            }

            list.add(
                CatalogExercise(
                    id = id,
                    name = name,
                    bodyPart = bodyPart,
                    equipment = equipment,
                    target = target,
                    secondaryMuscles = secList,
                    movementPattern = movement
                )
            )
        }

        catalogExercises = list
        catalogIds = list.map { it.id }.toSet()
    }

    @Test
    fun testEveryTemplateExerciseIdExistsInCatalog() {
        val templates = TemplateRepository.getAllTemplates()
        assertTrue("Templates should not be empty", templates.isNotEmpty())

        for (template in templates) {
            for (day in template.days) {
                for (exerciseId in day.exerciseIds) {
                    assertTrue(
                        "Exercise ID '$exerciseId' in template '${template.name}' / '${day.name}' must exist in catalog",
                        catalogIds.contains(exerciseId)
                    )
                }
            }
        }
    }

    @Test
    fun testAlternativesNeverIncludeSameId() {
        // Test for all catalog exercises
        for (current in catalogExercises) {
            val alternatives = AlternativesFinder.findAlternatives(current, catalogExercises)
            for (alt in alternatives) {
                assertNotEquals(
                    "Alternatives must never include the same ID as the source exercise (${current.id})",
                    current.id,
                    alt.id
                )
                assertEquals(
                    "Alternative must match the source target muscle",
                    current.target.trim().lowercase(),
                    alt.target.trim().lowercase()
                )
                assertEquals(
                    "Alternative must match the source movement pattern",
                    current.movementPattern?.trim()?.lowercase(),
                    alt.movementPattern?.trim()?.lowercase()
                )
            }
        }
    }

    @Test
    fun testDuplicateIsIndependent() {
        // Create an original routine with days and exercises
        val original = WorkoutPlanWithDays(
            plan = WorkoutPlanEntity(id = 1, name = "Original Hypertrophy", isActive = true),
            days = listOf(
                PlanDayWithExercises(
                    day = PlanDayEntity(id = 10, planId = 1, name = "Push Day", weekday = 1, position = 0),
                    exercises = mutableListOf(
                        PlanExerciseEntity(id = 100, planDayId = 10, exerciseId = "0662", position = 0, sets = 3, repMin = 8, repMax = 12, restSeconds = 90)
                    )
                )
            )
        )

        // Duplicate the routine
        val duplicate = TemplateRepository.duplicatePlan(original, "Duplicated Routine")

        // Assert fresh IDs
        assertEquals(0L, duplicate.plan.id)
        assertEquals(0L, duplicate.days[0].day.id)
        assertEquals(0L, duplicate.days[0].exercises[0].id)
        assertFalse("Duplicate should default to inactive", duplicate.plan.isActive)
        assertEquals("Duplicated Routine", duplicate.plan.name)

        // Mutate the duplicate copy (e.g. modify sets, add exercise, change name)
        val modifiedDuplicateExercises = duplicate.days[0].exercises.toMutableList().apply {
            this[0] = this[0].copy(sets = 5, repMin = 15, repMax = 20, restSeconds = 120)
            add(PlanExerciseEntity(id = 200, planDayId = 0, exerciseId = "0293", position = 1, sets = 4))
        }

        // Assert original remains completely untouched and independent
        assertEquals("Original Hypertrophy", original.plan.name)
        assertTrue(original.plan.isActive)
        assertEquals(1, original.days[0].exercises.size)
        assertEquals(3, original.days[0].exercises[0].sets)
        assertEquals(8, original.days[0].exercises[0].repMin)
        assertEquals(12, original.days[0].exercises[0].repMax)
        assertEquals(90, original.days[0].exercises[0].restSeconds)

        // Assert modified copy has changes
        assertEquals(2, modifiedDuplicateExercises.size)
        assertEquals(5, modifiedDuplicateExercises[0].sets)
    }
}
