package com.example

import com.example.data.local.entities.PersonalRecordType
import com.example.data.local.entities.SessionExerciseEntity
import com.example.data.local.entities.SessionExerciseWithSets
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.domain.Epley
import com.example.domain.PersonalRecordDetector
import com.example.domain.PreviousPerformanceFinder
import com.example.domain.SessionRecovery
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ActiveWorkoutDomainLogicTest {

    // 1. EPLEY MATH TESTS
    @Test
    fun testEpleyMathWithinRange() {
        // 100 kg for 1 rep: 100 * (1 + 1/30) = 103.333...
        val e1rm1 = Epley.calculate1RM(100.0, 1)
        assertNotNull(e1rm1)
        assertEquals(103.3333, e1rm1!!, 0.001)

        // 100 kg for 10 reps: 100 * (1 + 10/30) = 133.333...
        val e1rm10 = Epley.calculate1RM(100.0, 10)
        assertNotNull(e1rm10)
        assertEquals(133.3333, e1rm10!!, 0.001)

        // 60 kg for 6 reps: 60 * (1 + 6/30) = 72.0
        val e1rm6 = Epley.calculate1RM(60.0, 6)
        assertNotNull(e1rm6)
        assertEquals(72.0, e1rm6!!, 0.001)

        // 12 reps is the upper boundary: 100 * (1 + 12/30) = 140.0
        val e1rm12 = Epley.calculate1RM(100.0, 12)
        assertNotNull(e1rm12)
        assertEquals(140.0, e1rm12!!, 0.001)
    }

    @Test
    fun testEpleyMathOutsideRangeReturnsNull() {
        // 0 reps -> invalid
        assertNull(Epley.calculate1RM(100.0, 0))

        // Negative reps -> invalid
        assertNull(Epley.calculate1RM(100.0, -5))

        // 13 reps -> beyond 1-12 range
        assertNull(Epley.calculate1RM(100.0, 13))

        // 20 reps -> beyond 1-12 range
        assertNull(Epley.calculate1RM(100.0, 20))

        // 0 kg or negative weight -> invalid
        assertNull(Epley.calculate1RM(0.0, 10))
        assertNull(Epley.calculate1RM(-50.0, 10))
    }

    // 2. PR DETECTION TESTS (WARM-UPS IGNORED, TIES ARE NOT PRS)
    @Test
    fun testPRDetectionWarmupsIgnored() {
        val exerciseId = "0025" // Barbell Bench Press
        val priorHistory = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 10, weightKg = 80.0, isWarmup = false, completedAt = 1000L)
        )

        // A warm-up set with massive weight should NEVER be recognized as a PR
        val warmupSet = SetLogEntity(
            id = 2,
            sessionExerciseId = 2,
            setIndex = 0,
            reps = 10,
            weightKg = 150.0,
            isWarmup = true,
            completedAt = 2000L
        )

        assertFalse("Warm-up sets must be ignored for PR detection", PersonalRecordDetector.isSetPR(warmupSet, priorHistory))

        val detectedPRs = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(warmupSet),
            priorHistoricalSets = priorHistory
        )
        assertTrue("No PR records should be detected from warm-up sets", detectedPRs.isEmpty())
    }

    @Test
    fun testPRDetectionTiesAreNotPRs() {
        val exerciseId = "0025"
        val priorHistory = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 8, weightKg = 100.0, isWarmup = false, completedAt = 1000L)
        )

        // Exact tie: 100 kg for 8 reps
        val tiedSet = SetLogEntity(
            id = 2,
            sessionExerciseId = 2,
            setIndex = 0,
            reps = 8,
            weightKg = 100.0,
            isWarmup = false,
            completedAt = 2000L
        )

        assertFalse("Tied weight and reps must NOT be a PR", PersonalRecordDetector.isSetPR(tiedSet, priorHistory))

        val detectedTiedPRs = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(tiedSet),
            priorHistoricalSets = priorHistory
        )
        assertTrue("Detected PRs must be empty for tied performance", detectedTiedPRs.isEmpty())
    }

    @Test
    fun testPRDetectionStrictImprovementsArePRs() {
        val exerciseId = "0025"
        val priorHistory = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 8, weightKg = 100.0, isWarmup = false, completedAt = 1000L)
        )

        // 1. Strict heavier weight PR: 105 kg for 5 reps
        val heavierSet = SetLogEntity(
            id = 2,
            sessionExerciseId = 2,
            setIndex = 0,
            reps = 5,
            weightKg = 105.0,
            isWarmup = false,
            completedAt = 2000L
        )
        assertTrue("Heavier weight must be a PR", PersonalRecordDetector.isSetPR(heavierSet, priorHistory))

        // 2. Strict reps at weight PR: 100 kg for 10 reps (beats 8 reps)
        val moreRepsSet = SetLogEntity(
            id = 3,
            sessionExerciseId = 2,
            setIndex = 1,
            reps = 10,
            weightKg = 100.0,
            isWarmup = false,
            completedAt = 2100L
        )
        assertTrue("More reps at same weight must be a PR", PersonalRecordDetector.isSetPR(moreRepsSet, priorHistory))

        val detected = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(moreRepsSet),
            priorHistoricalSets = priorHistory
        )
        assertTrue("New PRs should be detected", detected.isNotEmpty())
        assertTrue("Should include BEST_REPS_AT_WEIGHT", detected.any { it.type == PersonalRecordType.BEST_REPS_AT_WEIGHT })
        assertTrue("Should include BEST_E1RM", detected.any { it.type == PersonalRecordType.BEST_E1RM })
    }

    @Test
    fun testIncompleteSetsAreNotPRs() {
        val priorHistory = emptyList<SetLogEntity>()
        // completedAt == null means not completed yet
        val uncompletedSet = SetLogEntity(
            id = 1,
            sessionExerciseId = 1,
            setIndex = 0,
            reps = 10,
            weightKg = 100.0,
            isWarmup = false,
            completedAt = null
        )

        assertFalse("Uncompleted set must not be a PR", PersonalRecordDetector.isSetPR(uncompletedSet, priorHistory))
    }

    @Test
    fun testFirstEverCompletedSetIsBaselineNotPR() {
        val exerciseId = "0025"
        val priorHistory = emptyList<SetLogEntity>()
        val firstSet = SetLogEntity(
            id = 1,
            sessionExerciseId = 1,
            setIndex = 0,
            reps = 10,
            weightKg = 80.0,
            isWarmup = false,
            completedAt = 1000L
        )

        assertFalse("First-ever completed set is a baseline, not a PR", PersonalRecordDetector.isSetPR(firstSet, priorHistory))

        val detected = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(firstSet),
            priorHistoricalSets = priorHistory
        )
        assertTrue("No PR records for first-ever completed set", detected.isEmpty())
    }

    @Test
    fun testBestRepsAtWeightOnlyCountsIfPriorSetsExistAtExactWeight() {
        val exerciseId = "0025"
        val priorHistory = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 10, weightKg = 80.0, isWarmup = false, completedAt = 1000L)
        )

        // Brand new weight: 90kg for 5 reps
        val newWeightSet = SetLogEntity(
            id = 2,
            sessionExerciseId = 2,
            setIndex = 0,
            reps = 5,
            weightKg = 90.0,
            isWarmup = false,
            completedAt = 2000L
        )

        val detectedNewWeight = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(newWeightSet),
            priorHistoricalSets = priorHistory
        )

        // 90kg is heavier than 80kg, so HEAVIEST_WEIGHT is true.
        assertTrue("Heaviest weight PR should be detected", detectedNewWeight.any { it.type == PersonalRecordType.HEAVIEST_WEIGHT })
        // But BEST_REPS_AT_WEIGHT must NOT be detected because no prior set existed at 90kg!
        assertFalse(
            "BEST_REPS_AT_WEIGHT must NOT count for new weight without prior history at that exact weight",
            detectedNewWeight.any { it.type == PersonalRecordType.BEST_REPS_AT_WEIGHT }
        )

        // Now with prior history at 90kg (5 reps), doing 90kg for 7 reps:
        val priorWith90 = priorHistory + listOf(newWeightSet)
        val repPRSet = SetLogEntity(
            id = 3,
            sessionExerciseId = 3,
            setIndex = 0,
            reps = 7,
            weightKg = 90.0,
            isWarmup = false,
            completedAt = 3000L
        )

        val detectedRepPR = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(repPRSet),
            priorHistoricalSets = priorWith90
        )
        assertTrue(
            "BEST_REPS_AT_WEIGHT should be detected when beating prior reps at exact weight",
            detectedRepPR.any { it.type == PersonalRecordType.BEST_REPS_AT_WEIGHT }
        )
    }

    @Test
    fun testBodyweightZeroKgTracksBestRepsOnly() {
        val exerciseId = "0662" // Push-up
        val priorHistory = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 20, weightKg = 0.0, isWarmup = false, completedAt = 1000L)
        )

        val improvedBodyweightSet = SetLogEntity(
            id = 2,
            sessionExerciseId = 2,
            setIndex = 0,
            reps = 25,
            weightKg = 0.0,
            isWarmup = false,
            completedAt = 2000L
        )

        assertTrue("Bodyweight rep improvement should be a PR", PersonalRecordDetector.isSetPR(improvedBodyweightSet, priorHistory))

        val detected = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(improvedBodyweightSet),
            priorHistoricalSets = priorHistory
        )

        assertEquals("Should have exactly 1 PR (BEST_REPS_AT_WEIGHT)", 1, detected.size)
        assertEquals(PersonalRecordType.BEST_REPS_AT_WEIGHT, detected[0].type)
        assertEquals(25.0, detected[0].value, 0.001)
        assertFalse("Must not track HEAVIEST_WEIGHT for bodyweight 0kg", detected.any { it.type == PersonalRecordType.HEAVIEST_WEIGHT })
        assertFalse("Must not track BEST_E1RM for bodyweight 0kg", detected.any { it.type == PersonalRecordType.BEST_E1RM })
    }

    @Test
    fun testKeepOnlyBestRecordPerTypePerExercisePerSession() {
        val exerciseId = "0025"
        val priorHistory = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 5, weightKg = 80.0, isWarmup = false, completedAt = 1000L)
        )

        // In a single session, 3 sets progressively beat heaviest weight: 90kg, 95kg, 100kg
        val set1 = SetLogEntity(id = 2, sessionExerciseId = 2, setIndex = 0, reps = 5, weightKg = 90.0, isWarmup = false, completedAt = 2000L)
        val set2 = SetLogEntity(id = 3, sessionExerciseId = 2, setIndex = 1, reps = 5, weightKg = 95.0, isWarmup = false, completedAt = 2100L)
        val set3 = SetLogEntity(id = 4, sessionExerciseId = 2, setIndex = 2, reps = 5, weightKg = 100.0, isWarmup = false, completedAt = 2200L)

        val detected = PersonalRecordDetector.detectNewPRsForExercise(
            exerciseId = exerciseId,
            sessionSets = listOf(set1, set2, set3),
            priorHistoricalSets = priorHistory
        )

        val heaviestRecords = detected.filter { it.type == PersonalRecordType.HEAVIEST_WEIGHT }
        assertEquals("Must keep only ONE heaviest weight record per session", 1, heaviestRecords.size)
        assertEquals("Must keep the best (highest) value: 100kg", 100.0, heaviestRecords[0].value, 0.001)
    }

    // 3. PREVIOUS-PERFORMANCE LOOKUP TESTS (IGNORES DISCARDED AND IN_PROGRESS SESSIONS)
    @Test
    fun testPreviousPerformanceIgnoresDiscardedAndInProgress() {
        val exerciseId = "0662" // Push-up

        val sessionCompleted1 = WorkoutSessionWithExercises(
            session = WorkoutSessionEntity(id = 1, dayName = "Day 1", startedAt = 1000L, endedAt = 2000L, status = WorkoutSessionStatus.COMPLETED),
            exercises = listOf(
                SessionExerciseWithSets(
                    exercise = SessionExerciseEntity(id = 10, sessionId = 1, exerciseId = exerciseId),
                    sets = listOf(
                        SetLogEntity(id = 101, sessionExerciseId = 10, setIndex = 0, reps = 15, weightKg = 70.0, completedAt = 1500L)
                    )
                )
            )
        )

        val sessionDiscarded = WorkoutSessionWithExercises(
            session = WorkoutSessionEntity(id = 2, dayName = "Day 2", startedAt = 3000L, endedAt = 4000L, status = WorkoutSessionStatus.DISCARDED),
            exercises = listOf(
                SessionExerciseWithSets(
                    exercise = SessionExerciseEntity(id = 20, sessionId = 2, exerciseId = exerciseId),
                    sets = listOf(
                        SetLogEntity(id = 201, sessionExerciseId = 20, setIndex = 0, reps = 20, weightKg = 120.0, completedAt = 3500L)
                    )
                )
            )
        )

        val sessionInProgress = WorkoutSessionWithExercises(
            session = WorkoutSessionEntity(id = 3, dayName = "Day 3", startedAt = 5000L, endedAt = null, status = WorkoutSessionStatus.IN_PROGRESS),
            exercises = listOf(
                SessionExerciseWithSets(
                    exercise = SessionExerciseEntity(id = 30, sessionId = 3, exerciseId = exerciseId),
                    sets = listOf(
                        SetLogEntity(id = 301, sessionExerciseId = 30, setIndex = 0, reps = 25, weightKg = 140.0, completedAt = 5500L)
                    )
                )
            )
        )

        val sessionCompletedRecent = WorkoutSessionWithExercises(
            session = WorkoutSessionEntity(id = 4, dayName = "Day 4", startedAt = 6000L, endedAt = 7000L, status = WorkoutSessionStatus.COMPLETED),
            exercises = listOf(
                SessionExerciseWithSets(
                    exercise = SessionExerciseEntity(id = 40, sessionId = 4, exerciseId = exerciseId),
                    sets = listOf(
                        SetLogEntity(id = 401, sessionExerciseId = 40, setIndex = 0, reps = 12, weightKg = 85.0, completedAt = 6500L)
                    )
                )
            )
        )

        val allSessions = listOf(sessionCompleted1, sessionDiscarded, sessionInProgress, sessionCompletedRecent)

        val result = PreviousPerformanceFinder.findPreviousPerformance(exerciseId, allSessions)

        assertNotNull("Previous performance should be found from completed sessions", result)
        assertEquals("Must match the most recent COMPLETED session ID (4)", 4L, result!!.lastSessionId)
        assertEquals(85.0, result.defaultWeightKg, 0.001)
        assertEquals(12, result.defaultReps)
        assertFalse("Must NOT take data from discarded session (120kg)", result.summaryText.contains("120"))
        assertFalse("Must NOT take data from in-progress session (140kg)", result.summaryText.contains("140"))
    }

    // 4. SESSION RECOVERY TESTS (IN_PROGRESS SESSION FOUND AFTER APP RESTARTS)
    @Test
    fun testSessionRecoveryFindsInProgressSession() {
        val sessions = listOf(
            WorkoutSessionEntity(id = 1, dayName = "Leg Day", startedAt = 1000L, endedAt = 2000L, status = WorkoutSessionStatus.COMPLETED),
            WorkoutSessionEntity(id = 2, dayName = "Push Day", startedAt = 3000L, endedAt = 4000L, status = WorkoutSessionStatus.DISCARDED),
            WorkoutSessionEntity(id = 3, dayName = "Upper Body", startedAt = 5000L, endedAt = null, status = WorkoutSessionStatus.IN_PROGRESS)
        )

        val recovered = SessionRecovery.findInProgressSession(sessions)

        assertNotNull("Should recover active IN_PROGRESS session", recovered)
        assertEquals(3L, recovered!!.id)
        assertEquals("Upper Body", recovered.dayName)
        assertEquals(WorkoutSessionStatus.IN_PROGRESS, recovered.status)
    }

    @Test
    fun testSessionRecoveryReturnsNullWhenNoActiveSession() {
        val completedOnly = listOf(
            WorkoutSessionEntity(id = 1, dayName = "Leg Day", startedAt = 1000L, endedAt = 2000L, status = WorkoutSessionStatus.COMPLETED),
            WorkoutSessionEntity(id = 2, dayName = "Push Day", startedAt = 3000L, endedAt = 4000L, status = WorkoutSessionStatus.DISCARDED)
        )

        val recovered = SessionRecovery.findInProgressSession(completedOnly)
        assertNull("Should return null when no session is IN_PROGRESS", recovered)
    }
}
