package com.example

import com.example.data.local.entities.SessionExerciseEntity
import com.example.data.local.entities.SessionExerciseWithSets
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.domain.charts.ChartDataBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

class ChartDataBuilderTest {

    private val utcZone = ZoneId.of("UTC")

    @Test
    fun testMondayStartWeekBoundaries() {
        // Monday, Oct 19, 2026, 00:05:00 UTC
        val mondayStart = ZonedDateTime.of(2026, 10, 19, 0, 5, 0, 0, utcZone).toInstant().toEpochMilli()
        // Sunday, Oct 25, 2026, 23:55:00 UTC (same week)
        val sundayEnd = ZonedDateTime.of(2026, 10, 25, 23, 55, 0, 0, utcZone).toInstant().toEpochMilli()
        // Next Monday, Oct 26, 2026, 00:01:00 UTC (next week)
        val nextMonday = ZonedDateTime.of(2026, 10, 26, 0, 1, 0, 0, utcZone).toInstant().toEpochMilli()

        val sessions = listOf(
            createSession(id = 1, startedAt = mondayStart),
            createSession(id = 2, startedAt = sundayEnd),
            createSession(id = 3, startedAt = nextMonday)
        )

        // Evaluate with nowMillis on Thursday, Oct 29, 2026
        val nowMillis = ZonedDateTime.of(2026, 10, 29, 12, 0, 0, 0, utcZone).toInstant().toEpochMilli()
        val buckets = ChartDataBuilder.weeklyBuckets(sessions, weeks = 4, nowMillis = nowMillis, zoneId = utcZone)

        assertEquals(4, buckets.size)

        // Every week bucket must start on a Monday
        buckets.forEach { bucket ->
            val dayOfWeek = Instant.ofEpochMilli(bucket.weekStartMillis).atZone(utcZone).dayOfWeek
            assertEquals(DayOfWeek.MONDAY, dayOfWeek)
        }

        // The second-to-last bucket (Oct 19 week) should have 2 sessions (Monday and Sunday)
        val oct19Bucket = buckets[buckets.size - 2]
        assertEquals(2, oct19Bucket.sessionCount)

        // The last bucket (Oct 26 week) should have 1 session (Next Monday)
        val oct26Bucket = buckets[buckets.size - 1]
        assertEquals(1, oct26Bucket.sessionCount)
    }

    @Test
    fun testEmptyWeeksFilledWithZero() {
        // Only 1 session in the current week
        val nowMillis = ZonedDateTime.of(2026, 10, 29, 12, 0, 0, 0, utcZone).toInstant().toEpochMilli()
        val sessions = listOf(createSession(id = 1, startedAt = nowMillis))

        val buckets = ChartDataBuilder.weeklyBuckets(sessions, weeks = 8, nowMillis = nowMillis, zoneId = utcZone)

        assertEquals(8, buckets.size)

        // First 7 weeks must be present with count = 0 and volume = 0.0
        for (i in 0 until 7) {
            assertEquals("Week index $i should have 0 sessions", 0, buckets[i].sessionCount)
            assertEquals("Week index $i should have 0 volume", 0.0, buckets[i].volumeKg, 0.001)
        }

        // Last bucket has 1 session
        assertEquals(1, buckets.last().sessionCount)
    }

    @Test
    fun testWarmupAndUnfinishedSetsExcluded() {
        val nowMillis = ZonedDateTime.of(2026, 10, 29, 12, 0, 0, 0, utcZone).toInstant().toEpochMilli()

        val sets = listOf(
            // Valid: 100 kg * 5 reps = 500 kg
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 5, weightKg = 100.0, isWarmup = false, completedAt = nowMillis),
            // Warmup: 50 kg * 10 reps -> excluded
            SetLogEntity(id = 2, sessionExerciseId = 1, setIndex = 1, reps = 10, weightKg = 50.0, isWarmup = true, completedAt = nowMillis),
            // Unfinished (completedAt = null): 100 kg * 5 reps -> excluded
            SetLogEntity(id = 3, sessionExerciseId = 1, setIndex = 2, reps = 5, weightKg = 100.0, isWarmup = false, completedAt = null),
            // Zero reps: -> excluded
            SetLogEntity(id = 4, sessionExerciseId = 1, setIndex = 3, reps = 0, weightKg = 100.0, isWarmup = false, completedAt = nowMillis)
        )

        val session = createSession(id = 1, startedAt = nowMillis, sets = sets)
        val buckets = ChartDataBuilder.weeklyBuckets(listOf(session), weeks = 1, nowMillis = nowMillis, zoneId = utcZone)

        assertEquals(1, buckets.size)
        assertEquals(500.0, buckets.first().volumeKg, 0.001)
    }

    @Test
    fun testDiscardedAndInProgressSessionsExcluded() {
        val nowMillis = ZonedDateTime.of(2026, 10, 29, 12, 0, 0, 0, utcZone).toInstant().toEpochMilli()

        val completed = createSession(id = 1, status = WorkoutSessionStatus.COMPLETED, startedAt = nowMillis, exerciseId = "ex_test")
        val inProgress = createSession(id = 2, status = WorkoutSessionStatus.IN_PROGRESS, startedAt = nowMillis, exerciseId = "ex_test")
        val discarded = createSession(id = 3, status = WorkoutSessionStatus.DISCARDED, startedAt = nowMillis, exerciseId = "ex_test")

        val all = listOf(completed, inProgress, discarded)

        // 1. Weekly buckets
        val weekly = ChartDataBuilder.weeklyBuckets(all, weeks = 1, nowMillis = nowMillis, zoneId = utcZone)
        assertEquals(1, weekly.first().sessionCount)

        // 2. Monthly buckets
        val monthly = ChartDataBuilder.monthlyBuckets(all, months = 1, nowMillis = nowMillis, zoneId = utcZone)
        assertEquals(1, monthly.first().sessionCount)

        // 3. Strength series
        val series = ChartDataBuilder.strengthSeries(all, exerciseId = "ex_test", nowMillis = nowMillis, zoneId = utcZone)
        assertEquals(1, series.size)

        // 4. Logged exercise IDs
        val ids = ChartDataBuilder.loggedExerciseIds(all)
        assertEquals(listOf("ex_test"), ids)
    }

    @Test
    fun testBodyweightExerciseSeriesUsesReps() {
        val nowMillis = ZonedDateTime.of(2026, 10, 29, 12, 0, 0, 0, utcZone).toInstant().toEpochMilli()

        val sets = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 12, weightKg = 0.0, isWarmup = false, completedAt = nowMillis),
            SetLogEntity(id = 2, sessionExerciseId = 1, setIndex = 1, reps = 15, weightKg = 0.0, isWarmup = false, completedAt = nowMillis)
        )

        val session = createSession(id = 1, startedAt = nowMillis, exerciseId = "pull_up", sets = sets)
        val series = ChartDataBuilder.strengthSeries(listOf(session), exerciseId = "pull_up", nowMillis = nowMillis, zoneId = utcZone)

        assertEquals(1, series.size)
        val point = series.first()
        assertNull("bestE1rmKg must be null for bodyweight exercise", point.bestE1rmKg)
        assertEquals(15, point.bestReps)
        assertEquals(0.0, point.bestWeightKg, 0.001)
    }

    @Test
    fun testE1rmSeriesIgnoresSetsOver12Reps() {
        val nowMillis = ZonedDateTime.of(2026, 10, 29, 12, 0, 0, 0, utcZone).toInstant().toEpochMilli()

        // Session 1: only sets > 12 reps -> e1rm must be null because reps > 12
        val setsSession1 = listOf(
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 15, weightKg = 100.0, isWarmup = false, completedAt = nowMillis),
            SetLogEntity(id = 2, sessionExerciseId = 1, setIndex = 1, reps = 20, weightKg = 80.0, isWarmup = false, completedAt = nowMillis)
        )
        val session1 = createSession(id = 1, startedAt = nowMillis - 86400000L, exerciseId = "bench_press", sets = setsSession1)

        // Session 2: set with 5 reps (valid in 1..12) and set with 16 reps (> 12)
        // 100 kg * 5 reps -> e1RM = 100 * (1 + 5/30) = 116.666 kg
        val setsSession2 = listOf(
            SetLogEntity(id = 3, sessionExerciseId = 2, setIndex = 0, reps = 5, weightKg = 100.0, isWarmup = false, completedAt = nowMillis),
            SetLogEntity(id = 4, sessionExerciseId = 2, setIndex = 1, reps = 16, weightKg = 90.0, isWarmup = false, completedAt = nowMillis)
        )
        val session2 = createSession(id = 2, startedAt = nowMillis, exerciseId = "bench_press", sets = setsSession2)

        val series = ChartDataBuilder.strengthSeries(listOf(session1, session2), exerciseId = "bench_press", nowMillis = nowMillis, zoneId = utcZone)

        assertEquals(2, series.size)

        // Session 1: all reps > 12 -> e1RM null
        assertNull(series[0].bestE1rmKg)
        assertEquals(100.0, series[0].bestWeightKg, 0.001)
        assertEquals(20, series[0].bestReps)

        // Session 2: 5 reps used for e1RM (ignoring 16 reps set)
        assertNotNull(series[1].bestE1rmKg)
        assertEquals(100.0 * (1.0 + 5.0 / 30.0), series[1].bestE1rmKg!!, 0.001)
    }

    private fun createSession(
        id: Long,
        status: String = WorkoutSessionStatus.COMPLETED,
        startedAt: Long,
        exerciseId: String = "test_ex",
        sets: List<SetLogEntity> = listOf(
            SetLogEntity(id = 100, sessionExerciseId = 1, setIndex = 0, reps = 8, weightKg = 50.0, isWarmup = false, completedAt = startedAt + 60000L)
        )
    ): WorkoutSessionWithExercises {
        return WorkoutSessionWithExercises(
            session = WorkoutSessionEntity(
                id = id,
                dayName = "Workout $id",
                startedAt = startedAt,
                endedAt = startedAt + 1800000L,
                status = status
            ),
            exercises = listOf(
                SessionExerciseWithSets(
                    exercise = SessionExerciseEntity(
                        id = 1,
                        sessionId = id,
                        exerciseId = exerciseId,
                        position = 0
                    ),
                    sets = sets
                )
            )
        )
    }
}
