package com.example

import com.example.data.local.entities.PersonalRecordEntity
import com.example.data.local.entities.PersonalRecordType
import com.example.data.local.entities.SessionExerciseEntity
import com.example.data.local.entities.SessionExerciseWithSets
import com.example.data.local.entities.SetLogEntity
import com.example.data.local.entities.WorkoutSessionEntity
import com.example.data.local.entities.WorkoutSessionStatus
import com.example.data.local.entities.WorkoutSessionWithExercises
import com.example.domain.history.WorkoutHistoryHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class WorkoutHistoryTest {

    private val utcZone = ZoneId.of("UTC")

    @Test
    fun testHistoryGroupingByMonth() {
        val octTime1 = ZonedDateTime.of(2026, 10, 20, 10, 0, 0, 0, utcZone).toInstant().toEpochMilli()
        val octTime2 = ZonedDateTime.of(2026, 10, 10, 10, 0, 0, 0, utcZone).toInstant().toEpochMilli()
        val sepTime1 = ZonedDateTime.of(2026, 9, 15, 10, 0, 0, 0, utcZone).toInstant().toEpochMilli()
        val augTime1 = ZonedDateTime.of(2026, 8, 5, 10, 0, 0, 0, utcZone).toInstant().toEpochMilli()

        val sessions = listOf(
            createSessionWithExercises(id = 1, status = WorkoutSessionStatus.COMPLETED, startedAt = octTime1),
            createSessionWithExercises(id = 2, status = WorkoutSessionStatus.COMPLETED, startedAt = sepTime1),
            createSessionWithExercises(id = 3, status = WorkoutSessionStatus.COMPLETED, startedAt = octTime2),
            createSessionWithExercises(id = 4, status = WorkoutSessionStatus.COMPLETED, startedAt = augTime1)
        )

        val grouped = WorkoutHistoryHelper.groupSessionsByMonth(sessions, utcZone)

        assertEquals(3, grouped.size)
        val monthKeys = grouped.keys.toList()
        assertEquals("October 2026", monthKeys[0])
        assertEquals("September 2026", monthKeys[1])
        assertEquals("August 2026", monthKeys[2])

        // Inside October: session 1 (Oct 20) should come before session 3 (Oct 10)
        assertEquals(2, grouped["October 2026"]!!.size)
        assertEquals(1L, grouped["October 2026"]!![0].session.id)
        assertEquals(3L, grouped["October 2026"]!![1].session.id)
    }

    @Test
    fun testTotalVolumeExcludesWarmupsAndBodyweightSets() {
        val sets = listOf(
            // Valid working set 1: 100 kg x 5 = 500 kg
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 5, weightKg = 100.0, isWarmup = false, completedAt = 1000L),
            // Valid working set 2: 80 kg x 8 = 640 kg
            SetLogEntity(id = 2, sessionExerciseId = 1, setIndex = 1, reps = 8, weightKg = 80.0, isWarmup = false, completedAt = 2000L),
            // Warm-up set: 50 kg x 10 -> MUST BE EXCLUDED
            SetLogEntity(id = 3, sessionExerciseId = 1, setIndex = 2, reps = 10, weightKg = 50.0, isWarmup = true, completedAt = 3000L),
            // Bodyweight set: 0 kg x 15 -> MUST BE EXCLUDED
            SetLogEntity(id = 4, sessionExerciseId = 1, setIndex = 3, reps = 15, weightKg = 0.0, isWarmup = false, completedAt = 4000L),
            // Uncompleted set: completedAt = null -> MUST BE EXCLUDED
            SetLogEntity(id = 5, sessionExerciseId = 1, setIndex = 4, reps = 5, weightKg = 100.0, isWarmup = false, completedAt = null)
        )

        val session = createSessionWithExercises(
            id = 10,
            status = WorkoutSessionStatus.COMPLETED,
            startedAt = 1000L,
            sets = sets
        )

        val totalVolume = WorkoutHistoryHelper.calculateTotalVolume(session)
        // 500.0 + 640.0 = 1140.0
        assertEquals(1140.0, totalVolume, 0.001)
    }

    @Test
    fun testExerciseHistoryBestSetWeighted() {
        val sets = listOf(
            // Set 1: 60 kg x 10 -> e1RM = 60 * (1 + 10/30) = 80.0
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 10, weightKg = 60.0, isWarmup = false, completedAt = 1000L),
            // Set 2: 70 kg x 6 -> e1RM = 70 * (1 + 6/30) = 84.0 (Highest 1RM!)
            SetLogEntity(id = 2, sessionExerciseId = 1, setIndex = 1, reps = 6, weightKg = 70.0, isWarmup = false, completedAt = 2000L),
            // Set 3: 50 kg x 15 -> warmup -> ignored
            SetLogEntity(id = 3, sessionExerciseId = 1, setIndex = 2, reps = 15, weightKg = 50.0, isWarmup = true, completedAt = 3000L),
            // Set 4: 80 kg x 5 -> uncompleted -> ignored
            SetLogEntity(id = 4, sessionExerciseId = 1, setIndex = 3, reps = 5, weightKg = 80.0, isWarmup = false, completedAt = null)
        )

        val best = WorkoutHistoryHelper.calculateBestSet(sets)
        assertNotNull(best)
        assertEquals(2L, best!!.id)
        assertEquals(70.0, best.weightKg, 0.001)
        assertEquals(6, best.reps)
    }

    @Test
    fun testExerciseHistoryBestSetBodyweight() {
        val sets = listOf(
            // Set 1: 0 kg x 10 reps
            SetLogEntity(id = 1, sessionExerciseId = 1, setIndex = 0, reps = 10, weightKg = 0.0, isWarmup = false, completedAt = 1000L),
            // Set 2: 0 kg x 16 reps (Best set!)
            SetLogEntity(id = 2, sessionExerciseId = 1, setIndex = 1, reps = 16, weightKg = 0.0, isWarmup = false, completedAt = 2000L),
            // Set 3: 0 kg x 12 reps
            SetLogEntity(id = 3, sessionExerciseId = 1, setIndex = 2, reps = 12, weightKg = 0.0, isWarmup = false, completedAt = 3000L),
            // Warm-up set: 0 kg x 20 reps -> ignored
            SetLogEntity(id = 4, sessionExerciseId = 1, setIndex = 3, reps = 20, weightKg = 0.0, isWarmup = true, completedAt = 4000L)
        )

        val best = WorkoutHistoryHelper.calculateBestSet(sets)
        assertNotNull(best)
        assertEquals(2L, best!!.id)
        assertEquals(16, best.reps)
    }

    @Test
    fun testRecordsListPicksBestRecordPerType() {
        val records = listOf(
            PersonalRecordEntity(id = 1, exerciseId = "ex1", type = PersonalRecordType.HEAVIEST_WEIGHT, value = 100.0, setLogId = 10, achievedAt = 1000L),
            PersonalRecordEntity(id = 2, exerciseId = "ex1", type = PersonalRecordType.HEAVIEST_WEIGHT, value = 110.0, setLogId = 11, achievedAt = 2000L),
            PersonalRecordEntity(id = 3, exerciseId = "ex1", type = PersonalRecordType.HEAVIEST_WEIGHT, value = 105.0, setLogId = 12, achievedAt = 1500L),
            PersonalRecordEntity(id = 4, exerciseId = "ex1", type = PersonalRecordType.BEST_E1RM, value = 115.0, setLogId = 13, achievedAt = 1000L),
            PersonalRecordEntity(id = 5, exerciseId = "ex1", type = PersonalRecordType.BEST_E1RM, value = 125.0, setLogId = 14, achievedAt = 2500L),
            // ex2: bodyweight
            PersonalRecordEntity(id = 6, exerciseId = "ex2", type = PersonalRecordType.BEST_REPS_AT_WEIGHT, value = 15.0, setLogId = 20, achievedAt = 3000L),
            PersonalRecordEntity(id = 7, exerciseId = "ex2", type = PersonalRecordType.BEST_REPS_AT_WEIGHT, value = 22.0, setLogId = 21, achievedAt = 4000L)
        )

        val names = mapOf("ex1" to "Bench Press", "ex2" to "Push-up")
        val summary = WorkoutHistoryHelper.extractBestRecordsPerExercise(records, names)

        assertEquals(2, summary.size)

        // ex2 had most recent achievedAt (4000L vs 2500L) -> should be first
        val first = summary[0]
        assertEquals("ex2", first.exerciseId)
        assertTrue(first.isBodyweight)
        assertEquals(22, first.bestReps)
        assertNull(first.heaviestWeightKg)

        // ex1 -> weighted
        val second = summary[1]
        assertEquals("ex1", second.exerciseId)
        assertFalse(second.isBodyweight)
        assertEquals(110.0, second.heaviestWeightKg!!, 0.001)
        assertEquals(125.0, second.bestE1rmKg!!, 0.001)
    }

    @Test
    fun testDiscardedAndInProgressSessionsAreExcludedEverywhere() {
        val completedSession = createSessionWithExercises(id = 1, status = WorkoutSessionStatus.COMPLETED, startedAt = 1000L)
        val inProgressSession = createSessionWithExercises(id = 2, status = WorkoutSessionStatus.IN_PROGRESS, startedAt = 2000L)
        val discardedSession = createSessionWithExercises(id = 3, status = WorkoutSessionStatus.DISCARDED, startedAt = 3000L)

        val allSessions = listOf(completedSession, inProgressSession, discardedSession)

        // 1. Filter completed sessions
        val filtered = WorkoutHistoryHelper.filterCompletedSessions(allSessions)
        assertEquals(1, filtered.size)
        assertEquals(1L, filtered[0].session.id)
        assertEquals(WorkoutSessionStatus.COMPLETED, filtered[0].session.status)

        // 2. Group by month
        val grouped = WorkoutHistoryHelper.groupSessionsByMonth(allSessions, utcZone)
        val totalSessionsInGrouped = grouped.values.flatten().size
        assertEquals(1, totalSessionsInGrouped)
        assertEquals(1L, grouped.values.flatten()[0].session.id)

        // 3. Exercise history
        val exerciseHistory = WorkoutHistoryHelper.getExerciseHistory("test_ex", allSessions, utcZone)
        assertEquals(1, exerciseHistory.size)
        assertEquals(1L, exerciseHistory[0].sessionId)
    }

    private fun createSessionWithExercises(
        id: Long,
        status: String,
        startedAt: Long,
        sets: List<SetLogEntity> = listOf(
            SetLogEntity(id = 100, sessionExerciseId = 1, setIndex = 0, reps = 10, weightKg = 50.0, isWarmup = false, completedAt = startedAt + 60000)
        )
    ): WorkoutSessionWithExercises {
        return WorkoutSessionWithExercises(
            session = WorkoutSessionEntity(
                id = id,
                dayName = "Day $id",
                startedAt = startedAt,
                endedAt = startedAt + 1800000L,
                status = status
            ),
            exercises = listOf(
                SessionExerciseWithSets(
                    exercise = SessionExerciseEntity(
                        id = 1,
                        sessionId = id,
                        exerciseId = "test_ex",
                        position = 0
                    ),
                    sets = sets
                )
            )
        )
    }
}
