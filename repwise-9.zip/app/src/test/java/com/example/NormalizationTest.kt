package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.normalization.Normalizer
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedReader
import java.io.InputStreamReader

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NormalizationTest {

    @Test
    fun testExplicitRequiredMappings() {
        assertEquals("chest", Normalizer.normalizeMuscle("pectorals"))
        assertEquals("shoulders", Normalizer.normalizeMuscle("delts"))
        assertEquals("quadriceps", Normalizer.normalizeMuscle("quads"))
        assertEquals("trapezius", Normalizer.normalizeMuscle("traps"))
        assertEquals("core", Normalizer.normalizeMuscle("abs"))

        // "band" and "resistance band" are the same
        val band = Normalizer.normalizeEquipment("band")
        val resistanceBand = Normalizer.normalizeEquipment("resistance band")
        assertEquals(band, resistanceBand)
        assertEquals("resistance band", band)
    }

    @Test
    fun testAllMusclesAndEquipmentInCatalogAreMapped() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val jsonContent = context.assets.open("catalog/exercises.json").use { stream ->
            BufferedReader(InputStreamReader(stream)).readText()
        }
        val jsonArray = JSONArray(jsonContent)

        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            val exerciseId = item.getString("id")
            val target = item.getString("target")
            val equipment = item.getString("equipment")

            val normalizedTarget = Normalizer.normalizeMuscle(target)
            assertNotNull("Target muscle for $exerciseId should not be null", normalizedTarget)

            val normalizedEquip = Normalizer.normalizeEquipment(equipment)
            assertNotNull("Equipment for $exerciseId should not be null", normalizedEquip)

            val secondaries = item.optJSONArray("secondaryMuscles")
            if (secondaries != null) {
                for (j in 0 until secondaries.length()) {
                    val sec = secondaries.getString(j)
                    val normalizedSec = Normalizer.normalizeMuscle(sec)
                    assertNotNull("Secondary muscle '$sec' in $exerciseId should not be null", normalizedSec)
                }
            }
        }
    }

    @Test
    fun testAllRequiredTargetsSecondariesAndEquipmentDoNotThrow() {
        val targets = listOf(
            "abs", "pectorals", "biceps", "glutes", "delts", "triceps", "upper back", "lats",
            "calves", "quads", "forearms", "cardiovascular system", "hamstrings", "spine",
            "traps", "adductors", "serratus anterior", "abductors", "levator scapulae"
        )

        val secondaries = listOf(
            "shoulders", "hamstrings", "forearms", "triceps", "biceps", "quadriceps", "calves",
            "glutes", "core", "chest", "hip flexors", "obliques", "lower back", "rhomboids",
            "trapezius", "upper back", "traps", "deltoids", "rear deltoids", "brachialis",
            "back", "ankles", "feet", "rotator cuff", "latissimus dorsi", "ankle stabilizers",
            "soleus", "wrists", "upper chest", "wrist flexors", "wrist extensors", "abdominals",
            "sternocleidomastoid", "hands", "groin", "grip muscles", "lower abs", "lats",
            "inner thighs", "shins"
        )

        val equipment = listOf(
            "body weight", "dumbbell", "cable", "barbell", "leverage machine", "band",
            "smith machine", "kettlebell", "weighted", "stability ball", "ez barbell",
            "assisted", "sled machine", "medicine ball", "rope", "roller", "resistance band",
            "bosu ball", "olympic barbell", "wheel roller", "upper body ergometer",
            "skierg machine", "hammer", "stationary bike", "tire", "trap bar",
            "elliptical machine", "stepmill machine"
        )

        for (target in targets) {
            val normalized = Normalizer.normalizeMuscle(target)
            assertNotNull("Target '$target' normalized to null", normalized)
        }

        for (sec in secondaries) {
            val normalized = Normalizer.normalizeMuscle(sec)
            assertNotNull("Secondary muscle '$sec' normalized to null", normalized)
        }

        for (equip in equipment) {
            val normalized = Normalizer.normalizeEquipment(equip)
            assertNotNull("Equipment '$equip' normalized to null", normalized)
        }
    }

    @Test
    fun testUnmappedMuscleFails() {
        assertThrows(IllegalArgumentException::class.java) {
            Normalizer.normalizeMuscle("extraterrestrial_muscle")
        }
    }

    @Test
    fun testUnmappedEquipmentFails() {
        assertThrows(IllegalArgumentException::class.java) {
            Normalizer.normalizeEquipment("anti_gravity_boots")
        }
    }
}
