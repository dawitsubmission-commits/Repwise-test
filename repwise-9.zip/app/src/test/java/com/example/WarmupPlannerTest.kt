package com.example

import com.example.domain.warmup.DrillKind
import com.example.domain.warmup.WarmupPlanner
import com.example.domain.warmup.WarmupPool
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WarmupPlannerTest {

    private val fullCatalogIds: Set<String> = (
        WarmupPool.general +
        WarmupPool.chest +
        WarmupPool.back +
        WarmupPool.shoulders +
        WarmupPool.arms +
        WarmupPool.legs +
        WarmupPool.core
    ).map { it.exerciseId }.toSet()

    @Test
    fun testAreaMappingIncludingRawNames() {
        // Canonical targets
        assertEquals("chest", WarmupPlanner.areaOfTarget("chest"))
        assertEquals("chest", WarmupPlanner.areaOfTarget("serratus anterior"))
        assertEquals("back", WarmupPlanner.areaOfTarget("lats"))
        assertEquals("back", WarmupPlanner.areaOfTarget("upper back"))
        assertEquals("back", WarmupPlanner.areaOfTarget("trapezius"))
        assertEquals("back", WarmupPlanner.areaOfTarget("spine"))
        assertEquals("back", WarmupPlanner.areaOfTarget("rhomboids"))
        assertEquals("shoulders", WarmupPlanner.areaOfTarget("shoulders"))
        assertEquals("arms", WarmupPlanner.areaOfTarget("biceps"))
        assertEquals("arms", WarmupPlanner.areaOfTarget("triceps"))
        assertEquals("arms", WarmupPlanner.areaOfTarget("forearms"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("quadriceps"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("hamstrings"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("glutes"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("calves"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("adductors"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("abductors"))
        assertEquals("core", WarmupPlanner.areaOfTarget("core"))

        // Raw names
        assertEquals("chest", WarmupPlanner.areaOfTarget("pectorals"))
        assertEquals("shoulders", WarmupPlanner.areaOfTarget("delts"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("quads"))
        assertEquals("back", WarmupPlanner.areaOfTarget("traps"))
        assertEquals("core", WarmupPlanner.areaOfTarget("abs"))

        // Case insensitivity and whitespace trimming
        assertEquals("chest", WarmupPlanner.areaOfTarget("  PECTORALS  "))
        assertEquals("shoulders", WarmupPlanner.areaOfTarget("Delts"))
        assertEquals("legs", WarmupPlanner.areaOfTarget("Quads"))
        assertEquals("back", WarmupPlanner.areaOfTarget("TRAPS"))
        assertEquals("core", WarmupPlanner.areaOfTarget("  Abs "))

        // Unknown targets ignored
        assertNull(WarmupPlanner.areaOfTarget("cardio"))
        assertNull(WarmupPlanner.areaOfTarget("unknown_xyz"))
        assertNull(WarmupPlanner.areaOfTarget(""))
    }

    @Test
    fun testTop2AreasByExerciseCount() {
        // 3 legs, 2 chest, 1 shoulder -> top 2 are legs and chest
        val targets = listOf("quads", "chest", "hamstrings", "pectorals", "calves", "delts")
        val plan = WarmupPlanner.plan(targets, fullCatalogIds)

        val nonGeneralAreas = plan.filter { it.area != "general" }.map { it.area }.toSet()
        assertEquals(setOf("legs", "chest"), nonGeneralAreas)

        // Tie-breaker: area that appears first in workout
        // Order: chest (0), back (1), legs (2) - each with count 1
        val tieTargets = listOf("pectorals", "lats", "quads")
        val tiePlan = WarmupPlanner.plan(tieTargets, fullCatalogIds)
        val tieAreas = tiePlan.filter { it.area != "general" }.map { it.area }.distinct()
        assertEquals(listOf("chest", "back"), tieAreas)
    }

    @Test
    fun testGeneralFirst() {
        val targets = listOf("quads", "chest")
        val plan = WarmupPlanner.plan(targets, fullCatalogIds)

        assertTrue(plan.isNotEmpty())
        assertEquals("general", plan.first().area)
        assertEquals("3636", plan.first().exerciseId)
    }

    @Test
    fun testDynamicBeforeStretch() {
        // Leg exercises have both dynamic and stretch drills in the pool
        val targets = listOf("quads", "hamstrings", "glutes")
        val plan = WarmupPlanner.plan(targets, fullCatalogIds)

        val legDrills = plan.filter { it.area == "legs" }
        assertTrue(legDrills.isNotEmpty())

        var seenStretch = false
        for (drill in legDrills) {
            if (drill.kind == DrillKind.STRETCH) {
                seenStretch = true
            } else if (seenStretch) {
                // If we see dynamic after stretch, fail!
                assertTrue("Found dynamic drill after stretch drill in area legs", false)
            }
        }
    }

    @Test
    fun testNoDuplicateExerciseIds() {
        // 1167 and 1271 appear in both chest and shoulders
        // 1428 appears in shoulders and arms
        // 2329 appears in back and core
        // 1471 appears in general and core
        val targets = listOf("chest", "shoulders", "arms", "back", "core")
        val plan = WarmupPlanner.plan(targets, fullCatalogIds, maxDrills = 10)

        val ids = plan.map { it.exerciseId }
        val uniqueIds = ids.toSet()
        assertEquals("Plan must not contain duplicate exercise IDs", uniqueIds.size, ids.size)

        // Specifically verify shared IDs appear at most once
        listOf("1167", "1271", "1428", "2329", "1471").forEach { sharedId ->
            val count = ids.count { it == sharedId }
            assertTrue("Shared ID $sharedId appeared $count times (must be <= 1)", count <= 1)
        }
    }

    @Test
    fun testDrillsMissingFromCatalogAreDropped() {
        // Drop "3636" (first general) and "1167" (dynamic chest)
        val restrictedCatalog = fullCatalogIds - setOf("3636", "1167")
        val targets = listOf("chest")
        val plan = WarmupPlanner.plan(targets, restrictedCatalog)

        assertFalse(plan.any { it.exerciseId == "3636" })
        assertFalse(plan.any { it.exerciseId == "1167" })

        // General should fall back to second general drill "3224"
        val generalDrill = plan.firstOrNull { it.area == "general" }
        assertNotNull(generalDrill)
        assertEquals("3224", generalDrill?.exerciseId)
    }

    @Test
    fun testMaxDrillsCap() {
        // High count session where many drills would qualify
        val targets = listOf("quads", "hamstrings", "chest", "pectorals")

        val defaultCapPlan = WarmupPlanner.plan(targets, fullCatalogIds)
        assertTrue(defaultCapPlan.size <= 6)
        assertEquals(6, defaultCapPlan.size)

        val smallCapPlan = WarmupPlanner.plan(targets, fullCatalogIds, maxDrills = 3)
        assertEquals(3, smallCapPlan.size)
    }

    @Test
    fun testEmptyPlanWhenCatalogHasNoneOfTheIds() {
        val targets = listOf("chest", "quads")
        val emptyPlan = WarmupPlanner.plan(targets, emptySet())
        assertTrue(emptyPlan.isEmpty())

        val unrelatedCatalog = setOf("unrelated_01", "unrelated_02")
        val emptyPlan2 = WarmupPlanner.plan(targets, unrelatedCatalog)
        assertTrue(emptyPlan2.isEmpty())
    }

    @Test
    fun testDeterminism() {
        val targets = listOf("chest", "delts", "quads", "traps")
        val plan1 = WarmupPlanner.plan(targets, fullCatalogIds)
        val plan2 = WarmupPlanner.plan(targets, fullCatalogIds)
        val plan3 = WarmupPlanner.plan(targets, fullCatalogIds)

        assertEquals(plan1, plan2)
        assertEquals(plan2, plan3)
    }
}
