package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ExerciseCatalogImporter
import com.example.data.local.RepwiseDatabase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExerciseCatalogImportTest {

    private lateinit var context: Context
    private lateinit var database: RepwiseDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(
            context,
            RepwiseDatabase::class.java
        ).allowMainThreadQueries().build()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testFirstLaunchImportInOneTransaction() = runBlocking {
        val dao = database.exerciseDao()
        assertEquals(0, dao.getExerciseCount())

        // Run import on first launch
        ExerciseCatalogImporter.importCatalogIfEmpty(context, dao)

        val count = dao.getExerciseCount()
        assertEquals(44, count)

        // Verify exercise with leading zeros preserved (e.g. "0662")
        val exercise0662 = dao.getExerciseByIdOnce("0662")
        assertNotNull(exercise0662)
        assertEquals("0662", exercise0662!!.exercise.id)
        assertEquals("push-up", exercise0662.exercise.name)
        // Normalized target: pectorals -> chest
        assertEquals("chest", exercise0662.exercise.target)
        // Normalized equipment:
        assertEquals("body weight", exercise0662.exercise.equipment)

        // Normalized secondaries:
        val secondaries = exercise0662.secondaryMuscles.map { it.muscle }
        assertTrue("Expected secondaries to contain 'shoulders', got $secondaries", secondaries.contains("shoulders"))
        assertTrue("Expected secondaries to contain 'core', got $secondaries", secondaries.contains("core"))
        assertTrue("Expected secondaries to contain 'triceps', got $secondaries", secondaries.contains("triceps"))

        // Instructions stored as JSON text
        val instructionsArray = JSONArray(exercise0662.exercise.instructionsJson)
        assertEquals(4, instructionsArray.length())

        // Frame paths
        assertEquals("exercises/0662/frame-00.svg", exercise0662.exercise.frame00Path)

        // Verify null animation entry (e.g. 0558 or 1366)
        val exercise0558 = dao.getExerciseByIdOnce("0558")
        if (exercise0558 != null) {
            assertNull("Expected null frame00Path for 0558", exercise0558.exercise.frame00Path)
        }

        // Idempotency: second run shouldn't re-insert or fail
        ExerciseCatalogImporter.importCatalogIfEmpty(context, dao)
        assertEquals(44, dao.getExerciseCount())
    }
}
