REPWISE muscle map pack. Unzip into app/src/main/assets/ so you get:
  assets/musclemap/body-parts.json
  assets/licenses/body-highlighter-LICENSE.txt
Source: react-native-body-highlighter (MIT, (c) 2022 ELABBASSI Hicham). Keep the license file in the app's licenses screen.
